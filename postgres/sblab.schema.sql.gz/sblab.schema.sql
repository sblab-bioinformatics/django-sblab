--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.1
-- Dumped by pg_dump version 9.1.1
-- Started on 2015-10-16 12:15:33 BST

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 105 (class 2615 OID 172913)
-- Name: 20120622_rnaseq_pdsa; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA "20120622_rnaseq_pdsa";


ALTER SCHEMA "20120622_rnaseq_pdsa" OWNER TO dberaldi;

--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 105
-- Name: SCHEMA "20120622_rnaseq_pdsa"; Type: COMMENT; Schema: -; Owner: dberaldi
--

COMMENT ON SCHEMA "20120622_rnaseq_pdsa" IS 'Data relative to project 20120622_rnaseq_pdsa';


--
-- TOC entry 47 (class 2615 OID 116889)
-- Name: dbms_alert; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA dbms_alert;


ALTER SCHEMA dbms_alert OWNER TO dberaldi;

--
-- TOC entry 56 (class 2615 OID 116951)
-- Name: dbms_assert; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA dbms_assert;


ALTER SCHEMA dbms_assert OWNER TO dberaldi;

--
-- TOC entry 51 (class 2615 OID 116714)
-- Name: dbms_output; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA dbms_output;


ALTER SCHEMA dbms_output OWNER TO dberaldi;

--
-- TOC entry 46 (class 2615 OID 116780)
-- Name: dbms_pipe; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA dbms_pipe;


ALTER SCHEMA dbms_pipe OWNER TO dberaldi;

--
-- TOC entry 58 (class 2615 OID 116979)
-- Name: dbms_random; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA dbms_random;


ALTER SCHEMA dbms_random OWNER TO dberaldi;

--
-- TOC entry 53 (class 2615 OID 116908)
-- Name: dbms_utility; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA dbms_utility;


ALTER SCHEMA dbms_utility OWNER TO dberaldi;

--
-- TOC entry 39 (class 2615 OID 31251)
-- Name: django_admin; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA django_admin;


ALTER SCHEMA django_admin OWNER TO dberaldi;

--
-- TOC entry 224 (class 2615 OID 834786)
-- Name: extdata; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA extdata;


ALTER SCHEMA extdata OWNER TO dberaldi;

--
-- TOC entry 7 (class 2615 OID 24614)
-- Name: main; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA main;


ALTER SCHEMA main OWNER TO dberaldi;

--
-- TOC entry 40 (class 2615 OID 32844)
-- Name: materialized_views; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA materialized_views;


ALTER SCHEMA materialized_views OWNER TO dberaldi;

--
-- TOC entry 3550 (class 0 OID 0)
-- Dependencies: 40
-- Name: SCHEMA materialized_views; Type: COMMENT; Schema: -; Owner: dberaldi
--

COMMENT ON SCHEMA materialized_views IS 'Schema to hold materialized views and probabily nothing else';


--
-- TOC entry 43 (class 2615 OID 116707)
-- Name: oracle; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA oracle;


ALTER SCHEMA oracle OWNER TO dberaldi;

--
-- TOC entry 44 (class 2615 OID 116960)
-- Name: plunit; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA plunit;


ALTER SCHEMA plunit OWNER TO dberaldi;

--
-- TOC entry 50 (class 2615 OID 116867)
-- Name: plvchr; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA plvchr;


ALTER SCHEMA plvchr OWNER TO dberaldi;

--
-- TOC entry 48 (class 2615 OID 116813)
-- Name: plvdate; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA plvdate;


ALTER SCHEMA plvdate OWNER TO dberaldi;

--
-- TOC entry 54 (class 2615 OID 116911)
-- Name: plvlex; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA plvlex;


ALTER SCHEMA plvlex OWNER TO dberaldi;

--
-- TOC entry 49 (class 2615 OID 116702)
-- Name: plvstr; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA plvstr;


ALTER SCHEMA plvstr OWNER TO dberaldi;

--
-- TOC entry 52 (class 2615 OID 116899)
-- Name: plvsubst; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA plvsubst;


ALTER SCHEMA plvsubst OWNER TO dberaldi;

--
-- TOC entry 55 (class 2615 OID 116913)
-- Name: utl_file; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA utl_file;


ALTER SCHEMA utl_file OWNER TO dberaldi;

--
-- TOC entry 106 (class 2615 OID 190128)
-- Name: zzz_unused_or_deprecated; Type: SCHEMA; Schema: -; Owner: dberaldi
--

CREATE SCHEMA zzz_unused_or_deprecated;


ALTER SCHEMA zzz_unused_or_deprecated OWNER TO dberaldi;

--
-- TOC entry 565 (class 3079 OID 11906)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 3559 (class 0 OID 0)
-- Dependencies: 565
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- TOC entry 1590 (class 2612 OID 24721)
-- Name: plpython3u; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: dberaldi
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpython3u;


ALTER PROCEDURAL LANGUAGE plpython3u OWNER TO dberaldi;

SET search_path = main, pg_catalog;

--
-- TOC entry 1304 (class 1247 OID 250416)
-- Dependencies: 1305 7
-- Name: md5sum; Type: DOMAIN; Schema: main; Owner: dberaldi
--

CREATE DOMAIN md5sum AS text DEFAULT 'not_available'::text
	CONSTRAINT md5sum_check CHECK (((VALUE ~ '^[0-9a-f]{32}$'::text) OR (VALUE = 'not_available'::text)));


ALTER DOMAIN main.md5sum OWNER TO dberaldi;

SET search_path = utl_file, pg_catalog;

--
-- TOC entry 1329 (class 1247 OID 116914)
-- Dependencies: 55
-- Name: file_type; Type: DOMAIN; Schema: utl_file; Owner: dberaldi
--

CREATE DOMAIN file_type AS integer;


ALTER DOMAIN utl_file.file_type OWNER TO dberaldi;

SET search_path = dbms_alert, pg_catalog;

--
-- TOC entry 583 (class 1255 OID 116893)
-- Dependencies: 47
-- Name: _signal(text, text); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION _signal(name text, message text) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_alert_signal';


ALTER FUNCTION dbms_alert._signal(name text, message text) OWNER TO dberaldi;

--
-- TOC entry 587 (class 1255 OID 116897)
-- Dependencies: 47
-- Name: defered_signal(); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION defered_signal() RETURNS trigger
    LANGUAGE c SECURITY DEFINER
    AS '$libdir/orafunc', 'dbms_alert_defered_signal';


ALTER FUNCTION dbms_alert.defered_signal() OWNER TO dberaldi;

--
-- TOC entry 580 (class 1255 OID 116890)
-- Dependencies: 47
-- Name: register(text); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION register(name text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_alert_register';


ALTER FUNCTION dbms_alert.register(name text) OWNER TO dberaldi;

--
-- TOC entry 3561 (class 0 OID 0)
-- Dependencies: 580
-- Name: FUNCTION register(name text); Type: COMMENT; Schema: dbms_alert; Owner: dberaldi
--

COMMENT ON FUNCTION register(name text) IS 'Register session as recipient of alert name';


--
-- TOC entry 581 (class 1255 OID 116891)
-- Dependencies: 47
-- Name: remove(text); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION remove(name text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_alert_remove';


ALTER FUNCTION dbms_alert.remove(name text) OWNER TO dberaldi;

--
-- TOC entry 3562 (class 0 OID 0)
-- Dependencies: 581
-- Name: FUNCTION remove(name text); Type: COMMENT; Schema: dbms_alert; Owner: dberaldi
--

COMMENT ON FUNCTION remove(name text) IS 'Remove session as recipient of alert name';


--
-- TOC entry 582 (class 1255 OID 116892)
-- Dependencies: 47
-- Name: removeall(); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION removeall() RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_alert_removeall';


ALTER FUNCTION dbms_alert.removeall() OWNER TO dberaldi;

--
-- TOC entry 3563 (class 0 OID 0)
-- Dependencies: 582
-- Name: FUNCTION removeall(); Type: COMMENT; Schema: dbms_alert; Owner: dberaldi
--

COMMENT ON FUNCTION removeall() IS 'Remove registration for all alerts';


--
-- TOC entry 586 (class 1255 OID 116896)
-- Dependencies: 47
-- Name: set_defaults(double precision); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION set_defaults(sensitivity double precision) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_alert_set_defaults';


ALTER FUNCTION dbms_alert.set_defaults(sensitivity double precision) OWNER TO dberaldi;

--
-- TOC entry 588 (class 1255 OID 116898)
-- Dependencies: 47
-- Name: signal(text, text); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION signal(_event text, _message text) RETURNS void
    LANGUAGE c SECURITY DEFINER
    AS '$libdir/orafunc', 'dbms_alert_signal';


ALTER FUNCTION dbms_alert.signal(_event text, _message text) OWNER TO dberaldi;

--
-- TOC entry 3564 (class 0 OID 0)
-- Dependencies: 588
-- Name: FUNCTION signal(_event text, _message text); Type: COMMENT; Schema: dbms_alert; Owner: dberaldi
--

COMMENT ON FUNCTION signal(_event text, _message text) IS 'Emit signal to all recipients';


--
-- TOC entry 584 (class 1255 OID 116894)
-- Dependencies: 47
-- Name: waitany(double precision); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION waitany(OUT name text, OUT message text, OUT status integer, timeout double precision) RETURNS record
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_alert_waitany';


ALTER FUNCTION dbms_alert.waitany(OUT name text, OUT message text, OUT status integer, timeout double precision) OWNER TO dberaldi;

--
-- TOC entry 3565 (class 0 OID 0)
-- Dependencies: 584
-- Name: FUNCTION waitany(OUT name text, OUT message text, OUT status integer, timeout double precision); Type: COMMENT; Schema: dbms_alert; Owner: dberaldi
--

COMMENT ON FUNCTION waitany(OUT name text, OUT message text, OUT status integer, timeout double precision) IS 'Wait for any signal';


--
-- TOC entry 585 (class 1255 OID 116895)
-- Dependencies: 47
-- Name: waitone(text, double precision); Type: FUNCTION; Schema: dbms_alert; Owner: dberaldi
--

CREATE FUNCTION waitone(name text, OUT message text, OUT status integer, timeout double precision) RETURNS record
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_alert_waitone';


ALTER FUNCTION dbms_alert.waitone(name text, OUT message text, OUT status integer, timeout double precision) OWNER TO dberaldi;

--
-- TOC entry 3566 (class 0 OID 0)
-- Dependencies: 585
-- Name: FUNCTION waitone(name text, OUT message text, OUT status integer, timeout double precision); Type: COMMENT; Schema: dbms_alert; Owner: dberaldi
--

COMMENT ON FUNCTION waitone(name text, OUT message text, OUT status integer, timeout double precision) IS 'Wait for specific signal';


SET search_path = dbms_assert, pg_catalog;

--
-- TOC entry 631 (class 1255 OID 116952)
-- Dependencies: 56
-- Name: enquote_literal(character varying); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION enquote_literal(str character varying) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'dbms_assert_enquote_literal';


ALTER FUNCTION dbms_assert.enquote_literal(str character varying) OWNER TO dberaldi;

--
-- TOC entry 3567 (class 0 OID 0)
-- Dependencies: 631
-- Name: FUNCTION enquote_literal(str character varying); Type: COMMENT; Schema: dbms_assert; Owner: dberaldi
--

COMMENT ON FUNCTION enquote_literal(str character varying) IS 'Add leading and trailing quotes, verify that all single quotes are paired with adjacent single quotes';


--
-- TOC entry 633 (class 1255 OID 116954)
-- Dependencies: 56
-- Name: enquote_name(character varying); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION enquote_name(str character varying) RETURNS character varying
    LANGUAGE sql IMMUTABLE
    AS $_$SELECT dbms_assert.enquote_name($1, true)$_$;


ALTER FUNCTION dbms_assert.enquote_name(str character varying) OWNER TO dberaldi;

--
-- TOC entry 3568 (class 0 OID 0)
-- Dependencies: 633
-- Name: FUNCTION enquote_name(str character varying); Type: COMMENT; Schema: dbms_assert; Owner: dberaldi
--

COMMENT ON FUNCTION enquote_name(str character varying) IS 'Enclose name in double quotes';


--
-- TOC entry 632 (class 1255 OID 116953)
-- Dependencies: 56
-- Name: enquote_name(character varying, boolean); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION enquote_name(str character varying, loweralize boolean) RETURNS character varying
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_assert_enquote_name';


ALTER FUNCTION dbms_assert.enquote_name(str character varying, loweralize boolean) OWNER TO dberaldi;

--
-- TOC entry 3569 (class 0 OID 0)
-- Dependencies: 632
-- Name: FUNCTION enquote_name(str character varying, loweralize boolean); Type: COMMENT; Schema: dbms_assert; Owner: dberaldi
--

COMMENT ON FUNCTION enquote_name(str character varying, loweralize boolean) IS 'Enclose name in double quotes';


--
-- TOC entry 634 (class 1255 OID 116955)
-- Dependencies: 56
-- Name: noop(character varying); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION noop(str character varying) RETURNS character varying
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_assert_noop';


ALTER FUNCTION dbms_assert.noop(str character varying) OWNER TO dberaldi;

--
-- TOC entry 3570 (class 0 OID 0)
-- Dependencies: 634
-- Name: FUNCTION noop(str character varying); Type: COMMENT; Schema: dbms_assert; Owner: dberaldi
--

COMMENT ON FUNCTION noop(str character varying) IS 'Returns value without any checking.';


--
-- TOC entry 636 (class 1255 OID 116957)
-- Dependencies: 56
-- Name: object_name(character varying); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION object_name(str character varying) RETURNS character varying
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_assert_object_name';


ALTER FUNCTION dbms_assert.object_name(str character varying) OWNER TO dberaldi;

--
-- TOC entry 3571 (class 0 OID 0)
-- Dependencies: 636
-- Name: FUNCTION object_name(str character varying); Type: COMMENT; Schema: dbms_assert; Owner: dberaldi
--

COMMENT ON FUNCTION object_name(str character varying) IS 'Verify input string is an qualified sql name.';


--
-- TOC entry 638 (class 1255 OID 116959)
-- Dependencies: 56
-- Name: qualified_sql_name(character varying); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION qualified_sql_name(str character varying) RETURNS character varying
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_assert_qualified_sql_name';


ALTER FUNCTION dbms_assert.qualified_sql_name(str character varying) OWNER TO dberaldi;

--
-- TOC entry 635 (class 1255 OID 116956)
-- Dependencies: 56
-- Name: schema_name(character varying); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION schema_name(str character varying) RETURNS character varying
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_assert_schema_name';


ALTER FUNCTION dbms_assert.schema_name(str character varying) OWNER TO dberaldi;

--
-- TOC entry 3572 (class 0 OID 0)
-- Dependencies: 635
-- Name: FUNCTION schema_name(str character varying); Type: COMMENT; Schema: dbms_assert; Owner: dberaldi
--

COMMENT ON FUNCTION schema_name(str character varying) IS 'Verify input string is an existing schema name.';


--
-- TOC entry 637 (class 1255 OID 116958)
-- Dependencies: 56
-- Name: simple_sql_name(character varying); Type: FUNCTION; Schema: dbms_assert; Owner: dberaldi
--

CREATE FUNCTION simple_sql_name(str character varying) RETURNS character varying
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_assert_simple_sql_name';


ALTER FUNCTION dbms_assert.simple_sql_name(str character varying) OWNER TO dberaldi;

SET search_path = dbms_output, pg_catalog;

--
-- TOC entry 704 (class 1255 OID 116717)
-- Dependencies: 51
-- Name: disable(); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION disable() RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_disable';


ALTER FUNCTION dbms_output.disable() OWNER TO dberaldi;

--
-- TOC entry 3573 (class 0 OID 0)
-- Dependencies: 704
-- Name: FUNCTION disable(); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION disable() IS 'Disable package functionality';


--
-- TOC entry 703 (class 1255 OID 116716)
-- Dependencies: 51
-- Name: enable(); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION enable() RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_enable_default';


ALTER FUNCTION dbms_output.enable() OWNER TO dberaldi;

--
-- TOC entry 3574 (class 0 OID 0)
-- Dependencies: 703
-- Name: FUNCTION enable(); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION enable() IS 'Enable package functionality';


--
-- TOC entry 702 (class 1255 OID 116715)
-- Dependencies: 51
-- Name: enable(integer); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION enable(buffer_size integer) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_output_enable';


ALTER FUNCTION dbms_output.enable(buffer_size integer) OWNER TO dberaldi;

--
-- TOC entry 3575 (class 0 OID 0)
-- Dependencies: 702
-- Name: FUNCTION enable(buffer_size integer); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION enable(buffer_size integer) IS 'Enable package functionality';


--
-- TOC entry 709 (class 1255 OID 116722)
-- Dependencies: 51
-- Name: get_line(); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION get_line(OUT line text, OUT status integer) RETURNS record
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_get_line';


ALTER FUNCTION dbms_output.get_line(OUT line text, OUT status integer) OWNER TO dberaldi;

--
-- TOC entry 3576 (class 0 OID 0)
-- Dependencies: 709
-- Name: FUNCTION get_line(OUT line text, OUT status integer); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION get_line(OUT line text, OUT status integer) IS 'Get line from output buffer';


--
-- TOC entry 710 (class 1255 OID 116723)
-- Dependencies: 51
-- Name: get_lines(integer); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION get_lines(OUT lines text[], INOUT numlines integer) RETURNS record
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_get_lines';


ALTER FUNCTION dbms_output.get_lines(OUT lines text[], INOUT numlines integer) OWNER TO dberaldi;

--
-- TOC entry 3577 (class 0 OID 0)
-- Dependencies: 710
-- Name: FUNCTION get_lines(OUT lines text[], INOUT numlines integer); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION get_lines(OUT lines text[], INOUT numlines integer) IS 'Get lines from output buffer';


--
-- TOC entry 708 (class 1255 OID 116721)
-- Dependencies: 51
-- Name: new_line(); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION new_line() RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_new_line';


ALTER FUNCTION dbms_output.new_line() OWNER TO dberaldi;

--
-- TOC entry 3578 (class 0 OID 0)
-- Dependencies: 708
-- Name: FUNCTION new_line(); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION new_line() IS 'Put new line char to output';


--
-- TOC entry 706 (class 1255 OID 116719)
-- Dependencies: 51
-- Name: put(text); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION put(a text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_put';


ALTER FUNCTION dbms_output.put(a text) OWNER TO dberaldi;

--
-- TOC entry 3579 (class 0 OID 0)
-- Dependencies: 706
-- Name: FUNCTION put(a text); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION put(a text) IS 'Put some text to output';


--
-- TOC entry 707 (class 1255 OID 116720)
-- Dependencies: 51
-- Name: put_line(text); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION put_line(a text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_put_line';


ALTER FUNCTION dbms_output.put_line(a text) OWNER TO dberaldi;

--
-- TOC entry 3580 (class 0 OID 0)
-- Dependencies: 707
-- Name: FUNCTION put_line(a text); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION put_line(a text) IS 'Put line to output';


--
-- TOC entry 705 (class 1255 OID 116718)
-- Dependencies: 51
-- Name: serveroutput(boolean); Type: FUNCTION; Schema: dbms_output; Owner: dberaldi
--

CREATE FUNCTION serveroutput(boolean) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_output_serveroutput';


ALTER FUNCTION dbms_output.serveroutput(boolean) OWNER TO dberaldi;

--
-- TOC entry 3581 (class 0 OID 0)
-- Dependencies: 705
-- Name: FUNCTION serveroutput(boolean); Type: COMMENT; Schema: dbms_output; Owner: dberaldi
--

COMMENT ON FUNCTION serveroutput(boolean) IS 'Set drowing output';


SET search_path = dbms_pipe, pg_catalog;

--
-- TOC entry 775 (class 1255 OID 116789)
-- Dependencies: 46
-- Name: __list_pipes(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION __list_pipes() RETURNS SETOF record
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_list_pipes';


ALTER FUNCTION dbms_pipe.__list_pipes() OWNER TO dberaldi;

--
-- TOC entry 779 (class 1255 OID 116797)
-- Dependencies: 46
-- Name: create_pipe(text); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION create_pipe(text) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_pipe_create_pipe_1';


ALTER FUNCTION dbms_pipe.create_pipe(text) OWNER TO dberaldi;

--
-- TOC entry 3582 (class 0 OID 0)
-- Dependencies: 779
-- Name: FUNCTION create_pipe(text); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION create_pipe(text) IS 'Create named pipe';


--
-- TOC entry 778 (class 1255 OID 116796)
-- Dependencies: 46
-- Name: create_pipe(text, integer); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION create_pipe(text, integer) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_pipe_create_pipe_2';


ALTER FUNCTION dbms_pipe.create_pipe(text, integer) OWNER TO dberaldi;

--
-- TOC entry 3583 (class 0 OID 0)
-- Dependencies: 778
-- Name: FUNCTION create_pipe(text, integer); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION create_pipe(text, integer) IS 'Create named pipe';


--
-- TOC entry 777 (class 1255 OID 116795)
-- Dependencies: 46
-- Name: create_pipe(text, integer, boolean); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION create_pipe(text, integer, boolean) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_pipe_create_pipe';


ALTER FUNCTION dbms_pipe.create_pipe(text, integer, boolean) OWNER TO dberaldi;

--
-- TOC entry 3584 (class 0 OID 0)
-- Dependencies: 777
-- Name: FUNCTION create_pipe(text, integer, boolean); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION create_pipe(text, integer, boolean) IS 'Create named pipe';


--
-- TOC entry 776 (class 1255 OID 116794)
-- Dependencies: 46
-- Name: next_item_type(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION next_item_type() RETURNS integer
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_next_item_type';


ALTER FUNCTION dbms_pipe.next_item_type() OWNER TO dberaldi;

--
-- TOC entry 3585 (class 0 OID 0)
-- Dependencies: 776
-- Name: FUNCTION next_item_type(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION next_item_type() IS 'Returns type of next field in message';


--
-- TOC entry 767 (class 1255 OID 116781)
-- Dependencies: 46
-- Name: pack_message(text); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_text';


ALTER FUNCTION dbms_pipe.pack_message(text) OWNER TO dberaldi;

--
-- TOC entry 3586 (class 0 OID 0)
-- Dependencies: 767
-- Name: FUNCTION pack_message(text); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(text) IS 'Add text field to message';


--
-- TOC entry 783 (class 1255 OID 116801)
-- Dependencies: 46
-- Name: pack_message(date); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(date) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_date';


ALTER FUNCTION dbms_pipe.pack_message(date) OWNER TO dberaldi;

--
-- TOC entry 3587 (class 0 OID 0)
-- Dependencies: 783
-- Name: FUNCTION pack_message(date); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(date) IS 'Add date field to message';


--
-- TOC entry 785 (class 1255 OID 116803)
-- Dependencies: 46
-- Name: pack_message(timestamp with time zone); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(timestamp with time zone) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_timestamp';


ALTER FUNCTION dbms_pipe.pack_message(timestamp with time zone) OWNER TO dberaldi;

--
-- TOC entry 3588 (class 0 OID 0)
-- Dependencies: 785
-- Name: FUNCTION pack_message(timestamp with time zone); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(timestamp with time zone) IS 'Add timestamp field to message';


--
-- TOC entry 787 (class 1255 OID 116805)
-- Dependencies: 46
-- Name: pack_message(numeric); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(numeric) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_number';


ALTER FUNCTION dbms_pipe.pack_message(numeric) OWNER TO dberaldi;

--
-- TOC entry 3589 (class 0 OID 0)
-- Dependencies: 787
-- Name: FUNCTION pack_message(numeric); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(numeric) IS 'Add numeric field to message';


--
-- TOC entry 789 (class 1255 OID 116807)
-- Dependencies: 46
-- Name: pack_message(integer); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(integer) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_integer';


ALTER FUNCTION dbms_pipe.pack_message(integer) OWNER TO dberaldi;

--
-- TOC entry 3590 (class 0 OID 0)
-- Dependencies: 789
-- Name: FUNCTION pack_message(integer); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(integer) IS 'Add numeric field to message';


--
-- TOC entry 790 (class 1255 OID 116808)
-- Dependencies: 46
-- Name: pack_message(bigint); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(bigint) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_bigint';


ALTER FUNCTION dbms_pipe.pack_message(bigint) OWNER TO dberaldi;

--
-- TOC entry 3591 (class 0 OID 0)
-- Dependencies: 790
-- Name: FUNCTION pack_message(bigint); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(bigint) IS 'Add numeric field to message';


--
-- TOC entry 791 (class 1255 OID 116809)
-- Dependencies: 46
-- Name: pack_message(bytea); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(bytea) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_bytea';


ALTER FUNCTION dbms_pipe.pack_message(bytea) OWNER TO dberaldi;

--
-- TOC entry 3592 (class 0 OID 0)
-- Dependencies: 791
-- Name: FUNCTION pack_message(bytea); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(bytea) IS 'Add bytea field to message';


--
-- TOC entry 793 (class 1255 OID 116811)
-- Dependencies: 46
-- Name: pack_message(record); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION pack_message(record) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_pack_message_record';


ALTER FUNCTION dbms_pipe.pack_message(record) OWNER TO dberaldi;

--
-- TOC entry 3593 (class 0 OID 0)
-- Dependencies: 793
-- Name: FUNCTION pack_message(record); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION pack_message(record) IS 'Add record field to message';


--
-- TOC entry 781 (class 1255 OID 116799)
-- Dependencies: 46
-- Name: purge(text); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION purge(text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_purge';


ALTER FUNCTION dbms_pipe.purge(text) OWNER TO dberaldi;

--
-- TOC entry 3594 (class 0 OID 0)
-- Dependencies: 781
-- Name: FUNCTION purge(text); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION purge(text) IS 'Clean pipe';


--
-- TOC entry 770 (class 1255 OID 116784)
-- Dependencies: 46
-- Name: receive_message(text); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION receive_message(text) RETURNS integer
    LANGUAGE sql
    AS $_$SELECT dbms_pipe.receive_message($1,NULL::int);$_$;


ALTER FUNCTION dbms_pipe.receive_message(text) OWNER TO dberaldi;

--
-- TOC entry 3595 (class 0 OID 0)
-- Dependencies: 770
-- Name: FUNCTION receive_message(text); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION receive_message(text) IS 'Receive message from pipe';


--
-- TOC entry 769 (class 1255 OID 116783)
-- Dependencies: 46
-- Name: receive_message(text, integer); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION receive_message(text, integer) RETURNS integer
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_pipe_receive_message';


ALTER FUNCTION dbms_pipe.receive_message(text, integer) OWNER TO dberaldi;

--
-- TOC entry 3596 (class 0 OID 0)
-- Dependencies: 769
-- Name: FUNCTION receive_message(text, integer); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION receive_message(text, integer) IS 'Receive message from pipe';


--
-- TOC entry 782 (class 1255 OID 116800)
-- Dependencies: 46
-- Name: remove_pipe(text); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION remove_pipe(text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_remove_pipe';


ALTER FUNCTION dbms_pipe.remove_pipe(text) OWNER TO dberaldi;

--
-- TOC entry 3597 (class 0 OID 0)
-- Dependencies: 782
-- Name: FUNCTION remove_pipe(text); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION remove_pipe(text) IS 'Destroy pipe';


--
-- TOC entry 780 (class 1255 OID 116798)
-- Dependencies: 46
-- Name: reset_buffer(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION reset_buffer() RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_pipe_reset_buffer';


ALTER FUNCTION dbms_pipe.reset_buffer() OWNER TO dberaldi;

--
-- TOC entry 3598 (class 0 OID 0)
-- Dependencies: 780
-- Name: FUNCTION reset_buffer(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION reset_buffer() IS 'Clean input buffer';


--
-- TOC entry 773 (class 1255 OID 116787)
-- Dependencies: 46
-- Name: send_message(text); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION send_message(text) RETURNS integer
    LANGUAGE sql
    AS $_$SELECT dbms_pipe.send_message($1,NULL,NULL);$_$;


ALTER FUNCTION dbms_pipe.send_message(text) OWNER TO dberaldi;

--
-- TOC entry 3599 (class 0 OID 0)
-- Dependencies: 773
-- Name: FUNCTION send_message(text); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION send_message(text) IS 'Send message to pipe';


--
-- TOC entry 772 (class 1255 OID 116786)
-- Dependencies: 46
-- Name: send_message(text, integer); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION send_message(text, integer) RETURNS integer
    LANGUAGE sql
    AS $_$SELECT dbms_pipe.send_message($1,$2,NULL);$_$;


ALTER FUNCTION dbms_pipe.send_message(text, integer) OWNER TO dberaldi;

--
-- TOC entry 3600 (class 0 OID 0)
-- Dependencies: 772
-- Name: FUNCTION send_message(text, integer); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION send_message(text, integer) IS 'Send message to pipe';


--
-- TOC entry 771 (class 1255 OID 116785)
-- Dependencies: 46
-- Name: send_message(text, integer, integer); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION send_message(text, integer, integer) RETURNS integer
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_pipe_send_message';


ALTER FUNCTION dbms_pipe.send_message(text, integer, integer) OWNER TO dberaldi;

--
-- TOC entry 3601 (class 0 OID 0)
-- Dependencies: 771
-- Name: FUNCTION send_message(text, integer, integer); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION send_message(text, integer, integer) IS 'Send message to pipe';


--
-- TOC entry 774 (class 1255 OID 116788)
-- Dependencies: 46
-- Name: unique_session_name(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION unique_session_name() RETURNS character varying
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_unique_session_name';


ALTER FUNCTION dbms_pipe.unique_session_name() OWNER TO dberaldi;

--
-- TOC entry 3602 (class 0 OID 0)
-- Dependencies: 774
-- Name: FUNCTION unique_session_name(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION unique_session_name() IS 'Returns unique session name';


--
-- TOC entry 792 (class 1255 OID 116810)
-- Dependencies: 46
-- Name: unpack_message_bytea(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION unpack_message_bytea() RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_unpack_message_bytea';


ALTER FUNCTION dbms_pipe.unpack_message_bytea() OWNER TO dberaldi;

--
-- TOC entry 3603 (class 0 OID 0)
-- Dependencies: 792
-- Name: FUNCTION unpack_message_bytea(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION unpack_message_bytea() IS 'Get bytea field from message';


--
-- TOC entry 784 (class 1255 OID 116802)
-- Dependencies: 46
-- Name: unpack_message_date(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION unpack_message_date() RETURNS date
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_unpack_message_date';


ALTER FUNCTION dbms_pipe.unpack_message_date() OWNER TO dberaldi;

--
-- TOC entry 3604 (class 0 OID 0)
-- Dependencies: 784
-- Name: FUNCTION unpack_message_date(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION unpack_message_date() IS 'Get date field from message';


--
-- TOC entry 788 (class 1255 OID 116806)
-- Dependencies: 46
-- Name: unpack_message_number(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION unpack_message_number() RETURNS numeric
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_unpack_message_number';


ALTER FUNCTION dbms_pipe.unpack_message_number() OWNER TO dberaldi;

--
-- TOC entry 3605 (class 0 OID 0)
-- Dependencies: 788
-- Name: FUNCTION unpack_message_number(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION unpack_message_number() IS 'Get numeric field from message';


--
-- TOC entry 794 (class 1255 OID 116812)
-- Dependencies: 46
-- Name: unpack_message_record(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION unpack_message_record() RETURNS record
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_unpack_message_record';


ALTER FUNCTION dbms_pipe.unpack_message_record() OWNER TO dberaldi;

--
-- TOC entry 3606 (class 0 OID 0)
-- Dependencies: 794
-- Name: FUNCTION unpack_message_record(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION unpack_message_record() IS 'Get record field from message';


--
-- TOC entry 768 (class 1255 OID 116782)
-- Dependencies: 46
-- Name: unpack_message_text(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION unpack_message_text() RETURNS text
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_pipe_unpack_message_text';


ALTER FUNCTION dbms_pipe.unpack_message_text() OWNER TO dberaldi;

--
-- TOC entry 3607 (class 0 OID 0)
-- Dependencies: 768
-- Name: FUNCTION unpack_message_text(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION unpack_message_text() IS 'Get text fiedl from message';


--
-- TOC entry 786 (class 1255 OID 116804)
-- Dependencies: 46
-- Name: unpack_message_timestamp(); Type: FUNCTION; Schema: dbms_pipe; Owner: dberaldi
--

CREATE FUNCTION unpack_message_timestamp() RETURNS timestamp with time zone
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_pipe_unpack_message_timestamp';


ALTER FUNCTION dbms_pipe.unpack_message_timestamp() OWNER TO dberaldi;

--
-- TOC entry 3608 (class 0 OID 0)
-- Dependencies: 786
-- Name: FUNCTION unpack_message_timestamp(); Type: COMMENT; Schema: dbms_pipe; Owner: dberaldi
--

COMMENT ON FUNCTION unpack_message_timestamp() IS 'Get timestamp field from message';


SET search_path = dbms_random, pg_catalog;

--
-- TOC entry 657 (class 1255 OID 116980)
-- Dependencies: 58
-- Name: initialize(integer); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION initialize(integer) RETURNS void
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'dbms_random_initialize';


ALTER FUNCTION dbms_random.initialize(integer) OWNER TO dberaldi;

--
-- TOC entry 3609 (class 0 OID 0)
-- Dependencies: 657
-- Name: FUNCTION initialize(integer); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION initialize(integer) IS 'Initialize package with a seed value';


--
-- TOC entry 658 (class 1255 OID 116981)
-- Dependencies: 58
-- Name: normal(); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION normal() RETURNS double precision
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_random_normal';


ALTER FUNCTION dbms_random.normal() OWNER TO dberaldi;

--
-- TOC entry 3610 (class 0 OID 0)
-- Dependencies: 658
-- Name: FUNCTION normal(); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION normal() IS 'Returns random numbers in a standard normal distribution';


--
-- TOC entry 659 (class 1255 OID 116982)
-- Dependencies: 58
-- Name: random(); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION random() RETURNS integer
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_random_random';


ALTER FUNCTION dbms_random.random() OWNER TO dberaldi;

--
-- TOC entry 3611 (class 0 OID 0)
-- Dependencies: 659
-- Name: FUNCTION random(); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION random() IS 'Generate Random Numeric Values';


--
-- TOC entry 660 (class 1255 OID 116983)
-- Dependencies: 58
-- Name: seed(integer); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION seed(integer) RETURNS void
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'dbms_random_seed_int';


ALTER FUNCTION dbms_random.seed(integer) OWNER TO dberaldi;

--
-- TOC entry 3612 (class 0 OID 0)
-- Dependencies: 660
-- Name: FUNCTION seed(integer); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION seed(integer) IS 'Reset the seed value';


--
-- TOC entry 661 (class 1255 OID 116984)
-- Dependencies: 58
-- Name: seed(text); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION seed(text) RETURNS void
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'dbms_random_seed_varchar';


ALTER FUNCTION dbms_random.seed(text) OWNER TO dberaldi;

--
-- TOC entry 3613 (class 0 OID 0)
-- Dependencies: 661
-- Name: FUNCTION seed(text); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION seed(text) IS 'Reset the seed value';


--
-- TOC entry 662 (class 1255 OID 116985)
-- Dependencies: 58
-- Name: string(text, integer); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION string(opt text, len integer) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_random_string';


ALTER FUNCTION dbms_random.string(opt text, len integer) OWNER TO dberaldi;

--
-- TOC entry 3614 (class 0 OID 0)
-- Dependencies: 662
-- Name: FUNCTION string(opt text, len integer); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION string(opt text, len integer) IS 'Create Random Strings';


--
-- TOC entry 663 (class 1255 OID 116986)
-- Dependencies: 58
-- Name: terminate(); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION terminate() RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'dbms_random_terminate';


ALTER FUNCTION dbms_random.terminate() OWNER TO dberaldi;

--
-- TOC entry 3615 (class 0 OID 0)
-- Dependencies: 663
-- Name: FUNCTION terminate(); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION terminate() IS 'Terminate use of the Package';


--
-- TOC entry 665 (class 1255 OID 116988)
-- Dependencies: 58
-- Name: value(); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION value() RETURNS double precision
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_random_value';


ALTER FUNCTION dbms_random.value() OWNER TO dberaldi;

--
-- TOC entry 3616 (class 0 OID 0)
-- Dependencies: 665
-- Name: FUNCTION value(); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION value() IS 'Generate Random number x, where x is greather or equal to 0 and less then 1';


--
-- TOC entry 664 (class 1255 OID 116987)
-- Dependencies: 58
-- Name: value(double precision, double precision); Type: FUNCTION; Schema: dbms_random; Owner: dberaldi
--

CREATE FUNCTION value(low double precision, high double precision) RETURNS double precision
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_random_value_range';


ALTER FUNCTION dbms_random.value(low double precision, high double precision) OWNER TO dberaldi;

--
-- TOC entry 3617 (class 0 OID 0)
-- Dependencies: 664
-- Name: FUNCTION value(low double precision, high double precision); Type: COMMENT; Schema: dbms_random; Owner: dberaldi
--

COMMENT ON FUNCTION value(low double precision, high double precision) IS 'Generate Random number x, where x is greather or equal to low and less then high';


SET search_path = dbms_utility, pg_catalog;

--
-- TOC entry 600 (class 1255 OID 116910)
-- Dependencies: 53
-- Name: format_call_stack(); Type: FUNCTION; Schema: dbms_utility; Owner: dberaldi
--

CREATE FUNCTION format_call_stack() RETURNS text
    LANGUAGE c
    AS '$libdir/orafunc', 'dbms_utility_format_call_stack0';


ALTER FUNCTION dbms_utility.format_call_stack() OWNER TO dberaldi;

--
-- TOC entry 3618 (class 0 OID 0)
-- Dependencies: 600
-- Name: FUNCTION format_call_stack(); Type: COMMENT; Schema: dbms_utility; Owner: dberaldi
--

COMMENT ON FUNCTION format_call_stack() IS 'Return formated call stack';


--
-- TOC entry 599 (class 1255 OID 116909)
-- Dependencies: 53
-- Name: format_call_stack(text); Type: FUNCTION; Schema: dbms_utility; Owner: dberaldi
--

CREATE FUNCTION format_call_stack(text) RETURNS text
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'dbms_utility_format_call_stack1';


ALTER FUNCTION dbms_utility.format_call_stack(text) OWNER TO dberaldi;

--
-- TOC entry 3619 (class 0 OID 0)
-- Dependencies: 599
-- Name: FUNCTION format_call_stack(text); Type: COMMENT; Schema: dbms_utility; Owner: dberaldi
--

COMMENT ON FUNCTION format_call_stack(text) IS 'Return formated call stack';


SET search_path = main, pg_catalog;

--
-- TOC entry 869 (class 1255 OID 33744)
-- Dependencies: 1589 7
-- Name: create_crosstab_project_designs(); Type: FUNCTION; Schema: main; Owner: dberaldi
--

CREATE FUNCTION create_crosstab_project_designs() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
    declare 
        sqlstring text;
        sqlcounter text;
        nrows int;
        row_project projects%ROWTYPE; -- Name of the project
        ct_project text; -- Name of cross tab table produced from exp_design
        view_project text; -- Name for final view
    begin
    set search_path to materialized_views, main, public, django_admin; -- This will create the matview in the proper schema
    for row_project in select distinct project from projects where is_deprecated is False
        loop
        /* MEMO: Each table joined in triggered function must have a trigger associated 
         otherwise the cross-tabs will be outdated !!*/
            ct_project := 'exp_design_' || row_project.project;
            view_project := 'view_' || row_project.project;
            sqlstring := 'select distinct 
                                 project_samples.project,
                                 exp_design.sample_id,
                                 exp_design.s_variable, -- For cross_tab: This must be second last column 
                                 exp_design.s_value     -- For cross_tab: This must be last column
                          from exp_design inner join project_samples on exp_design.sample_id = project_samples.sample_id 
                          where project_samples.project = ' || quote_literal(row_project.project);
            sqlcounter := 'select count(*) from (' || sqlstring || ') as t';
            execute sqlcounter into nrows;
            if nrows > 0 then
                perform cross_tab(sqlstring, ct_project, False, True, cascade := True);
                execute 'alter table ' || quote_ident(ct_project) || ' add column id serial';
                execute 'comment on table ' || quote_ident(ct_project) || $$ is 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)'$$;
                execute 'drop view if exists ' || quote_ident(view_project) || ' cascade;';
                execute 'create view ' || quote_ident(view_project) || ' as(
                     select distinct ' || quote_ident(ct_project) || '.*,
                         samples.organism,
                         samples.source_name,
                         samples.molecule,
                         libraries.library_id,
                         libraries.library_type
                     from ' || quote_ident(ct_project) || ' inner join samples on samples.sample_id = ' || quote_ident(ct_project) || '.sample_id
                     left join libraries on libraries.sample_id = samples.sample_id)';
                execute 'comment on view ' || quote_ident(view_project) || $$ is 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)'$$;
            end if;
         end loop;
    return null;
    end;
    $_$;


ALTER FUNCTION main.create_crosstab_project_designs() OWNER TO dberaldi;

--
-- TOC entry 681 (class 1255 OID 256482)
-- Dependencies: 7 1589
-- Name: fastqfile_startswith_library_id(); Type: FUNCTION; Schema: main; Owner: dberaldi
--

CREATE FUNCTION fastqfile_startswith_library_id() RETURNS trigger
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    DECLARE 
    invalid_fastqfile text[]; -- This variable will store output of queries cheking for invalid library_id. It must remain NULL for valid IDs;
    
    BEGIN

    SELECT array[fastqfiles.fastqfile, fastqfiles.library_id] INTO invalid_fastqfile FROM fastqfiles
    WHERE get_library_id(fastqfile) != fastqfiles.library_id OR get_library_id(fastqfile) is null;
    
    IF invalid_fastqfile IS NOT NULL THEN
        RAISE EXCEPTION 'Trigger fastqfile_startswith_library_id: Invalid name for fastqfile:
"%" should begin with the name of the assigned library_id "%"', invalid_fastqfile[1], invalid_fastqfile[2];
        RETURN NULL;
    END IF;

    RETURN NULL;
    END;
$$;


ALTER FUNCTION main.fastqfile_startswith_library_id() OWNER TO dberaldi;

--
-- TOC entry 591 (class 1255 OID 26845)
-- Dependencies: 1590 7
-- Name: read_fasta(text, text); Type: FUNCTION; Schema: main; Owner: dberaldi
--

CREATE FUNCTION read_fasta(file text, dest_table text) RETURNS text
    LANGUAGE plpython3u IMMUTABLE
    AS $$

"""
DESCRIPTION:
Reads the fasta file 'file' and imports the content to table 'dest_table'.
dest_table has two columns: sequence_name and sequence.
read_fasta starts importing when the first line beginning with '>' is found.
Blank or comment lines at the beginning of the file are therefore allowed and
skipped. Blank lines interspersed in the file (e.g. separarting sequences) are
also allowed and skipped.
The '>' character is removed from the sequence name after importing.

read_fasta is written in plpythonu. Adjust the connection parameters as appropriate.

EXAMPLE:
select read_fasta('C:/Tritume/writefasta.fa', 'tmp_test_read_fasta');
"""

import psycopg2
import os
import tempfile

" ---------------------------------[ Connect to database]-------------------- "
try:
    conn = psycopg2.connect("dbname='sblab' user='dberaldi' host='localhost' password='isa'");
except:
    return("I am unable to connect to the database")
" --------------------------------------------------------------------------- "

cur = conn.cursor()

qry_fasta_table= 'CREATE TABLE ' + dest_table + ' (sequence_name text, sequence text)'
cur.execute(qry_fasta_table)
conn.commit()

infile= open(file, 'r')
output= os.path.join(tempfile.gettempdir(), 'pg_read_fasta.tmp') ## file + '.tmp'
output= output.replace('\\', '/')
outfile= open(output, 'w')

nseq= 0
line_stack= ''
line= []
while True:
    line= infile.readline()
    if line.startswith('>'):
        line= line[1:]
        line= line.strip()
        title= line
        nseq += 1
        break
    elif line == '':
        break

for line in infile:
    line= line.strip()
    if line.startswith('>'):
        line= line[1:]
        outfile.write(title + '\t' + line_stack + '\n')
        title= line
        nseq += 1
        line_stack= ''
    else:
        line_stack= line_stack + line
outfile.write(title + '\t' + line_stack + '\n')

infile.close()
outfile.close()

qry_read_file= "COPY " + dest_table + " FROM E'" + output + "' WITH CSV DELIMITER E'\t'"
cur.execute(qry_read_file)
conn.commit()

os.remove(output)
return(str(nseq) + ' Sequences read and imported with:\n' + qry_read_file)

$$;


ALTER FUNCTION main.read_fasta(file text, dest_table text) OWNER TO dberaldi;

--
-- TOC entry 683 (class 1255 OID 152039)
-- Dependencies: 7 1590
-- Name: read_fastq(text, text); Type: FUNCTION; Schema: main; Owner: dberaldi
--

CREATE FUNCTION read_fastq(fastq_file text, dest_table text) RETURNS void
    LANGUAGE plpython3u
    AS $$

"""

Imports a FASTQ file (fastq_file) into a new table (dest_table). The four
lines of each fastq read are converted to a single line in dest_table.

read_fastq first converts the FASTQ file to a tabular format (4-line bloc
to a single line) and then import this formatted file to the database.

USAGE:
SELECT read_fastq('C:/Tritume/s_7_1_sequence.txt.filtered', 'tmp_pe_1');

"""

import psycopg2
import os

# ----------------------------[ Connect to database ]--------------------------

conn = psycopg2.connect("""dbname='sblab' user='dberaldi' \
    host='localhost' password='isa'""")

cur_modify= conn.cursor()

# -----------------------------------------------------------------------------

fastq = open(fastq_file, 'r')

## Temporary file with FASTQ in tab format
fastq_file_tab = fastq_file + '.tmp'
tmp_outfile = open(fastq_file_tab, 'w')

fastq_read = list()

counter = 1 ## This counter used to convert each read (4 lines) to a list

# -------------------------[ Convert FASTQ to tabular ]------------------------
while 1:
    while counter <= 4:
            fastq_line = (fastq.readline()).rstrip('\n')
            fastq_read.append(fastq_line)
            counter += 1
    counter = 1

    if fastq_line == '': ## Break when empty line is found
        break
       
    tmp_outfile.write('\t'.join(fastq_read) + '\n')

    fastq_read = list()

fastq.close()
tmp_outfile.close()

# -------------------[ Import tabular FASTQ ]----------------------------------

cur_modify.execute(""" CREATE TABLE %(dest_table)s (
  read_name character varying(80),
  read_sequence character varying(80),
  description character varying(80),
  quality character varying(80)
  )
  """ %{'dest_table':dest_table})

cur_modify.execute( """
  COPY %(dest_table)s
  FROM %(fastq_file_tab)s
  WITH CSV DELIMITER E'\t'
  """ %{'dest_table':dest_table, 'fastq_file_tab' : "'" + fastq_file_tab + "'"})

os.remove(fastq_file_tab) ## Remove tabular FASTQ
     
#------------------------------------------------------------------------------

conn.commit()

$$;


ALTER FUNCTION main.read_fastq(fastq_file text, dest_table text) OWNER TO dberaldi;

--
-- TOC entry 870 (class 1255 OID 32428)
-- Dependencies: 1589 7
-- Name: update_crosstab_exp_design(); Type: FUNCTION; Schema: main; Owner: dberaldi
--

CREATE FUNCTION update_crosstab_exp_design() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    begin
    set search_path to materialized_views, main, public, django_admin; -- This will create the matview in the proper schema

    drop table if exists materialized_views.exp_design_samples cascade;
    perform cross_tab(' 
        select distinct
            exp_design.sample_id,
            exp_design.s_variable, -- For cross_tab: This must be second last column
            exp_design.s_value     -- For cross_tab: This must be last column
        from exp_design 
        left join project_samples on exp_design.sample_id = project_samples.sample_id
        inner join samples on exp_design.sample_id = samples.sample_id
        left join libraries on samples.sample_id = libraries.sample_id
        ', 'exp_design_samples', temp := False, overwrite := True, cascade := True);

    alter table exp_design_samples add column id serial;
    
    drop view if exists view_exp_design_samples;
    create view materialized_views.view_exp_design_samples AS(
                 select distinct 
                     exp_design_samples.*,
                     samples.organism,
                     samples.source_name,
                     samples.molecule,
                     libraries.library_id,
                     libraries.library_type
                 from exp_design_samples inner join samples on exp_design_samples.sample_id = samples.sample_id
                 left join libraries on libraries.sample_id = samples.sample_id);
    comment on view materialized_views.view_exp_design_samples is 'Table created by procedure main.update_crosstab_exp_design() triggered by "trigger_crosstab_exp_design" on update/insert/delete on table exp_design. Do not modify this table directly.';
    return null;
    end;
    $$;


ALTER FUNCTION main.update_crosstab_exp_design() OWNER TO dberaldi;

--
-- TOC entry 682 (class 1255 OID 249140)
-- Dependencies: 7 1589
-- Name: validate_library_id(); Type: FUNCTION; Schema: main; Owner: dberaldi
--

CREATE FUNCTION validate_library_id() RETURNS trigger
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
    DECLARE 
    invalid_library_id text; -- This variable will store output of queries cheking for invalid library_id. It must remain NULL for valid IDs;
    
    BEGIN

    -- library_id must contain only letters, numbers and  underscore.
    SELECT library_id INTO invalid_library_id FROM libraries WHERE library_id !~ '^[a-zA-Z][a-zA-Z0-9_\-]+$'; -- 05/08/2015 was: (^[a-zA-Z]\w+[a-zA-Z0-9]$)
    
    IF invalid_library_id IS NOT NULL THEN
        RAISE EXCEPTION 'Trigger validate_library_id: Invalid library_id format: "%". See validate_library_id()', invalid_library_id;
        RETURN NULL;
    END IF;
    RETURN NULL;
    -- Get possible sample_ids whose initials are not in contacts or are not capitalized.     
    END;
$_$;


ALTER FUNCTION main.validate_library_id() OWNER TO dberaldi;

--
-- TOC entry 871 (class 1255 OID 243748)
-- Dependencies: 7 1589
-- Name: validate_sample_id(); Type: FUNCTION; Schema: main; Owner: dberaldi
--

CREATE FUNCTION validate_sample_id() RETURNS trigger
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
    DECLARE 
    invalid_sample_id text; -- This variable will store output of queries cheking for invalid sample_id. It must remain NULL for valid IDs;
    
    BEGIN
    
    -- Get possible sample_ids whose initials are not in contacts or are not capitalized.     
    SELECT samples.sample_id INTO invalid_sample_id
    FROM samples LEFT JOIN contacts ON
    upper(contacts.initials) = upper(regexp_replace(samples.sample_id, '\d{1,}.*', '')) -- regexp to extract the initials.
    WHERE upper(contacts.initials) IS NULL
    LIMIT 1;

    IF invalid_sample_id IS NOT NULL THEN
        RAISE EXCEPTION 'Trigger validate_sample_id: sample_id "%" seems to start with initials not found in table contacts.initials or initials not capitalized', invalid_sample_id;
        RETURN NULL;
    END IF;

    -- Check if sample_ids are composed by two or more letters followed by 3 or more digits possibly followed by _ and only digit and letters.
    -- Changed on 19/11/2013: Initials are no longer case sensitive.
    SELECT samples.sample_id INTO invalid_sample_id
    FROM samples WHERE sample_id !~ '(^[a-zA-Z]{2,}[0-9]{3,}$)|([a-zA-Z]{2,}[0-9]{3,}_[a-zA-Z0-9_\-]+$)';

    IF invalid_sample_id IS NOT NULL THEN
        RAISE EXCEPTION 'Trigger validate_sample_id: sample_id "%" seems to be badly formatted. Allowed format must match the regexp in validate_sample_id()', invalid_sample_id;
        RETURN NULL;
    END IF;
    RETURN NULL;    
    END;
$_$;


ALTER FUNCTION main.validate_sample_id() OWNER TO dberaldi;

SET search_path = oracle, pg_catalog;

--
-- TOC entry 700 (class 1255 OID 116708)
-- Dependencies: 43
-- Name: substr(text, integer); Type: FUNCTION; Schema: oracle; Owner: dberaldi
--

CREATE FUNCTION substr(str text, start integer) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'oracle_substr2';


ALTER FUNCTION oracle.substr(str text, start integer) OWNER TO dberaldi;

--
-- TOC entry 3620 (class 0 OID 0)
-- Dependencies: 700
-- Name: FUNCTION substr(str text, start integer); Type: COMMENT; Schema: oracle; Owner: dberaldi
--

COMMENT ON FUNCTION substr(str text, start integer) IS 'Returns substring started on start_in to end';


--
-- TOC entry 701 (class 1255 OID 116709)
-- Dependencies: 43
-- Name: substr(text, integer, integer); Type: FUNCTION; Schema: oracle; Owner: dberaldi
--

CREATE FUNCTION substr(str text, start integer, len integer) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'oracle_substr3';


ALTER FUNCTION oracle.substr(str text, start integer, len integer) OWNER TO dberaldi;

--
-- TOC entry 3621 (class 0 OID 0)
-- Dependencies: 701
-- Name: FUNCTION substr(str text, start integer, len integer); Type: COMMENT; Schema: oracle; Owner: dberaldi
--

COMMENT ON FUNCTION substr(str text, start integer, len integer) IS 'Returns substring started on start_in len chars';


SET search_path = plunit, pg_catalog;

--
-- TOC entry 647 (class 1255 OID 116969)
-- Dependencies: 44
-- Name: assert_equals(anyelement, anyelement); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_equals(expected anyelement, actual anyelement) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_equals';


ALTER FUNCTION plunit.assert_equals(expected anyelement, actual anyelement) OWNER TO dberaldi;

--
-- TOC entry 3622 (class 0 OID 0)
-- Dependencies: 647
-- Name: FUNCTION assert_equals(expected anyelement, actual anyelement); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_equals(expected anyelement, actual anyelement) IS 'Asserts that expected and actual are equal';


--
-- TOC entry 648 (class 1255 OID 116970)
-- Dependencies: 44
-- Name: assert_equals(anyelement, anyelement, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_equals(expected anyelement, actual anyelement, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_equals_message';


ALTER FUNCTION plunit.assert_equals(expected anyelement, actual anyelement, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3623 (class 0 OID 0)
-- Dependencies: 648
-- Name: FUNCTION assert_equals(expected anyelement, actual anyelement, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_equals(expected anyelement, actual anyelement, message character varying) IS 'Asserts that expected and actual are equal';


--
-- TOC entry 649 (class 1255 OID 116971)
-- Dependencies: 44
-- Name: assert_equals(double precision, double precision, double precision); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_equals(expected double precision, actual double precision, range double precision) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_equals_range';


ALTER FUNCTION plunit.assert_equals(expected double precision, actual double precision, range double precision) OWNER TO dberaldi;

--
-- TOC entry 3624 (class 0 OID 0)
-- Dependencies: 649
-- Name: FUNCTION assert_equals(expected double precision, actual double precision, range double precision); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_equals(expected double precision, actual double precision, range double precision) IS 'Asserts that expected and actual are equal';


--
-- TOC entry 650 (class 1255 OID 116972)
-- Dependencies: 44
-- Name: assert_equals(double precision, double precision, double precision, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_equals(expected double precision, actual double precision, range double precision, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_equals_range_message';


ALTER FUNCTION plunit.assert_equals(expected double precision, actual double precision, range double precision, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3625 (class 0 OID 0)
-- Dependencies: 650
-- Name: FUNCTION assert_equals(expected double precision, actual double precision, range double precision, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_equals(expected double precision, actual double precision, range double precision, message character varying) IS 'Asserts that expected and actual are equal';


--
-- TOC entry 641 (class 1255 OID 116963)
-- Dependencies: 44
-- Name: assert_false(boolean); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_false(condition boolean) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_false';


ALTER FUNCTION plunit.assert_false(condition boolean) OWNER TO dberaldi;

--
-- TOC entry 3626 (class 0 OID 0)
-- Dependencies: 641
-- Name: FUNCTION assert_false(condition boolean); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_false(condition boolean) IS 'Asserts that the condition is false';


--
-- TOC entry 642 (class 1255 OID 116964)
-- Dependencies: 44
-- Name: assert_false(boolean, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_false(condition boolean, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_false_message';


ALTER FUNCTION plunit.assert_false(condition boolean, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3627 (class 0 OID 0)
-- Dependencies: 642
-- Name: FUNCTION assert_false(condition boolean, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_false(condition boolean, message character varying) IS 'Asserts that the condition is false';


--
-- TOC entry 651 (class 1255 OID 116973)
-- Dependencies: 44
-- Name: assert_not_equals(anyelement, anyelement); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_not_equals(expected anyelement, actual anyelement) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_not_equals';


ALTER FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement) OWNER TO dberaldi;

--
-- TOC entry 3628 (class 0 OID 0)
-- Dependencies: 651
-- Name: FUNCTION assert_not_equals(expected anyelement, actual anyelement); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_not_equals(expected anyelement, actual anyelement) IS 'Asserts that expected and actual are equal';


--
-- TOC entry 652 (class 1255 OID 116974)
-- Dependencies: 44
-- Name: assert_not_equals(anyelement, anyelement, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_not_equals(expected anyelement, actual anyelement, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_not_equals_message';


ALTER FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3629 (class 0 OID 0)
-- Dependencies: 652
-- Name: FUNCTION assert_not_equals(expected anyelement, actual anyelement, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_not_equals(expected anyelement, actual anyelement, message character varying) IS 'Asserts that expected and actual are equal';


--
-- TOC entry 653 (class 1255 OID 116975)
-- Dependencies: 44
-- Name: assert_not_equals(double precision, double precision, double precision); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_not_equals(expected double precision, actual double precision, range double precision) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_not_equals_range';


ALTER FUNCTION plunit.assert_not_equals(expected double precision, actual double precision, range double precision) OWNER TO dberaldi;

--
-- TOC entry 654 (class 1255 OID 116976)
-- Dependencies: 44
-- Name: assert_not_equals(double precision, double precision, double precision, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_not_equals(expected double precision, actual double precision, range double precision, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_not_equals_range_message';


ALTER FUNCTION plunit.assert_not_equals(expected double precision, actual double precision, range double precision, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3630 (class 0 OID 0)
-- Dependencies: 654
-- Name: FUNCTION assert_not_equals(expected double precision, actual double precision, range double precision, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_not_equals(expected double precision, actual double precision, range double precision, message character varying) IS 'Asserts that expected and actual are equal';


--
-- TOC entry 645 (class 1255 OID 116967)
-- Dependencies: 44
-- Name: assert_not_null(anyelement); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_not_null(actual anyelement) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_not_null';


ALTER FUNCTION plunit.assert_not_null(actual anyelement) OWNER TO dberaldi;

--
-- TOC entry 3631 (class 0 OID 0)
-- Dependencies: 645
-- Name: FUNCTION assert_not_null(actual anyelement); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_not_null(actual anyelement) IS 'Asserts that the actual is not null';


--
-- TOC entry 646 (class 1255 OID 116968)
-- Dependencies: 44
-- Name: assert_not_null(anyelement, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_not_null(actual anyelement, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_not_null_message';


ALTER FUNCTION plunit.assert_not_null(actual anyelement, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3632 (class 0 OID 0)
-- Dependencies: 646
-- Name: FUNCTION assert_not_null(actual anyelement, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_not_null(actual anyelement, message character varying) IS 'Asserts that the condition is not null';


--
-- TOC entry 643 (class 1255 OID 116965)
-- Dependencies: 44
-- Name: assert_null(anyelement); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_null(actual anyelement) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_null';


ALTER FUNCTION plunit.assert_null(actual anyelement) OWNER TO dberaldi;

--
-- TOC entry 3633 (class 0 OID 0)
-- Dependencies: 643
-- Name: FUNCTION assert_null(actual anyelement); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_null(actual anyelement) IS 'Asserts that the actual is null';


--
-- TOC entry 644 (class 1255 OID 116966)
-- Dependencies: 44
-- Name: assert_null(anyelement, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_null(actual anyelement, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_null_message';


ALTER FUNCTION plunit.assert_null(actual anyelement, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3634 (class 0 OID 0)
-- Dependencies: 644
-- Name: FUNCTION assert_null(actual anyelement, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_null(actual anyelement, message character varying) IS 'Asserts that the condition is null';


--
-- TOC entry 639 (class 1255 OID 116961)
-- Dependencies: 44
-- Name: assert_true(boolean); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_true(condition boolean) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_true';


ALTER FUNCTION plunit.assert_true(condition boolean) OWNER TO dberaldi;

--
-- TOC entry 3635 (class 0 OID 0)
-- Dependencies: 639
-- Name: FUNCTION assert_true(condition boolean); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_true(condition boolean) IS 'Asserts that the condition is true';


--
-- TOC entry 640 (class 1255 OID 116962)
-- Dependencies: 44
-- Name: assert_true(boolean, character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION assert_true(condition boolean, message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_assert_true_message';


ALTER FUNCTION plunit.assert_true(condition boolean, message character varying) OWNER TO dberaldi;

--
-- TOC entry 3636 (class 0 OID 0)
-- Dependencies: 640
-- Name: FUNCTION assert_true(condition boolean, message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION assert_true(condition boolean, message character varying) IS 'Asserts that the condition is true';


--
-- TOC entry 655 (class 1255 OID 116977)
-- Dependencies: 44
-- Name: fail(); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION fail() RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_fail';


ALTER FUNCTION plunit.fail() OWNER TO dberaldi;

--
-- TOC entry 3637 (class 0 OID 0)
-- Dependencies: 655
-- Name: FUNCTION fail(); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION fail() IS 'Immediately fail.';


--
-- TOC entry 656 (class 1255 OID 116978)
-- Dependencies: 44
-- Name: fail(character varying); Type: FUNCTION; Schema: plunit; Owner: dberaldi
--

CREATE FUNCTION fail(message character varying) RETURNS void
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plunit_fail_message';


ALTER FUNCTION plunit.fail(message character varying) OWNER TO dberaldi;

--
-- TOC entry 3638 (class 0 OID 0)
-- Dependencies: 656
-- Name: FUNCTION fail(message character varying); Type: COMMENT; Schema: plunit; Owner: dberaldi
--

COMMENT ON FUNCTION fail(message character varying) IS 'Immediately fail.';


SET search_path = plvchr, pg_catalog;

--
-- TOC entry 851 (class 1255 OID 116871)
-- Dependencies: 50
-- Name: _is_kind(text, integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION _is_kind(str text, kind integer) RETURNS boolean
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvchr_is_kind_a';


ALTER FUNCTION plvchr._is_kind(str text, kind integer) OWNER TO dberaldi;

--
-- TOC entry 852 (class 1255 OID 116872)
-- Dependencies: 50
-- Name: _is_kind(integer, integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION _is_kind(c integer, kind integer) RETURNS boolean
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvchr_is_kind_i';


ALTER FUNCTION plvchr._is_kind(c integer, kind integer) OWNER TO dberaldi;

--
-- TOC entry 863 (class 1255 OID 116883)
-- Dependencies: 50
-- Name: char_name(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION char_name(c text) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvchr_char_name';


ALTER FUNCTION plvchr.char_name(c text) OWNER TO dberaldi;

--
-- TOC entry 849 (class 1255 OID 116869)
-- Dependencies: 50
-- Name: first(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION first(str text) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvchr_first';


ALTER FUNCTION plvchr.first(str text) OWNER TO dberaldi;

--
-- TOC entry 3639 (class 0 OID 0)
-- Dependencies: 849
-- Name: FUNCTION first(str text); Type: COMMENT; Schema: plvchr; Owner: dberaldi
--

COMMENT ON FUNCTION first(str text) IS 'Call this function to return the first character in a string';


--
-- TOC entry 853 (class 1255 OID 116873)
-- Dependencies: 50
-- Name: is_blank(integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_blank(c integer) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 1);$_$;


ALTER FUNCTION plvchr.is_blank(c integer) OWNER TO dberaldi;

--
-- TOC entry 854 (class 1255 OID 116874)
-- Dependencies: 50
-- Name: is_blank(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_blank(c text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 1);$_$;


ALTER FUNCTION plvchr.is_blank(c text) OWNER TO dberaldi;

--
-- TOC entry 855 (class 1255 OID 116875)
-- Dependencies: 50
-- Name: is_digit(integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_digit(c integer) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 2);$_$;


ALTER FUNCTION plvchr.is_digit(c integer) OWNER TO dberaldi;

--
-- TOC entry 856 (class 1255 OID 116876)
-- Dependencies: 50
-- Name: is_digit(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_digit(c text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 2);$_$;


ALTER FUNCTION plvchr.is_digit(c text) OWNER TO dberaldi;

--
-- TOC entry 861 (class 1255 OID 116881)
-- Dependencies: 50
-- Name: is_letter(integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_letter(c integer) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 5);$_$;


ALTER FUNCTION plvchr.is_letter(c integer) OWNER TO dberaldi;

--
-- TOC entry 862 (class 1255 OID 116882)
-- Dependencies: 50
-- Name: is_letter(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_letter(c text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 5);$_$;


ALTER FUNCTION plvchr.is_letter(c text) OWNER TO dberaldi;

--
-- TOC entry 859 (class 1255 OID 116879)
-- Dependencies: 50
-- Name: is_other(integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_other(c integer) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 4);$_$;


ALTER FUNCTION plvchr.is_other(c integer) OWNER TO dberaldi;

--
-- TOC entry 860 (class 1255 OID 116880)
-- Dependencies: 50
-- Name: is_other(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_other(c text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 4);$_$;


ALTER FUNCTION plvchr.is_other(c text) OWNER TO dberaldi;

--
-- TOC entry 857 (class 1255 OID 116877)
-- Dependencies: 50
-- Name: is_quote(integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_quote(c integer) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 3);$_$;


ALTER FUNCTION plvchr.is_quote(c integer) OWNER TO dberaldi;

--
-- TOC entry 858 (class 1255 OID 116878)
-- Dependencies: 50
-- Name: is_quote(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION is_quote(c text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvchr._is_kind($1, 3);$_$;


ALTER FUNCTION plvchr.is_quote(c text) OWNER TO dberaldi;

--
-- TOC entry 850 (class 1255 OID 116870)
-- Dependencies: 50
-- Name: last(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION last(str text) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvchr_last';


ALTER FUNCTION plvchr.last(str text) OWNER TO dberaldi;

--
-- TOC entry 3640 (class 0 OID 0)
-- Dependencies: 850
-- Name: FUNCTION last(str text); Type: COMMENT; Schema: plvchr; Owner: dberaldi
--

COMMENT ON FUNCTION last(str text) IS 'Call this function to return the last character in a string';


--
-- TOC entry 848 (class 1255 OID 116868)
-- Dependencies: 50
-- Name: nth(text, integer); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION nth(str text, n integer) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvchr_nth';


ALTER FUNCTION plvchr.nth(str text, n integer) OWNER TO dberaldi;

--
-- TOC entry 3641 (class 0 OID 0)
-- Dependencies: 848
-- Name: FUNCTION nth(str text, n integer); Type: COMMENT; Schema: plvchr; Owner: dberaldi
--

COMMENT ON FUNCTION nth(str text, n integer) IS 'Call this function to return the Nth character in a string';


--
-- TOC entry 866 (class 1255 OID 116886)
-- Dependencies: 50
-- Name: quoted1(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION quoted1(str text) RETURNS character varying
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT ''''||$1||'''';$_$;


ALTER FUNCTION plvchr.quoted1(str text) OWNER TO dberaldi;

--
-- TOC entry 3642 (class 0 OID 0)
-- Dependencies: 866
-- Name: FUNCTION quoted1(str text); Type: COMMENT; Schema: plvchr; Owner: dberaldi
--

COMMENT ON FUNCTION quoted1(str text) IS 'Quoted text between ''';


--
-- TOC entry 867 (class 1255 OID 116887)
-- Dependencies: 50
-- Name: quoted2(text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION quoted2(str text) RETURNS character varying
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT '"'||$1||'"';$_$;


ALTER FUNCTION plvchr.quoted2(str text) OWNER TO dberaldi;

--
-- TOC entry 3643 (class 0 OID 0)
-- Dependencies: 867
-- Name: FUNCTION quoted2(str text); Type: COMMENT; Schema: plvchr; Owner: dberaldi
--

COMMENT ON FUNCTION quoted2(str text) IS 'Quoted text between "';


--
-- TOC entry 579 (class 1255 OID 116888)
-- Dependencies: 50
-- Name: stripped(text, text); Type: FUNCTION; Schema: plvchr; Owner: dberaldi
--

CREATE FUNCTION stripped(str text, char_in text) RETURNS character varying
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT TRANSLATE($1, 'A'||$2, 'A'); $_$;


ALTER FUNCTION plvchr.stripped(str text, char_in text) OWNER TO dberaldi;

--
-- TOC entry 3644 (class 0 OID 0)
-- Dependencies: 579
-- Name: FUNCTION stripped(str text, char_in text); Type: COMMENT; Schema: plvchr; Owner: dberaldi
--

COMMENT ON FUNCTION stripped(str text, char_in text) IS 'Strips a string of all instances of the specified characters';


SET search_path = plvdate, pg_catalog;

--
-- TOC entry 795 (class 1255 OID 116814)
-- Dependencies: 48
-- Name: add_bizdays(date, integer); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION add_bizdays(date, integer) RETURNS date
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvdate_add_bizdays';


ALTER FUNCTION plvdate.add_bizdays(date, integer) OWNER TO dberaldi;

--
-- TOC entry 3645 (class 0 OID 0)
-- Dependencies: 795
-- Name: FUNCTION add_bizdays(date, integer); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION add_bizdays(date, integer) IS 'Get the date created by adding <n> business days to a date';


--
-- TOC entry 798 (class 1255 OID 116817)
-- Dependencies: 48
-- Name: bizdays_between(date, date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION bizdays_between(date, date) RETURNS integer
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvdate_bizdays_between';


ALTER FUNCTION plvdate.bizdays_between(date, date) OWNER TO dberaldi;

--
-- TOC entry 3646 (class 0 OID 0)
-- Dependencies: 798
-- Name: FUNCTION bizdays_between(date, date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION bizdays_between(date, date) IS 'Get the number of business days between two dates';


--
-- TOC entry 817 (class 1255 OID 116836)
-- Dependencies: 48
-- Name: days_inmonth(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION days_inmonth(date) RETURNS integer
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_days_inmonth';


ALTER FUNCTION plvdate.days_inmonth(date) OWNER TO dberaldi;

--
-- TOC entry 3647 (class 0 OID 0)
-- Dependencies: 817
-- Name: FUNCTION days_inmonth(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION days_inmonth(date) IS 'Returns number of days in month';


--
-- TOC entry 816 (class 1255 OID 116835)
-- Dependencies: 48
-- Name: default_holidays(text); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION default_holidays(text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_default_holidays';


ALTER FUNCTION plvdate.default_holidays(text) OWNER TO dberaldi;

--
-- TOC entry 3648 (class 0 OID 0)
-- Dependencies: 816
-- Name: FUNCTION default_holidays(text); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION default_holidays(text) IS 'Load calendar for some nations';


--
-- TOC entry 812 (class 1255 OID 116831)
-- Dependencies: 48
-- Name: include_start(); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION include_start() RETURNS boolean
    LANGUAGE sql STRICT
    AS $$SELECT plvdate.include_start(true); SELECT NULL::boolean;$$;


ALTER FUNCTION plvdate.include_start() OWNER TO dberaldi;

--
-- TOC entry 811 (class 1255 OID 116830)
-- Dependencies: 48
-- Name: include_start(boolean); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION include_start(boolean) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_include_start';


ALTER FUNCTION plvdate.include_start(boolean) OWNER TO dberaldi;

--
-- TOC entry 3649 (class 0 OID 0)
-- Dependencies: 811
-- Name: FUNCTION include_start(boolean); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION include_start(boolean) IS 'Include starting date in bizdays_between calculation';


--
-- TOC entry 814 (class 1255 OID 116833)
-- Dependencies: 48
-- Name: including_start(); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION including_start() RETURNS boolean
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_including_start';


ALTER FUNCTION plvdate.including_start() OWNER TO dberaldi;

--
-- TOC entry 800 (class 1255 OID 116819)
-- Dependencies: 48
-- Name: isbizday(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION isbizday(date) RETURNS boolean
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvdate_isbizday';


ALTER FUNCTION plvdate.isbizday(date) OWNER TO dberaldi;

--
-- TOC entry 3650 (class 0 OID 0)
-- Dependencies: 800
-- Name: FUNCTION isbizday(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION isbizday(date) IS 'Call this function to determine if a date is a business day';


--
-- TOC entry 818 (class 1255 OID 116837)
-- Dependencies: 48
-- Name: isleapyear(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION isleapyear(date) RETURNS boolean
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_isleapyear';


ALTER FUNCTION plvdate.isleapyear(date) OWNER TO dberaldi;

--
-- TOC entry 3651 (class 0 OID 0)
-- Dependencies: 818
-- Name: FUNCTION isleapyear(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION isleapyear(date) IS 'Is leap year';


--
-- TOC entry 796 (class 1255 OID 116815)
-- Dependencies: 48
-- Name: nearest_bizday(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION nearest_bizday(date) RETURNS date
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvdate_nearest_bizday';


ALTER FUNCTION plvdate.nearest_bizday(date) OWNER TO dberaldi;

--
-- TOC entry 3652 (class 0 OID 0)
-- Dependencies: 796
-- Name: FUNCTION nearest_bizday(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION nearest_bizday(date) IS 'Get the nearest business date to a given date, user defined';


--
-- TOC entry 797 (class 1255 OID 116816)
-- Dependencies: 48
-- Name: next_bizday(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION next_bizday(date) RETURNS date
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvdate_next_bizday';


ALTER FUNCTION plvdate.next_bizday(date) OWNER TO dberaldi;

--
-- TOC entry 3653 (class 0 OID 0)
-- Dependencies: 797
-- Name: FUNCTION next_bizday(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION next_bizday(date) IS 'Get the next business date from a given date, user defined';


--
-- TOC entry 813 (class 1255 OID 116832)
-- Dependencies: 48
-- Name: noinclude_start(); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION noinclude_start() RETURNS boolean
    LANGUAGE sql STRICT
    AS $$SELECT plvdate.include_start(false); SELECT NULL::boolean;$$;


ALTER FUNCTION plvdate.noinclude_start() OWNER TO dberaldi;

--
-- TOC entry 799 (class 1255 OID 116818)
-- Dependencies: 48
-- Name: prev_bizday(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION prev_bizday(date) RETURNS date
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvdate_prev_bizday';


ALTER FUNCTION plvdate.prev_bizday(date) OWNER TO dberaldi;

--
-- TOC entry 3654 (class 0 OID 0)
-- Dependencies: 799
-- Name: FUNCTION prev_bizday(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION prev_bizday(date) IS 'Get the previous business date from a given date';


--
-- TOC entry 801 (class 1255 OID 116820)
-- Dependencies: 48
-- Name: set_nonbizday(text); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION set_nonbizday(text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_set_nonbizday_dow';


ALTER FUNCTION plvdate.set_nonbizday(text) OWNER TO dberaldi;

--
-- TOC entry 3655 (class 0 OID 0)
-- Dependencies: 801
-- Name: FUNCTION set_nonbizday(text); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION set_nonbizday(text) IS 'Set day of week as non bussines day';


--
-- TOC entry 805 (class 1255 OID 116824)
-- Dependencies: 48
-- Name: set_nonbizday(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION set_nonbizday(date) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT plvdate.set_nonbizday($1, false); SELECT NULL::boolean;$_$;


ALTER FUNCTION plvdate.set_nonbizday(date) OWNER TO dberaldi;

--
-- TOC entry 3656 (class 0 OID 0)
-- Dependencies: 805
-- Name: FUNCTION set_nonbizday(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION set_nonbizday(date) IS 'Set day as non bussines day';


--
-- TOC entry 803 (class 1255 OID 116822)
-- Dependencies: 48
-- Name: set_nonbizday(date, boolean); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION set_nonbizday(date, boolean) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_set_nonbizday_day';


ALTER FUNCTION plvdate.set_nonbizday(date, boolean) OWNER TO dberaldi;

--
-- TOC entry 3657 (class 0 OID 0)
-- Dependencies: 803
-- Name: FUNCTION set_nonbizday(date, boolean); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION set_nonbizday(date, boolean) IS 'Set day as non bussines day, if repeat is true, then day is nonbiz every year';


--
-- TOC entry 802 (class 1255 OID 116821)
-- Dependencies: 48
-- Name: unset_nonbizday(text); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION unset_nonbizday(text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_unset_nonbizday_dow';


ALTER FUNCTION plvdate.unset_nonbizday(text) OWNER TO dberaldi;

--
-- TOC entry 3658 (class 0 OID 0)
-- Dependencies: 802
-- Name: FUNCTION unset_nonbizday(text); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION unset_nonbizday(text) IS 'Unset day of week as non bussines day';


--
-- TOC entry 806 (class 1255 OID 116825)
-- Dependencies: 48
-- Name: unset_nonbizday(date); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION unset_nonbizday(date) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT plvdate.unset_nonbizday($1, false); SELECT NULL::boolean;$_$;


ALTER FUNCTION plvdate.unset_nonbizday(date) OWNER TO dberaldi;

--
-- TOC entry 3659 (class 0 OID 0)
-- Dependencies: 806
-- Name: FUNCTION unset_nonbizday(date); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION unset_nonbizday(date) IS 'Unset day as non bussines day';


--
-- TOC entry 804 (class 1255 OID 116823)
-- Dependencies: 48
-- Name: unset_nonbizday(date, boolean); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION unset_nonbizday(date, boolean) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_unset_nonbizday_day';


ALTER FUNCTION plvdate.unset_nonbizday(date, boolean) OWNER TO dberaldi;

--
-- TOC entry 3660 (class 0 OID 0)
-- Dependencies: 804
-- Name: FUNCTION unset_nonbizday(date, boolean); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION unset_nonbizday(date, boolean) IS 'Unset day as non bussines day, if repeat is true, then day is nonbiz every year';


--
-- TOC entry 809 (class 1255 OID 116828)
-- Dependencies: 48
-- Name: unuse_easter(); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION unuse_easter() RETURNS boolean
    LANGUAGE sql STRICT
    AS $$SELECT plvdate.use_easter(false); SELECT NULL::boolean;$$;


ALTER FUNCTION plvdate.unuse_easter() OWNER TO dberaldi;

--
-- TOC entry 3661 (class 0 OID 0)
-- Dependencies: 809
-- Name: FUNCTION unuse_easter(); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION unuse_easter() IS 'Easter Sunday and easter monday will not be holiday';


--
-- TOC entry 808 (class 1255 OID 116827)
-- Dependencies: 48
-- Name: use_easter(); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION use_easter() RETURNS boolean
    LANGUAGE sql STRICT
    AS $$SELECT plvdate.use_easter(true); SELECT NULL::boolean;$$;


ALTER FUNCTION plvdate.use_easter() OWNER TO dberaldi;

--
-- TOC entry 3662 (class 0 OID 0)
-- Dependencies: 808
-- Name: FUNCTION use_easter(); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION use_easter() IS 'Easter Sunday and easter monday will be holiday';


--
-- TOC entry 807 (class 1255 OID 116826)
-- Dependencies: 48
-- Name: use_easter(boolean); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION use_easter(boolean) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_use_easter';


ALTER FUNCTION plvdate.use_easter(boolean) OWNER TO dberaldi;

--
-- TOC entry 3663 (class 0 OID 0)
-- Dependencies: 807
-- Name: FUNCTION use_easter(boolean); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION use_easter(boolean) IS 'Easter Sunday and easter monday will be holiday';


--
-- TOC entry 810 (class 1255 OID 116829)
-- Dependencies: 48
-- Name: using_easter(); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION using_easter() RETURNS boolean
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_using_easter';


ALTER FUNCTION plvdate.using_easter() OWNER TO dberaldi;

--
-- TOC entry 3664 (class 0 OID 0)
-- Dependencies: 810
-- Name: FUNCTION using_easter(); Type: COMMENT; Schema: plvdate; Owner: dberaldi
--

COMMENT ON FUNCTION using_easter() IS 'Use easter?';


--
-- TOC entry 815 (class 1255 OID 116834)
-- Dependencies: 48
-- Name: version(); Type: FUNCTION; Schema: plvdate; Owner: dberaldi
--

CREATE FUNCTION version() RETURNS cstring
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvdate_version';


ALTER FUNCTION plvdate.version() OWNER TO dberaldi;

SET search_path = plvlex, pg_catalog;

--
-- TOC entry 601 (class 1255 OID 116912)
-- Dependencies: 54
-- Name: tokens(text, boolean, boolean); Type: FUNCTION; Schema: plvlex; Owner: dberaldi
--

CREATE FUNCTION tokens(str text, skip_spaces boolean, qualified_names boolean, OUT pos integer, OUT token text, OUT code integer, OUT class text, OUT separator text, OUT mod text) RETURNS SETOF record
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvlex_tokens';


ALTER FUNCTION plvlex.tokens(str text, skip_spaces boolean, qualified_names boolean, OUT pos integer, OUT token text, OUT code integer, OUT class text, OUT separator text, OUT mod text) OWNER TO dberaldi;

--
-- TOC entry 3665 (class 0 OID 0)
-- Dependencies: 601
-- Name: FUNCTION tokens(str text, skip_spaces boolean, qualified_names boolean, OUT pos integer, OUT token text, OUT code integer, OUT class text, OUT separator text, OUT mod text); Type: COMMENT; Schema: plvlex; Owner: dberaldi
--

COMMENT ON FUNCTION tokens(str text, skip_spaces boolean, qualified_names boolean, OUT pos integer, OUT token text, OUT code integer, OUT class text, OUT separator text, OUT mod text) IS 'Parse SQL string';


SET search_path = plvstr, pg_catalog;

--
-- TOC entry 844 (class 1255 OID 116863)
-- Dependencies: 49
-- Name: betwn(text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION betwn(str text, start integer, _end integer) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.betwn($1,$2,$3,true);$_$;


ALTER FUNCTION plvstr.betwn(str text, start integer, _end integer) OWNER TO dberaldi;

--
-- TOC entry 3666 (class 0 OID 0)
-- Dependencies: 844
-- Name: FUNCTION betwn(str text, start integer, _end integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION betwn(str text, start integer, _end integer) IS 'Find the Substring Between Start and End Locations';


--
-- TOC entry 846 (class 1255 OID 116865)
-- Dependencies: 49
-- Name: betwn(text, text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION betwn(str text, start text, _end text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $_$ SELECT plvstr.betwn($1,$2,$3,1,1,true,false);$_$;


ALTER FUNCTION plvstr.betwn(str text, start text, _end text) OWNER TO dberaldi;

--
-- TOC entry 3667 (class 0 OID 0)
-- Dependencies: 846
-- Name: FUNCTION betwn(str text, start text, _end text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION betwn(str text, start text, _end text) IS 'Find the Substring Between Start and End Locations';


--
-- TOC entry 843 (class 1255 OID 116862)
-- Dependencies: 49
-- Name: betwn(text, integer, integer, boolean); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION betwn(str text, start integer, _end integer, inclusive boolean) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_betwn_i';


ALTER FUNCTION plvstr.betwn(str text, start integer, _end integer, inclusive boolean) OWNER TO dberaldi;

--
-- TOC entry 3668 (class 0 OID 0)
-- Dependencies: 843
-- Name: FUNCTION betwn(str text, start integer, _end integer, inclusive boolean); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION betwn(str text, start integer, _end integer, inclusive boolean) IS 'Find the Substring Between Start and End Locations';


--
-- TOC entry 847 (class 1255 OID 116866)
-- Dependencies: 49
-- Name: betwn(text, text, text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION betwn(str text, start text, _end text, startnth integer, endnth integer) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $_$ SELECT plvstr.betwn($1,$2,$3,$4,$5,true,false);$_$;


ALTER FUNCTION plvstr.betwn(str text, start text, _end text, startnth integer, endnth integer) OWNER TO dberaldi;

--
-- TOC entry 3669 (class 0 OID 0)
-- Dependencies: 847
-- Name: FUNCTION betwn(str text, start text, _end text, startnth integer, endnth integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION betwn(str text, start text, _end text, startnth integer, endnth integer) IS 'Find the Substring Between Start and End Locations';


--
-- TOC entry 845 (class 1255 OID 116864)
-- Dependencies: 49
-- Name: betwn(text, text, text, integer, integer, boolean, boolean); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION betwn(str text, start text, _end text, startnth integer, endnth integer, inclusive boolean, gotoend boolean) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plvstr_betwn_c';


ALTER FUNCTION plvstr.betwn(str text, start text, _end text, startnth integer, endnth integer, inclusive boolean, gotoend boolean) OWNER TO dberaldi;

--
-- TOC entry 3670 (class 0 OID 0)
-- Dependencies: 845
-- Name: FUNCTION betwn(str text, start text, _end text, startnth integer, endnth integer, inclusive boolean, gotoend boolean); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION betwn(str text, start text, _end text, startnth integer, endnth integer, inclusive boolean, gotoend boolean) IS 'Find the Substring Between Start and End Locations';


--
-- TOC entry 828 (class 1255 OID 116847)
-- Dependencies: 49
-- Name: instr(text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION instr(str text, patt text) RETURNS integer
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_instr2';


ALTER FUNCTION plvstr.instr(str text, patt text) OWNER TO dberaldi;

--
-- TOC entry 3671 (class 0 OID 0)
-- Dependencies: 828
-- Name: FUNCTION instr(str text, patt text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION instr(str text, patt text) IS 'Search pattern in string';


--
-- TOC entry 827 (class 1255 OID 116846)
-- Dependencies: 49
-- Name: instr(text, text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION instr(str text, patt text, start integer) RETURNS integer
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_instr3';


ALTER FUNCTION plvstr.instr(str text, patt text, start integer) OWNER TO dberaldi;

--
-- TOC entry 3672 (class 0 OID 0)
-- Dependencies: 827
-- Name: FUNCTION instr(str text, patt text, start integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION instr(str text, patt text, start integer) IS 'Search pattern in string';


--
-- TOC entry 826 (class 1255 OID 116845)
-- Dependencies: 49
-- Name: instr(text, text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION instr(str text, patt text, start integer, nth integer) RETURNS integer
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_instr4';


ALTER FUNCTION plvstr.instr(str text, patt text, start integer, nth integer) OWNER TO dberaldi;

--
-- TOC entry 3673 (class 0 OID 0)
-- Dependencies: 826
-- Name: FUNCTION instr(str text, patt text, start integer, nth integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION instr(str text, patt text, start integer, nth integer) IS 'Search pattern in string';


--
-- TOC entry 821 (class 1255 OID 116840)
-- Dependencies: 49
-- Name: is_prefix(text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION is_prefix(str text, prefix text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.is_prefix($1,$2,true);$_$;


ALTER FUNCTION plvstr.is_prefix(str text, prefix text) OWNER TO dberaldi;

--
-- TOC entry 3674 (class 0 OID 0)
-- Dependencies: 821
-- Name: FUNCTION is_prefix(str text, prefix text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION is_prefix(str text, prefix text) IS 'Returns true, if prefix is prefix of str';


--
-- TOC entry 822 (class 1255 OID 116841)
-- Dependencies: 49
-- Name: is_prefix(integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION is_prefix(str integer, prefix integer) RETURNS boolean
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_is_prefix_int';


ALTER FUNCTION plvstr.is_prefix(str integer, prefix integer) OWNER TO dberaldi;

--
-- TOC entry 3675 (class 0 OID 0)
-- Dependencies: 822
-- Name: FUNCTION is_prefix(str integer, prefix integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION is_prefix(str integer, prefix integer) IS 'Returns true, if prefix is prefix of str';


--
-- TOC entry 823 (class 1255 OID 116842)
-- Dependencies: 49
-- Name: is_prefix(bigint, bigint); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION is_prefix(str bigint, prefix bigint) RETURNS boolean
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_is_prefix_int64';


ALTER FUNCTION plvstr.is_prefix(str bigint, prefix bigint) OWNER TO dberaldi;

--
-- TOC entry 3676 (class 0 OID 0)
-- Dependencies: 823
-- Name: FUNCTION is_prefix(str bigint, prefix bigint); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION is_prefix(str bigint, prefix bigint) IS 'Returns true, if prefix is prefix of str';


--
-- TOC entry 820 (class 1255 OID 116839)
-- Dependencies: 49
-- Name: is_prefix(text, text, boolean); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION is_prefix(str text, prefix text, cs boolean) RETURNS boolean
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_is_prefix_text';


ALTER FUNCTION plvstr.is_prefix(str text, prefix text, cs boolean) OWNER TO dberaldi;

--
-- TOC entry 3677 (class 0 OID 0)
-- Dependencies: 820
-- Name: FUNCTION is_prefix(str text, prefix text, cs boolean); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION is_prefix(str text, prefix text, cs boolean) IS 'Returns true, if prefix is prefix of str';


--
-- TOC entry 864 (class 1255 OID 116884)
-- Dependencies: 49
-- Name: left(text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION "left"(str text, n integer) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_left';


ALTER FUNCTION plvstr."left"(str text, n integer) OWNER TO dberaldi;

--
-- TOC entry 3678 (class 0 OID 0)
-- Dependencies: 864
-- Name: FUNCTION "left"(str text, n integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION "left"(str text, n integer) IS 'Returns firs num_in charaters. You can use negative num_in';


--
-- TOC entry 832 (class 1255 OID 116851)
-- Dependencies: 49
-- Name: lpart(text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION lpart(str text, div text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.lpart($1,$2, 1, 1, false); $_$;


ALTER FUNCTION plvstr.lpart(str text, div text) OWNER TO dberaldi;

--
-- TOC entry 3679 (class 0 OID 0)
-- Dependencies: 832
-- Name: FUNCTION lpart(str text, div text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION lpart(str text, div text) IS 'Call this function to return the left part of a string';


--
-- TOC entry 831 (class 1255 OID 116850)
-- Dependencies: 49
-- Name: lpart(text, text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION lpart(str text, div text, start integer) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.lpart($1,$2, $3, 1, false); $_$;


ALTER FUNCTION plvstr.lpart(str text, div text, start integer) OWNER TO dberaldi;

--
-- TOC entry 3680 (class 0 OID 0)
-- Dependencies: 831
-- Name: FUNCTION lpart(str text, div text, start integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION lpart(str text, div text, start integer) IS 'Call this function to return the left part of a string';


--
-- TOC entry 830 (class 1255 OID 116849)
-- Dependencies: 49
-- Name: lpart(text, text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION lpart(str text, div text, start integer, nth integer) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.lpart($1,$2, $3, $4, false); $_$;


ALTER FUNCTION plvstr.lpart(str text, div text, start integer, nth integer) OWNER TO dberaldi;

--
-- TOC entry 3681 (class 0 OID 0)
-- Dependencies: 830
-- Name: FUNCTION lpart(str text, div text, start integer, nth integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION lpart(str text, div text, start integer, nth integer) IS 'Call this function to return the left part of a string';


--
-- TOC entry 829 (class 1255 OID 116848)
-- Dependencies: 49
-- Name: lpart(text, text, integer, integer, boolean); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION lpart(str text, div text, start integer, nth integer, all_if_notfound boolean) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_lpart';


ALTER FUNCTION plvstr.lpart(str text, div text, start integer, nth integer, all_if_notfound boolean) OWNER TO dberaldi;

--
-- TOC entry 3682 (class 0 OID 0)
-- Dependencies: 829
-- Name: FUNCTION lpart(str text, div text, start integer, nth integer, all_if_notfound boolean); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION lpart(str text, div text, start integer, nth integer, all_if_notfound boolean) IS 'Call this function to return the left part of a string';


--
-- TOC entry 838 (class 1255 OID 116857)
-- Dependencies: 49
-- Name: lstrip(text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION lstrip(str text, substr text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.lstrip($1, $2, 1); $_$;


ALTER FUNCTION plvstr.lstrip(str text, substr text) OWNER TO dberaldi;

--
-- TOC entry 3683 (class 0 OID 0)
-- Dependencies: 838
-- Name: FUNCTION lstrip(str text, substr text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION lstrip(str text, substr text) IS 'Call this function to remove characters from the beginning ';


--
-- TOC entry 837 (class 1255 OID 116856)
-- Dependencies: 49
-- Name: lstrip(text, text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION lstrip(str text, substr text, num integer) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_lstrip';


ALTER FUNCTION plvstr.lstrip(str text, substr text, num integer) OWNER TO dberaldi;

--
-- TOC entry 3684 (class 0 OID 0)
-- Dependencies: 837
-- Name: FUNCTION lstrip(str text, substr text, num integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION lstrip(str text, substr text, num integer) IS 'Call this function to remove characters from the beginning ';


--
-- TOC entry 819 (class 1255 OID 116838)
-- Dependencies: 49
-- Name: normalize(text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION normalize(str text) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_normalize';


ALTER FUNCTION plvstr.normalize(str text) OWNER TO dberaldi;

--
-- TOC entry 3685 (class 0 OID 0)
-- Dependencies: 819
-- Name: FUNCTION normalize(str text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION normalize(str text) IS 'Replace white chars by space, replace  spaces by space';


--
-- TOC entry 865 (class 1255 OID 116885)
-- Dependencies: 49
-- Name: right(text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION "right"(str text, n integer) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_right';


ALTER FUNCTION plvstr."right"(str text, n integer) OWNER TO dberaldi;

--
-- TOC entry 3686 (class 0 OID 0)
-- Dependencies: 865
-- Name: FUNCTION "right"(str text, n integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION "right"(str text, n integer) IS 'Returns last num_in charaters. You can use negative num_ni';


--
-- TOC entry 836 (class 1255 OID 116855)
-- Dependencies: 49
-- Name: rpart(text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rpart(str text, div text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.rpart($1,$2, 1, 1, false); $_$;


ALTER FUNCTION plvstr.rpart(str text, div text) OWNER TO dberaldi;

--
-- TOC entry 3687 (class 0 OID 0)
-- Dependencies: 836
-- Name: FUNCTION rpart(str text, div text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rpart(str text, div text) IS 'Call this function to return the right part of a string';


--
-- TOC entry 835 (class 1255 OID 116854)
-- Dependencies: 49
-- Name: rpart(text, text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rpart(str text, div text, start integer) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.rpart($1,$2, $3, 1, false); $_$;


ALTER FUNCTION plvstr.rpart(str text, div text, start integer) OWNER TO dberaldi;

--
-- TOC entry 3688 (class 0 OID 0)
-- Dependencies: 835
-- Name: FUNCTION rpart(str text, div text, start integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rpart(str text, div text, start integer) IS 'Call this function to return the right part of a string';


--
-- TOC entry 834 (class 1255 OID 116853)
-- Dependencies: 49
-- Name: rpart(text, text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rpart(str text, div text, start integer, nth integer) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.rpart($1,$2, $3, $4, false); $_$;


ALTER FUNCTION plvstr.rpart(str text, div text, start integer, nth integer) OWNER TO dberaldi;

--
-- TOC entry 3689 (class 0 OID 0)
-- Dependencies: 834
-- Name: FUNCTION rpart(str text, div text, start integer, nth integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rpart(str text, div text, start integer, nth integer) IS 'Call this function to return the right part of a string';


--
-- TOC entry 833 (class 1255 OID 116852)
-- Dependencies: 49
-- Name: rpart(text, text, integer, integer, boolean); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rpart(str text, div text, start integer, nth integer, all_if_notfound boolean) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_rpart';


ALTER FUNCTION plvstr.rpart(str text, div text, start integer, nth integer, all_if_notfound boolean) OWNER TO dberaldi;

--
-- TOC entry 3690 (class 0 OID 0)
-- Dependencies: 833
-- Name: FUNCTION rpart(str text, div text, start integer, nth integer, all_if_notfound boolean); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rpart(str text, div text, start integer, nth integer, all_if_notfound boolean) IS 'Call this function to return the right part of a string';


--
-- TOC entry 840 (class 1255 OID 116859)
-- Dependencies: 49
-- Name: rstrip(text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rstrip(str text, substr text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.rstrip($1, $2, 1); $_$;


ALTER FUNCTION plvstr.rstrip(str text, substr text) OWNER TO dberaldi;

--
-- TOC entry 3691 (class 0 OID 0)
-- Dependencies: 840
-- Name: FUNCTION rstrip(str text, substr text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rstrip(str text, substr text) IS 'Call this function to remove characters from the end';


--
-- TOC entry 839 (class 1255 OID 116858)
-- Dependencies: 49
-- Name: rstrip(text, text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rstrip(str text, substr text, num integer) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_rstrip';


ALTER FUNCTION plvstr.rstrip(str text, substr text, num integer) OWNER TO dberaldi;

--
-- TOC entry 3692 (class 0 OID 0)
-- Dependencies: 839
-- Name: FUNCTION rstrip(str text, substr text, num integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rstrip(str text, substr text, num integer) IS 'Call this function to remove characters from the end';


--
-- TOC entry 699 (class 1255 OID 116705)
-- Dependencies: 49
-- Name: rvrs(text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rvrs(str text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.rvrs($1,1,NULL);$_$;


ALTER FUNCTION plvstr.rvrs(str text) OWNER TO dberaldi;

--
-- TOC entry 3693 (class 0 OID 0)
-- Dependencies: 699
-- Name: FUNCTION rvrs(str text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rvrs(str text) IS 'Reverse string or part of string';


--
-- TOC entry 698 (class 1255 OID 116704)
-- Dependencies: 49
-- Name: rvrs(text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rvrs(str text, start integer) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.rvrs($1,$2,NULL);$_$;


ALTER FUNCTION plvstr.rvrs(str text, start integer) OWNER TO dberaldi;

--
-- TOC entry 3694 (class 0 OID 0)
-- Dependencies: 698
-- Name: FUNCTION rvrs(str text, start integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rvrs(str text, start integer) IS 'Reverse string or part of string';


--
-- TOC entry 697 (class 1255 OID 116703)
-- Dependencies: 49
-- Name: rvrs(text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION rvrs(str text, start integer, _end integer) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plvstr_rvrs';


ALTER FUNCTION plvstr.rvrs(str text, start integer, _end integer) OWNER TO dberaldi;

--
-- TOC entry 3695 (class 0 OID 0)
-- Dependencies: 697
-- Name: FUNCTION rvrs(str text, start integer, _end integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION rvrs(str text, start integer, _end integer) IS 'Reverse string or part of string';


--
-- TOC entry 825 (class 1255 OID 116844)
-- Dependencies: 49
-- Name: substr(text, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION substr(str text, start integer) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_substr2';


ALTER FUNCTION plvstr.substr(str text, start integer) OWNER TO dberaldi;

--
-- TOC entry 3696 (class 0 OID 0)
-- Dependencies: 825
-- Name: FUNCTION substr(str text, start integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION substr(str text, start integer) IS 'Returns substring started on start_in to end';


--
-- TOC entry 824 (class 1255 OID 116843)
-- Dependencies: 49
-- Name: substr(text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION substr(str text, start integer, len integer) RETURNS character varying
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'plvstr_substr3';


ALTER FUNCTION plvstr.substr(str text, start integer, len integer) OWNER TO dberaldi;

--
-- TOC entry 3697 (class 0 OID 0)
-- Dependencies: 824
-- Name: FUNCTION substr(str text, start integer, len integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION substr(str text, start integer, len integer) IS 'Returns substring started on start_in to end';


--
-- TOC entry 842 (class 1255 OID 116861)
-- Dependencies: 49
-- Name: swap(text, text); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION swap(str text, replace text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT plvstr.swap($1,$2,1, NULL);$_$;


ALTER FUNCTION plvstr.swap(str text, replace text) OWNER TO dberaldi;

--
-- TOC entry 3698 (class 0 OID 0)
-- Dependencies: 842
-- Name: FUNCTION swap(str text, replace text); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION swap(str text, replace text) IS 'Replace a substring in a string with a specified string';


--
-- TOC entry 841 (class 1255 OID 116860)
-- Dependencies: 49
-- Name: swap(text, text, integer, integer); Type: FUNCTION; Schema: plvstr; Owner: dberaldi
--

CREATE FUNCTION swap(str text, replace text, start integer, length integer) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plvstr_swap';


ALTER FUNCTION plvstr.swap(str text, replace text, start integer, length integer) OWNER TO dberaldi;

--
-- TOC entry 3699 (class 0 OID 0)
-- Dependencies: 841
-- Name: FUNCTION swap(str text, replace text, start integer, length integer); Type: COMMENT; Schema: plvstr; Owner: dberaldi
--

COMMENT ON FUNCTION swap(str text, replace text, start integer, length integer) IS 'Replace a substring in a string with a specified string';


SET search_path = plvsubst, pg_catalog;

--
-- TOC entry 597 (class 1255 OID 116906)
-- Dependencies: 52
-- Name: setsubst(); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION setsubst() RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvsubst_setsubst_default';


ALTER FUNCTION plvsubst.setsubst() OWNER TO dberaldi;

--
-- TOC entry 3700 (class 0 OID 0)
-- Dependencies: 597
-- Name: FUNCTION setsubst(); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION setsubst() IS 'Change the substitution keyword to default %s';


--
-- TOC entry 596 (class 1255 OID 116905)
-- Dependencies: 52
-- Name: setsubst(text); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION setsubst(str text) RETURNS void
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvsubst_setsubst';


ALTER FUNCTION plvsubst.setsubst(str text) OWNER TO dberaldi;

--
-- TOC entry 3701 (class 0 OID 0)
-- Dependencies: 596
-- Name: FUNCTION setsubst(str text); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION setsubst(str text) IS 'Change the substitution keyword';


--
-- TOC entry 589 (class 1255 OID 116901)
-- Dependencies: 52
-- Name: string(text, text[]); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION string(template_in text, values_in text[]) RETURNS text
    LANGUAGE sql STRICT
    AS $_$SELECT plvsubst.string($1,$2, NULL);$_$;


ALTER FUNCTION plvsubst.string(template_in text, values_in text[]) OWNER TO dberaldi;

--
-- TOC entry 3702 (class 0 OID 0)
-- Dependencies: 589
-- Name: FUNCTION string(template_in text, values_in text[]); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION string(template_in text, values_in text[]) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';


--
-- TOC entry 593 (class 1255 OID 116903)
-- Dependencies: 52
-- Name: string(text, text); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION string(template_in text, vals_in text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plvsubst_string_string';


ALTER FUNCTION plvsubst.string(template_in text, vals_in text) OWNER TO dberaldi;

--
-- TOC entry 3703 (class 0 OID 0)
-- Dependencies: 593
-- Name: FUNCTION string(template_in text, vals_in text); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION string(template_in text, vals_in text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';


--
-- TOC entry 577 (class 1255 OID 116900)
-- Dependencies: 52
-- Name: string(text, text[], text); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION string(template_in text, values_in text[], subst text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plvsubst_string_array';


ALTER FUNCTION plvsubst.string(template_in text, values_in text[], subst text) OWNER TO dberaldi;

--
-- TOC entry 3704 (class 0 OID 0)
-- Dependencies: 577
-- Name: FUNCTION string(template_in text, values_in text[], subst text); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION string(template_in text, values_in text[], subst text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';


--
-- TOC entry 595 (class 1255 OID 116904)
-- Dependencies: 52
-- Name: string(text, text, text); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION string(template_in text, vals_in text, delim_in text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plvsubst_string_string';


ALTER FUNCTION plvsubst.string(template_in text, vals_in text, delim_in text) OWNER TO dberaldi;

--
-- TOC entry 3705 (class 0 OID 0)
-- Dependencies: 595
-- Name: FUNCTION string(template_in text, vals_in text, delim_in text); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION string(template_in text, vals_in text, delim_in text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';


--
-- TOC entry 592 (class 1255 OID 116902)
-- Dependencies: 52
-- Name: string(text, text, text, text); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION string(template_in text, vals_in text, delim_in text, subst_in text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'plvsubst_string_string';


ALTER FUNCTION plvsubst.string(template_in text, vals_in text, delim_in text, subst_in text) OWNER TO dberaldi;

--
-- TOC entry 3706 (class 0 OID 0)
-- Dependencies: 592
-- Name: FUNCTION string(template_in text, vals_in text, delim_in text, subst_in text); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION string(template_in text, vals_in text, delim_in text, subst_in text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';


--
-- TOC entry 598 (class 1255 OID 116907)
-- Dependencies: 52
-- Name: subst(); Type: FUNCTION; Schema: plvsubst; Owner: dberaldi
--

CREATE FUNCTION subst() RETURNS text
    LANGUAGE c STRICT
    AS '$libdir/orafunc', 'plvsubst_subst';


ALTER FUNCTION plvsubst.subst() OWNER TO dberaldi;

--
-- TOC entry 3707 (class 0 OID 0)
-- Dependencies: 598
-- Name: FUNCTION subst(); Type: COMMENT; Schema: plvsubst; Owner: dberaldi
--

COMMENT ON FUNCTION subst() IS 'Retrieve the current substitution keyword';


SET search_path = public, pg_catalog;

--
-- TOC entry 679 (class 1255 OID 207847)
-- Dependencies: 5
-- Name: array_avg(double precision[]); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION array_avg(double precision[]) RETURNS double precision
    LANGUAGE sql
    AS $_$
SELECT avg(v) FROM unnest($1) g(v)
$_$;


ALTER FUNCTION public.array_avg(double precision[]) OWNER TO dberaldi;

--
-- TOC entry 686 (class 1255 OID 26946)
-- Dependencies: 1590 5
-- Name: bedtools(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION bedtools(arg_string text) RETURNS text
    LANGUAGE plpython3u
    AS $_$
version= '0.1-stub'
docstring= """ bedtools %s

Author: Dario Beraldi (dario<dot>beraldi<at>gmail<dot>com)

DESCRIPTION:
ARGUMENTS:
EXAMPLES:
""" %version

" '-----------------------[ Function starts here ]------------------------------ "
argstr= arg_string.strip()
if argstr == 'man' or argstr == 'help' or argstr == 'h' or argstr == '':
    return(docstring)

import os
import tempfile
import sys
import subprocess

" ---------------------[ Parse arguments ]----------------------------------- "

" List of pseudo-arguments "
afile= 'afile'
bfile= 'bfile'
cmd= 'cmd'
dest_table= 'dest_table'
outfile= 'outfile'
rm_tmp_files= 'rm_tmp_files'

## Convert the argument string to a dictionary
try:
    arg_dict= eval('{' + arg_string + '}')
except:
    sys.exit("Error parsing the argument string:\n" + arg_string +
           "\n- Does it contain '=' instead of ':' assignment sign?\n- Are the argument names correct?")

""" Arg-parser
Retrieve user's parameters (try:...) or assign defaults (except:...) """
try:
    afile= arg_dict[afile]
except:
    sys.exit('Error in bedtools(): argument afile is empty')
try:
    bfile= arg_dict[bfile]
except:
    sys.exit('Error in bedtools(): argument afile is empty')
try:
    cmd= arg_dict[cmd]
except:
    sys.exit('Error in bedtools(): argument cmd is empty')
try:
    dest_table= arg_dict[dest_table]
except:
    sys.exit('Error in bedtools(): argument dest_table is empty')
try:
    outfile= arg_dict[outfile]
except:
    outfile= None
try:
    rm_tmp_files= arg_dict[rm_tmp_files]
except:
    rm_tmp_files= True
" ---------------------------[ Define functions ]---------------------------- "

def isfile(argstring):
    """ Tests whether string 'argstring' is a file or an SQL select
    statement.
    Returns True if file, False if it is a SQL statement starting with select.   """
    argstring= argstring.strip()
    if os.path.exists(argstring) is True:
            f= open(argstring)
            f.close()
            return(True)
    elif argstring.lower().startswith('select'):
        return(False)
    else:
        sys.exit('bedtools: %s is not recognized as file or valid sql SELECT statement' %(argstring))
        
def sql2file(sql):
    """ Executes the sql select statement in string sql and writes to a temp
    file the result table.
    Returns the name of the temp file. """
    sql= sql.strip()
    sql= sql.rstrip(';')
    tmpfile= tempfile.NamedTemporaryFile(suffix= '_bedtools_input', delete= False)
    tmpfile_name= tmpfile.name
    os.chmod(tmpfile_name, int('666', 8))
    copy_sql= "COPY (%s) TO '%s' DELIMITER E'\t';" %(sql, tmpfile_name)
    plpy.execute(copy_sql)
    return(tmpfile_name)

def getbedpath(cmd):
    " Queries the system to get the path to bedtool cmd to execute "
    cmd= cmd.strip()
    cmd= cmd + ' '
    btool_pos= cmd.find(' ')
    btool= cmd[0:(btool_pos+1)]
    p= subprocess.Popen('which %s' %(btool), shell= True, stdout= subprocess.PIPE)
    path= p.stdout.read().decode("utf-8")
    path= path.rstrip(cmd)
    path= path.strip()
#    if path == '':
#        sys.exit('Could not find program %s in cmd %s' %(btool, cmd))
    return(path)

" --------------------------------------------------------------------------- "

if isfile(afile) is True:
    afile= afile
else:
    afile= sql2file(afile)

if isfile(bfile) is True:
    bfile= bfile
else:
    bfile= sql2file(bfile)

if outfile is None:
    outfile= tempfile.NamedTemporaryFile(delete= True, suffix= '_bedtools_outfile')
    outfile_name= outfile.name
else:
    outfile_name= outfile
    
" Compile bedtools command "
## bedpath= getbedpath(cmd)
bedcmd= cmd + ' -a ' + afile + ' -b ' + bfile + ' > ' + outfile_name

p= subprocess.Popen(bedcmd, shell= True, stderr= subprocess.PIPE)
perr= p.stderr.read().decode('UTF-8')
if perr != '':
    sys.exit('Error executing command %s\n%s' %(bedcmd, perr))

os.chmod(outfile_name, int('666', 8))
" Check if output file is empty "
if os.stat(outfile_name)[6] == 0:
    return('Warning: Output file is empty. Table %s not created.\n%s' %(dest_table, bedcmd))

sql_import= """SELECT read_table($$ file: '%s', table: '%s', sep: '\t'  $$)""" %(outfile_name, dest_table)
plpy.execute(sql_import)

if rm_tmp_files is True:
    os.remove(afile)
    os.remove(bfile)

return(bedcmd)

$_$;


ALTER FUNCTION public.bedtools(arg_string text) OWNER TO dberaldi;

--
-- TOC entry 688 (class 1255 OID 116693)
-- Dependencies: 5
-- Name: bitand(bigint, bigint); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION bitand(bigint, bigint) RETURNS bigint
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT $1 & $2; $_$;


ALTER FUNCTION public.bitand(bigint, bigint) OWNER TO dberaldi;

--
-- TOC entry 690 (class 1255 OID 116695)
-- Dependencies: 5
-- Name: cosh(double precision); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION cosh(double precision) RETURNS double precision
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT (exp($1) + exp(-$1)) / 2; $_$;


ALTER FUNCTION public.cosh(double precision) OWNER TO dberaldi;

--
-- TOC entry 678 (class 1255 OID 33009)
-- Dependencies: 5 1589
-- Name: create_project_designs(); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION create_project_designs() RETURNS text
    LANGUAGE plpgsql
    AS $$
    declare 
        sqlstring text;
        sqlcounter text;
        nrows int;
        row_project projects%ROWTYPE;

    begin
    set search_path to materialized_views, main, public, django_admin; -- This will create the matview in the proper schema
    for row_project in select distinct project from projects where is_deprecated is False limit 3
        loop
            sqlstring := 'select project_samples.project, exp_design.sample_id, s_variable, s_value 
                          from exp_design 
                          left join project_samples on exp_design.sample_id = project_samples.sample_id
                          where project_samples.project = ' || quote_literal(row_project.project);

            sqlcounter := 'select count(*) from (' || sqlstring || ') as t';
            execute sqlcounter into nrows;
            if nrows > 0 then
                perform cross_tab(sqlstring, row_project.project, False, True);
            end if;
         end loop;
    return nrows;
    end;
    $$;


ALTER FUNCTION public.create_project_designs() OWNER TO dberaldi;

--
-- TOC entry 684 (class 1255 OID 37846)
-- Dependencies: 5 1590
-- Name: cross_tab(text, text, boolean, boolean, boolean); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION cross_tab(sql_query text, dest_table text, temp boolean DEFAULT true, overwrite boolean DEFAULT true, cascade boolean DEFAULT false) RETURNS text
    LANGUAGE plpython3u
    AS $_$
""" -------------------------[ cross_tab-4.1 ]------------------------------- 

DESCRIPTION
Returns a crosstab table from a normalized table (similar to MS Access's 
pivot table). Table is created as TEMPORARY (new in 4.1).
Requirements: An SQL returning a normalized table with at least three 
columns corresponding to (in this order!) one or more row headers, 
column header, and value. E.g.

       |------- row headers ------| |-- 2nd last--]  |-- last --|
SELECT row_header, [opt.row_head 2], column_header,      value    FROM etc... ;

Each combination of row header(s) and column header should be unique.

Note: cross_tab() will re-order the table produced by sql_query by row header
(left to right) then by column header.

ARGUMENTS
sql_query:  A string containing an SQL statement returning the normalized 
            table to transform. See above how columns should be selected.

dest_table: Name of the output table that will store the cross-tab query.

temp:       True/False should the output table be created as TEMPORARY? 
            (Defualt True).

overwrite:  True/False. Overwrite existing dest_table? (Default True)

cascade:    Issues a DROP ... CASCADE to drop the existing cross tab table. Ignored 
            if overwrite is False. Default False.

TODO

 - Avoid string interpolation to compile SQLs.
 - Better coping with inout queries returning 0 rows. Currently no table is created and a message
   is returned. Better to create an empty table instead?
 - DONE: Use plpy.quote_ident() to properly quote table and column names to respect capitalization

"""

import sys
import datetime
import os
import tempfile

sql_query2= sql_query.rstrip()
sql_query2= sql_query2.rstrip(';')

" ------------------------[ Define functions ]------------------------------- "

def get_query_colnames(sql_query):
    """ Return a list with the column names in the query string sql_query.
    The order of names in the list is the same as in the query.
    """
    sql_query= sql_query.rstrip()
    sql_query= sql_query.rstrip(';')
    qry_table_colnames= 'DROP TABLE IF EXISTS colnames; CREATE TEMP TABLE colnames ON COMMIT DROP AS (SELECT * FROM (' + sql_query + ') AS t WHERE 1 = 2);'
    plpy.execute(qry_table_colnames)
    qry_colnames= "select * from information_schema.columns where table_name = 'colnames' order by ordinal_position;"
    colnames_results= plpy.execute(qry_colnames)
    nrows= colnames_results.nrows()
    colnames= []
    for i in range(0, nrows):
         colnames.append(colnames_results[i]["column_name"])
    return(colnames)

def plpy_get_line(cur, i, colnames):
    """ Return line number i from the plpy result object cur. in the column order given in list colnames.
    Note: The colnames for query q can be obtained with can be obtained with get_query_colnames(q).
    E.g.
    q= 'select a, b, c from t1'  ## Where first (i= 0) row has values: a= 1, b= 2, c= 3
    cur= plpy.execute(q)
    colnames= get_query_colnames(q)   ## >>> ['a', 'b', 'c']
    plpy_get_line(cur, 0, colnames)   ## >>> [1, 2, 3]
    """
    line= []
    for x in colnames:
        line.append(cur[i][x])
    return(line)

## Some functions for crosstabing
def reformat(x):
    " Substitute python's None with empty string or False if datatype is boolean "
    " Substitute date-times to isoformat "
    if x is None:
        if col_types[vi] == 'boolean':
            return(False)
        else:
            return('')
    elif type(x) == type(datetime.datetime.now()):
        return(datetime.date.isoformat(x))
    else:
        return(x)

def write_line(lst_line):
    " Reformat each block of input lines to a single line to be sent to outfile "
    outlinex= [reformat(x) for x in lst_line]
    line= '\t'.join([str(x) for x in outlinex]) + '\n'
    outfile.write(line)

def check_duplicate():
    " Stop execution if two rows have the same Row and column header (i.e. there are multiple values/row) "
    if (line is not None) and (current_row_heading == [line[i] for i in ri]) and (current_col_heading == line[ci]):
        sys.exit('Duplicate found for line\n' + str(line))

" -------------------[ Get input table column names and datatypes ]--------- "

if cascade is True:
    drop_cascade= 'CASCADE'
else:
    drop_cascade= ''

if overwrite is True:
    drop_sql= 'DROP TABLE IF EXISTS %s %s' %(plpy.quote_ident(dest_table), drop_cascade, )
    plpy.execute(drop_sql)

" Test if destination table already exists."
table_exists= 0
try:
    qry_test= 'SELECT * FROM %s LIMIT 1;' %(plpy.quote_ident(dest_table)) 
    table_exists= plpy.execute(qry_test)
    table_exists= 1
except:
    pass
if table_exists == 1:
    sys.exit('Destination table %s already exists.' %(plpy.quote_ident(dest_table)))

" Prepare temp output file "
outdir= tempfile.gettempdir()
outf= os.path.join(outdir, 'tmp_query_cross_tab.txt')
outfile= open(outf, 'w')

qry_input_table= 'CREATE TEMP TABLE tmp_cross_tab_input AS (SELECT * FROM (' + sql_query2 + ') AS t1);'
cur= plpy.execute(qry_input_table)

## w/o distinct it returns each name twice (!?)
qry_names_ord= """SELECT DISTINCT column_name, ordinal_position, data_type
  FROM information_schema.columns 
  WHERE table_name like 'tmp_cross_tab_input' 
  ORDER BY ordinal_position;"""
cur= plpy.execute(qry_names_ord)
## cur.execute(qry_names_ord)
nrows= cur.nrows()

col_names= []
for i in range(0, nrows):
    col_names.append(cur[i]['column_name'])
col_types= []
for i in range(0, nrows):
    col_types.append(cur[i]['data_type'])

" Replace NULL and empty string in future column names in order to avoid invalid column names "
sql_null= """SELECT * FROM (%s) AS t WHERE t.%s::text IS NULL OR t.%s::text = '' LIMIT 1;""" %(sql_query2, plpy.quote_ident(col_names[-2]), plpy.quote_ident(col_names[-2])) 
cur= plpy.execute(sql_null)
nrows= cur.nrows()
if nrows > 0:
    sys.exit("""cross_tab(): One or more values in the second last column (%s) contain a NULL or empty string.
Null and empty strings will not be valid column names for the output crosstab.
Add a CASE...WHEN or replace in the input query to avoid null and empty.
Found by:
%s
""" %(plpy.quote_ident(col_names[-2]), sql_null))

## Indexes of headers:
ri_s= 0 ## Row header starts
ri_e= len(col_names)-2 ## Row header finishes
ri= range(ri_s, ri_e)
ci= -2
vi= -1

## Default header names:
row_header= ', '.join([plpy.quote_ident(x) for x in col_names[ri_s:ri_e]]) ## All columns but last two
column_header= plpy.quote_ident(col_names[ci]) ## Second last columns  in input query
value= '"' + str(col_names[vi]) + '"' ## Last columns

## String to plug in SELECT statement
row_header__col_header__value= ', '.join([row_header, column_header + '::text', value])

## Collect column header names
qry_column_header= 'SELECT DISTINCT ' + column_header + '::text AS colheader FROM tmp_cross_tab_input;'
cur= plpy.execute(qry_column_header)
nrows= cur.nrows()

headers= []
for i in range(0, nrows):
    headers.append(cur[i]['colheader'])

headers.sort()

## Dictionary with position of each column header
column_dict={}
i= len(ri) ## Start from after the row_headings
for key in headers:
    column_dict[key] = i
    i += 1

## Prepare CREATE TABLE crosstab table

if temp is True:
    istemp= 'TEMP'
elif temp is False:
    istemp= ''
else:
    sys.exit('Unexpected value for arg temp: %s' %(temp))

qry_create_crosstab= 'CREATE ' + istemp + ' TABLE ' + plpy.quote_ident(dest_table) + '(\n  '
for i in ri:
    col= plpy.quote_ident(col_names[i]) ## '"' + col_names[i] + '"'
    var= col_types[i]
    qry_create_crosstab= qry_create_crosstab + col + ' ' + var + ',\n '
qry_create_crosstab= qry_create_crosstab.rstrip(',\n ')

for col in headers:
    col_def=  ',\n  ' +  plpy.quote_ident(col) + ' ' + col_types[vi]
    qry_create_crosstab= qry_create_crosstab + col_def
qry_create_crosstab= qry_create_crosstab + ');'

cur= plpy.execute(qry_create_crosstab)
## cur.execute(qry_create_crosstab)

## Order input query
qry_input_ordered= 'SELECT ' + row_header__col_header__value + ' FROM tmp_cross_tab_input ORDER BY ' + row_header + ', '+ column_header +';'
cur= plpy.execute(qry_input_ordered)
nrows= cur.nrows()
colnames= get_query_colnames(qry_input_ordered)

qry_delete_tmp= 'DROP TABLE tmp_cross_tab_input;'
plpy.execute(qry_delete_tmp)


" --------------------------[ Start cross-tabulation ]----------------------- "
if nrows == 0:
    " This is for when input queries returns zero rows "
    return('Table %s not created: Zero rows returned from input query.' %(dest_table) )
else:
    n= 0 
    line= plpy_get_line(cur, n, colnames)
    n += 1
    current_row_heading= [line[i] for i in ri]
    current_col_heading= line[ci]
    current_value= line[vi]
    outline= [None] * (len(headers)+ri_e)  ## List to hold row heading and crossed values
    for i in ri:
        " Replace in empty outline the row headings "
        outline[i]=current_row_heading[i]
    value_pos= column_dict[current_col_heading]
    outline[value_pos]= current_value 
    
    for n in range(1, nrows):
        line= plpy_get_line(cur, n, colnames)
        check_duplicate()
        next_row_heading= [line[i] for i in ri]
        next_col_heading= line[ci]
        next_value= line[vi]
        if next_row_heading == current_row_heading:
            value_pos= column_dict[next_col_heading]
            outline[value_pos]= next_value
        else:
            write_line(outline)
            current_row_heading = next_row_heading
            current_col_heading = next_col_heading
            outline= [None] * (len(headers)+ri_e)  ## Reset empty list to hold row heading and crossed values
            for i in ri:
                " Replace in empty outline the row headings "
                outline[i]=current_row_heading[i]
            value_pos= column_dict[current_col_heading]
            outline[value_pos]= next_value
write_line(outline)
outfile.close()

qry_copy= 'COPY ' + plpy.quote_ident(dest_table) + ' FROM ' + "E'" + outf + "' WITH CSV DELIMITER E'\t';"
plpy.execute(qry_copy)

os.remove(outf)

qry_comment= 'COMMENT ON TABLE ' + plpy.quote_ident(dest_table) + ' IS ' + "$comment$ Crosstab table generated by cross_tab() from input query: " + sql_query2 + " $comment$;"
plpy.execute(qry_comment)

return('Cross-tab table written to "' + dest_table + 
       '".\nThe following SQL commands have been executed:\n\n' +
       qry_input_table + '\n\n' + qry_names_ord + '\n\n' + 
       qry_column_header + '\n\n' + qry_create_crosstab + '\n\n' + qry_input_ordered +'\n\n' + 
       qry_copy + '\n\n' + qry_comment)

$_$;


ALTER FUNCTION public.cross_tab(sql_query text, dest_table text, temp boolean, overwrite boolean, cascade boolean) OWNER TO dberaldi;

--
-- TOC entry 713 (class 1255 OID 116726)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, text) OWNER TO dberaldi;

--
-- TOC entry 719 (class 1255 OID 116732)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, character); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, character) RETURNS character
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, character) OWNER TO dberaldi;

--
-- TOC entry 725 (class 1255 OID 116738)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, integer) RETURNS integer
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, integer) OWNER TO dberaldi;

--
-- TOC entry 731 (class 1255 OID 116744)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, bigint); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, bigint) RETURNS bigint
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, bigint) OWNER TO dberaldi;

--
-- TOC entry 737 (class 1255 OID 116750)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, numeric); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, numeric) RETURNS numeric
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, numeric) OWNER TO dberaldi;

--
-- TOC entry 743 (class 1255 OID 116756)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, date); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, date) RETURNS date
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, date) OWNER TO dberaldi;

--
-- TOC entry 749 (class 1255 OID 116762)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, time without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, time without time zone) RETURNS time without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, time without time zone) OWNER TO dberaldi;

--
-- TOC entry 755 (class 1255 OID 116768)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp without time zone) OWNER TO dberaldi;

--
-- TOC entry 761 (class 1255 OID 116774)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp with time zone) OWNER TO dberaldi;

--
-- TOC entry 714 (class 1255 OID 116727)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, text, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, text, text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, text, text) OWNER TO dberaldi;

--
-- TOC entry 720 (class 1255 OID 116733)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, character, character); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, character, character) RETURNS character
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, character, character) OWNER TO dberaldi;

--
-- TOC entry 726 (class 1255 OID 116739)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, integer, integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, integer, integer) RETURNS integer
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, integer, integer) OWNER TO dberaldi;

--
-- TOC entry 732 (class 1255 OID 116745)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, bigint, bigint); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, bigint, bigint) RETURNS bigint
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, bigint, bigint) OWNER TO dberaldi;

--
-- TOC entry 738 (class 1255 OID 116751)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, numeric, numeric); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, numeric, numeric) RETURNS numeric
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, numeric, numeric) OWNER TO dberaldi;

--
-- TOC entry 744 (class 1255 OID 116757)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, date, date); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, date, date) RETURNS date
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, date, date) OWNER TO dberaldi;

--
-- TOC entry 750 (class 1255 OID 116763)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, time without time zone, time without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, time without time zone, time without time zone) RETURNS time without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, time without time zone, time without time zone) OWNER TO dberaldi;

--
-- TOC entry 756 (class 1255 OID 116769)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp without time zone, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, timestamp without time zone) OWNER TO dberaldi;

--
-- TOC entry 762 (class 1255 OID 116775)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp with time zone, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, timestamp with time zone) OWNER TO dberaldi;

--
-- TOC entry 715 (class 1255 OID 116728)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, text, anyelement, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, text, anyelement, text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, text, anyelement, text) OWNER TO dberaldi;

--
-- TOC entry 721 (class 1255 OID 116734)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, character, anyelement, character); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, character, anyelement, character) RETURNS character
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, character, anyelement, character) OWNER TO dberaldi;

--
-- TOC entry 727 (class 1255 OID 116740)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, integer, anyelement, integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, integer, anyelement, integer) RETURNS integer
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer) OWNER TO dberaldi;

--
-- TOC entry 733 (class 1255 OID 116746)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, bigint, anyelement, bigint); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, bigint, anyelement, bigint) RETURNS bigint
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint) OWNER TO dberaldi;

--
-- TOC entry 739 (class 1255 OID 116752)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, numeric, anyelement, numeric); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, numeric, anyelement, numeric) RETURNS numeric
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric) OWNER TO dberaldi;

--
-- TOC entry 745 (class 1255 OID 116758)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, date, anyelement, date); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, date, anyelement, date) RETURNS date
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, date, anyelement, date) OWNER TO dberaldi;

--
-- TOC entry 751 (class 1255 OID 116764)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, time without time zone, anyelement, time without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, time without time zone, anyelement, time without time zone) RETURNS time without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone) OWNER TO dberaldi;

--
-- TOC entry 757 (class 1255 OID 116770)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone) OWNER TO dberaldi;

--
-- TOC entry 763 (class 1255 OID 116776)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone) OWNER TO dberaldi;

--
-- TOC entry 716 (class 1255 OID 116729)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, text, anyelement, text, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, text, anyelement, text, text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, text) OWNER TO dberaldi;

--
-- TOC entry 722 (class 1255 OID 116735)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, character, anyelement, character, character); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, character, anyelement, character, character) RETURNS character
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, character) OWNER TO dberaldi;

--
-- TOC entry 728 (class 1255 OID 116741)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, integer, anyelement, integer, integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, integer, anyelement, integer, integer) RETURNS integer
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, integer) OWNER TO dberaldi;

--
-- TOC entry 734 (class 1255 OID 116747)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, bigint, anyelement, bigint, bigint); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, bigint, anyelement, bigint, bigint) RETURNS bigint
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, bigint) OWNER TO dberaldi;

--
-- TOC entry 740 (class 1255 OID 116753)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, numeric, anyelement, numeric, numeric); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, numeric, anyelement, numeric, numeric) RETURNS numeric
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, numeric) OWNER TO dberaldi;

--
-- TOC entry 746 (class 1255 OID 116759)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, date, anyelement, date, date); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, date, anyelement, date, date) RETURNS date
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, date) OWNER TO dberaldi;

--
-- TOC entry 752 (class 1255 OID 116765)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, time without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, time without time zone) RETURNS time without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, time without time zone) OWNER TO dberaldi;

--
-- TOC entry 758 (class 1255 OID 116771)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone) OWNER TO dberaldi;

--
-- TOC entry 764 (class 1255 OID 116777)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone) OWNER TO dberaldi;

--
-- TOC entry 717 (class 1255 OID 116730)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, text, anyelement, text, anyelement, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, text, anyelement, text, anyelement, text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, anyelement, text) OWNER TO dberaldi;

--
-- TOC entry 723 (class 1255 OID 116736)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, character, anyelement, character, anyelement, character); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, character, anyelement, character, anyelement, character) RETURNS character
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, anyelement, character) OWNER TO dberaldi;

--
-- TOC entry 729 (class 1255 OID 116742)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer) RETURNS integer
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer) OWNER TO dberaldi;

--
-- TOC entry 735 (class 1255 OID 116748)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint) RETURNS bigint
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint) OWNER TO dberaldi;

--
-- TOC entry 741 (class 1255 OID 116754)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric) RETURNS numeric
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric) OWNER TO dberaldi;

--
-- TOC entry 747 (class 1255 OID 116760)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, date, anyelement, date, anyelement, date); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, date, anyelement, date, anyelement, date) RETURNS date
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, anyelement, date) OWNER TO dberaldi;

--
-- TOC entry 753 (class 1255 OID 116766)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone) RETURNS time without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone) OWNER TO dberaldi;

--
-- TOC entry 759 (class 1255 OID 116772)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone) OWNER TO dberaldi;

--
-- TOC entry 765 (class 1255 OID 116778)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone) OWNER TO dberaldi;

--
-- TOC entry 718 (class 1255 OID 116731)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, text, anyelement, text, anyelement, text, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, text, anyelement, text, anyelement, text, text) RETURNS text
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, text, anyelement, text, anyelement, text, text) OWNER TO dberaldi;

--
-- TOC entry 724 (class 1255 OID 116737)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, character, anyelement, character, anyelement, character, character); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, character, anyelement, character, anyelement, character, character) RETURNS character
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, character, anyelement, character, anyelement, character, character) OWNER TO dberaldi;

--
-- TOC entry 730 (class 1255 OID 116743)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer, integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer, integer) RETURNS integer
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, integer, anyelement, integer, anyelement, integer, integer) OWNER TO dberaldi;

--
-- TOC entry 736 (class 1255 OID 116749)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint, bigint); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint, bigint) RETURNS bigint
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, bigint, anyelement, bigint, anyelement, bigint, bigint) OWNER TO dberaldi;

--
-- TOC entry 742 (class 1255 OID 116755)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric, numeric); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric, numeric) RETURNS numeric
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, numeric, anyelement, numeric, anyelement, numeric, numeric) OWNER TO dberaldi;

--
-- TOC entry 748 (class 1255 OID 116761)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, date, anyelement, date, anyelement, date, date); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, date, anyelement, date, anyelement, date, date) RETURNS date
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, date, anyelement, date, anyelement, date, date) OWNER TO dberaldi;

--
-- TOC entry 754 (class 1255 OID 116767)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone, time without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone, time without time zone) RETURNS time without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, time without time zone, anyelement, time without time zone, anyelement, time without time zone, time without time zone) OWNER TO dberaldi;

--
-- TOC entry 760 (class 1255 OID 116773)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp without time zone, anyelement, timestamp without time zone, anyelement, timestamp without time zone, timestamp without time zone) OWNER TO dberaldi;

--
-- TOC entry 766 (class 1255 OID 116779)
-- Dependencies: 5
-- Name: decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_decode';


ALTER FUNCTION public.decode(anyelement, anyelement, timestamp with time zone, anyelement, timestamp with time zone, anyelement, timestamp with time zone, timestamp with time zone) OWNER TO dberaldi;

--
-- TOC entry 695 (class 1255 OID 116700)
-- Dependencies: 5
-- Name: dump("any"); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION dump("any") RETURNS character varying
    LANGUAGE c
    AS '$libdir/orafunc', 'orafce_dump';


ALTER FUNCTION public.dump("any") OWNER TO dberaldi;

--
-- TOC entry 666 (class 1255 OID 116989)
-- Dependencies: 5
-- Name: dump(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION dump(text) RETURNS character varying
    LANGUAGE c
    AS '$libdir/orafunc', 'orafce_dump';


ALTER FUNCTION public.dump(text) OWNER TO dberaldi;

--
-- TOC entry 696 (class 1255 OID 116701)
-- Dependencies: 5
-- Name: dump("any", integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION dump("any", integer) RETURNS character varying
    LANGUAGE c
    AS '$libdir/orafunc', 'orafce_dump';


ALTER FUNCTION public.dump("any", integer) OWNER TO dberaldi;

--
-- TOC entry 667 (class 1255 OID 116990)
-- Dependencies: 5
-- Name: dump(text, integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION dump(text, integer) RETURNS character varying
    LANGUAGE c
    AS '$libdir/orafunc', 'orafce_dump';


ALTER FUNCTION public.dump(text, integer) OWNER TO dberaldi;

--
-- TOC entry 680 (class 1255 OID 209581)
-- Dependencies: 1590 5
-- Name: get_library_id(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION get_library_id(x text) RETURNS text
    LANGUAGE plpython3u IMMUTABLE
    AS $$
""" Get the library ID from the string x. The library ID is extracted by:
- Split x at each '.' (lib IDs can't contain dots)
- Match each item against the list of library IDs in libraries.library_id
- Return the resulting item or NULL if no match is found or more than one match is found

EXAMPLE
select get_library_id('ds019_ctrl_24h.slx-5010') => ds019_ctrl_24h
select get_library_id('nonsense.ds019_ctrl_24h.fq.gz') => ds019_ctrl_24h
select get_library_id('ds019_ctrl_24h.ds020_ctrl_24h') => NULL (More than one lib id found)
select get_library_id('nonsense') => NULL
"""

xlist= set(x.split('.'))

" Get all library IDs"
cur= plpy.execute('select library_id from libraries')
libids= []
for i in range(0, cur.nrows()):
    libids.append(cur[i]['library_id'])

xmatch= []
for m in xlist:
    " Match each item in xlist against all lib IDs"
    if m in libids:
        xmatch.append(m)
        
if xmatch == [] or len(xmatch) > 1:
    return(None)
if len(xmatch) == 1:
    return(xmatch[0])

$$;


ALTER FUNCTION public.get_library_id(x text) OWNER TO dberaldi;

--
-- TOC entry 674 (class 1255 OID 31799)
-- Dependencies: 1589 5
-- Name: names(text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION names(tname text, sep text DEFAULT ', '::text, quote text DEFAULT 'quote_literal'::text, orderby text DEFAULT 'ordinal_position'::text, schema text DEFAULT NULL::text) RETURNS text
    LANGUAGE plpgsql
    AS $$
/* 
Return the column names of table 'tname' as a single string conveniently quoted
and separated for use in other scripts.

Essentially names() queries *information_schema.columns* with the passed args 
and uses array_to_string(array_agg(), sep) to reformat the output.

Requires PostgreSQL 9.x or above as it uses named arguments.

ARGUMENTS

  tname <no default>:
     The table for which column names have to be returned. 
     This string passed to "...WHERE table_name = quote_literal(tname) ..."

  sep <', '>: 
     A string to separate the column names (passed to 
     array_to_string(column_array, sep))

  quote <'quote_literal'>: 
     Determines how column names should be quoted inside the returned string. 
     Options are:
       - 'quote_literal': Keyword to single-quote each name using function 
                          quote_literal()
       - 'quote_ident':   Keyword to double-quote names containg capital
                          letters or metacharacters using quote_ident()
       - any string:      This string will be concatenated exactly as is.
       
  orderby <'ordinal_position'>: 
     Order in which names shuld be returned. It should be a column name in 
     information_schema.columns as it is passed to the ORDER BY clause in 
     SELECT ... FROM information_schema.columns.
     Use 'ordinal_position' (defualt) for the order in the table or 
     'column_name' for alphanumeric order (ascending order only)
     
  schema <NULL>: 
     Schema where tname should be found. NULL (defualt) queries the entire
     information_schema.columns table.

EXAMPLES:

  select names('columns', schema := 'information_schema'); 
  >>> 'table_catalog', 'table_schema', 'table_name', ...
  
  select names('columns', schema := 'information_schema', sep := E'\n'); -- NOTE: E'' to enable interpretation of \n as newline
  >>> 'table_catalog'
      'table_schema'
      'table_name'
       ...
       
  select names('columns', schema := 'information_schema', quote := '"');
  >>> "table_catalog", "table_schema", "table_name", ...

  select names('columns', schema := 'information_schema', quote := 'quote_ident'); -- Convenient to copy and paste in a SELECT query
  >>> table_catalog, table_schema, table_name, ...

TODO:
  - Enable descending ordering of orderby.
*/
  DECLARE colnames text;
  DECLARE whereschema text;
  BEGIN

  IF     quote = 'quote_literal' THEN quote := 'quote_literal(column_name::text)'; 
  ELSEIF quote = 'quote_ident'   THEN quote := 'quote_ident(column_name::text)';
  ELSE   quote := quote_literal(quote) || '|| column_name::text ||' || quote_literal(quote);
  END IF;

  IF schema IS NULL THEN whereschema := '';
  ELSE whereschema := ' AND table_schema = ' || quote_literal(schema);
  END IF;
  
  DROP TABLE IF EXISTS tmp_namescols;
  EXECUTE 'CREATE TEMP TABLE tmp_namescols AS (
      SELECT ' || quote || ' AS q_column_name
      FROM information_schema.columns 
      WHERE table_name = ' || quote_literal(tname) || whereschema 
      || ' ORDER BY ' || quote_ident(orderby) || ')' ;
  
  SELECT array_to_string(array_agg(q_column_name), sep) INTO colnames FROM tmp_namescols; 

  RETURN colnames;
  END;
$$;


ALTER FUNCTION public.names(tname text, sep text, quote text, orderby text, schema text) OWNER TO dberaldi;

--
-- TOC entry 692 (class 1255 OID 116697)
-- Dependencies: 5
-- Name: nanvl(real, real); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION nanvl(real, real) RETURNS real
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $_$;


ALTER FUNCTION public.nanvl(real, real) OWNER TO dberaldi;

--
-- TOC entry 693 (class 1255 OID 116698)
-- Dependencies: 5
-- Name: nanvl(double precision, double precision); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION nanvl(double precision, double precision) RETURNS double precision
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $_$;


ALTER FUNCTION public.nanvl(double precision, double precision) OWNER TO dberaldi;

--
-- TOC entry 694 (class 1255 OID 116699)
-- Dependencies: 5
-- Name: nanvl(numeric, numeric); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION nanvl(numeric, numeric) RETURNS numeric
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $_$;


ALTER FUNCTION public.nanvl(numeric, numeric) OWNER TO dberaldi;

--
-- TOC entry 590 (class 1255 OID 28514)
-- Dependencies: 5 1590
-- Name: normalize(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION normalize(arg_string text) RETURNS text
    LANGUAGE plpython3u
    AS $_$

""" -------------------------[ normalize-1.1 ]---------------------------------

DESCRIPTION:
Opposite of cross_tab(): Converts a table from cross-tab format to conventional
database format (long, normalize).

ARGUMENTS:
A single string representing a python dictionary with pseudo-arguments assigned
to values by ':' and separated by ','. Pseudo-arguments:

ct_table:      The input table to be normalized. Either a table name or an SQL
               statement returning a set of rows ('SELECT ... FROM ... ')
               
dest_table:    Name of destination table to hold the output of normalize(). Default
               is 'out_normalize'

which:         A python list (or tuple) of column names and/or column indexes
               to be normalized. For example, each of these columns could be
               a time point in a time course experiment. No default
               Mixing indexes and names is allowed. Nested lists/tuples also
               allowed. Repeating the same column more than once (i.e. creating
               duplicate rows) is allowed.
               NB: The first column in 'ct_table' has index 1 (not 0 as in python)
               NB: If you use the range() function to generate indexes remember
                   that the upper limit of range() is excluded. E.g
                   [1,2,3,4] == range(1, 5)

which_nn:      A python list (or tuple) of column names and/or column indexes
               NOT to be normlized. I.e. simply to be repeated as row headers.
               This could be the subject IDs in a time course experiment.
               A column can be specified only once.
               TODO: All the columns not included in 'which' are repeated
               NB: See which arg.
               
level_header:  An optional name for the normalized column holding the normalized
               column NAMES. (This could be something like 'time_point' in a
               normalized time course table). Defualt 'level'

value_header:  An optional name for the normalized column holding the normalized
               column VALUES. (This could be something like 'weight' in a
               normalized time course table). Defualt 'value'
               
overwrite: Logical. Should a pre-existing dest_table be ooverwritten? Default False

temp:          Logical. Should dest_table be created as temporary table? Default True

WARNINGS and BUGS:

EXAMPLES:
--               col index: 1                          2            3                        4               5               6
CREATE TEMP TABLE tmp_norm (subj_id character varying, age integer, tp_00h double precision, tp_06h numeric, tp_12h numeric, tp_24h numeric);
INSERT INTO tmp_norm VALUES('r1', 1, 0.1, 6.1, 12.1, 24.1);
INSERT INTO tmp_norm VALUES('r2', 2, 0.2, Null, 12.2, 24.2);
INSERT INTO tmp_norm VALUES('r3', 3, 0.3, 6.3, 12.3, 24.3);
INSERT INTO tmp_norm VALUES('r4', 4, 0.4, 6.4, 12.4, 24.4);
select * from tmp_norm;

-- 
select normalize($$ ct_table:'tmp_norm', which: range(3, 7), which_nn: (1,2), overwrite: True $$);
select * from out_normalize;
DROP TABLE tmp_norm;

# -----------------------[ Function starts here ]------------------------------ """

import os
import csv
import sys
" ---------------------[ Parse arguments ]----------------------------------- "
## List of pseudo-arguments
ct_table= 'ct_table'     
dest_table= 'dest_table'
which= 'which'
level_header= 'level_header'
value_header= 'value_header'
overwrite= 'overwrite'
which_nn= 'which_nn'
temp= 'temp'

## Convert the argument string to a dictionary
try:
    arg_dict= eval('{' + arg_string + '}')
except:
    return("Error parsing the argument string:\n" + arg_string +
           "\n- Does it contain '=' instead of ':' assignment sign?\n- Are the argument names correct?")

## Retrieve user's parameters (try:...) or assign defaults (except:...)
try:
    ct_table= arg_dict[ct_table]
except:
    return('Error in normalize(): argument ct_table is empty')
try:
    dest_table= arg_dict[dest_table]
except:
    dest_table= None
try:
    which= arg_dict[which]
    if min(which) < 0:
        return('Invalid column indexes for arg which.')
    if type(which) == str or type(which) == int:
        x= []
        x.append(which)
        which= x
except:
    return('Error in normalize(): specify columns to normalize (arg which:)')
try:
    level_header= arg_dict[level_header]
except:
    level_header= 'level'
try:
    value_header= arg_dict[value_header]
except:
    value_header= 'value'
try:
    overwrite= arg_dict[overwrite]
    if type(overwrite) != bool:
        return("Parameter passed to 'overwrite' is not of type boolean (True/False)")
except:
    overwrite= False
try:
    which_nn= arg_dict[which_nn]
    if type(which_nn) == str or type(which_nn) == int:
        x= []
        x.append(which_nn)
        which_nn= x
except:
    which_nn= None
try:
    temp= arg_dict[temp]
    if type(temp) != bool:
        return("Parameter passed to 'temp' is not of type boolean (True/False)")
except:
    temp= True
" -------------------------[ Define functions ]------------------------------ "

def flatten(lst):
    " Returns a single list from a list containing nested lists "
    for elem in lst:
        if type(elem) in (tuple, list):
            for i in flatten(elem):
                yield(i)
        else:
            yield(elem)

def colname2position(which, tbl):
    " Returns the ordinal positions of the columns in table 'tbl' specified by 'which' "
    qry_def= "SELECT ordinal_position, column_name FROM information_schema.columns WHERE table_name LIKE '" + tbl + "';"
    names_ord= plpy.execute(qry_def)
    ordinals= []
    for i in which:
        if type(i) == int:
            ordinals.append(i)
        else:
            qry_pos= "SELECT ordinal_position FROM information_schema.columns WHERE table_name LIKE '" + tbl + "' AND column_name LIKE '" + i+ "';"
            n= plpy.execute(qry_pos)
            if len(n) == 0:
                sys.exit('Column "' + i + '" does not exists.')
            pos= int(n[0]['ordinal_position'])
            ordinals.append(pos)
    return(ordinals)

def normalize_line():
    for i in norm_headers:
        u_cols= [line[col] for col in row_headers] ## Un-normalized columns
        u_cols.append(i)             ## Level name
        u_cols.append(line[i])
        tmp_fopen.writerow(u_cols)
    return()

" ---------------------------------------------------------- "

try:
    tmp_file= '/tmp/tmp_normalized_x1z2v3.txt'
    tmp_f= open(tmp_file, 'w')
    tmp_fopen= csv.writer(tmp_f, delimiter='\t', quotechar='"', lineterminator= '\n')
except:
    try:
        tmp_file= 'C:/Windows/Temp/tmp_normalized_x1z2v3.txt'
        tmp_f= open(tmp_file, 'w')
        tmp_fopen= csv.writer(tmp_f, delimiter='\t', quotechar='"', lineterminator= '\n')
    except:
        return('Could not find a suitable directory for file "tmp_file".')

if ct_table[0] == ct_table[-1] == '"':
    ct_table= ct_table[1:-1]

" -----------------------[ Get table definition for ct_table  ]----------------- "

ct_table= ct_table.lstrip()
if (ct_table.lower()).startswith('select '):
    " Do this if ct_table is a select query "
    ct_table= ct_table.rstrip(';')
    qry_load_ct_table= 'CREATE TABLE tmp_normalized_x1z2v3 AS(\n  SELECT * FROM (' + ct_table + ' ) AS t1\n  );'
    plpy.execute(qry_load_ct_table)
    if dest_table is None:
        dest_table= 'out_normalize'
elif ct_table:
    " Try this if ct_table is a table  "
    qry_load_ct_table= 'CREATE TABLE tmp_normalized_x1z2v3 AS (\n  SELECT * FROM "' + ct_table + '"\n  );'
    plpy.execute(qry_load_ct_table)
    if dest_table is None:
        dest_table= 'out_normalize'
else:
    return('Error. Could not retrieve data from "' + ct_table + '"')

" Fetch table definition "
qry_ct_table_names= "SELECT ordinal_position, column_name, data_type FROM information_schema.columns WHERE table_name LIKE 'tmp_normalized_x1z2v3';"
table_def= plpy.execute(qry_ct_table_names)

" Column indexes 1-based (postgres)"

which= list(flatten(which))
which_nn= list(flatten(which_nn))
  

which= colname2position(which, 'tmp_normalized_x1z2v3')

if max(which) > len(table_def):
    " Check the indexes in which are viable"
    plpy.execute('DROP TABLE tmp_normalized_x1z2v3;')
    return("Error: Index(es) in 'which' exceed the number of columns in input table (" + str(len(table_def)) + ' cols).')

which_all= [int(table_def[i]['ordinal_position']) for i in range(0, len(table_def))]

if which_nn is None:
    which_nn= [int(which_all[i]) for i in range(0, len(table_def)) if which_all[i] not in which]
else:
    which_nn= colname2position(which_nn, 'tmp_normalized_x1z2v3')
    if max(which_nn) > len(table_def):
        " Check the indexes in which_nn are viable"
        plpy.execute('DROP TABLE tmp_normalized_x1z2v3;')
        return("Error: Index(es) in 'which_nn' exceed the number of columns in input table (" + str(len(table_def)) + ' cols).')
    which_nn= [int(which_all[i-1]) for i in which_nn]

" All column names and datatypes"
headers= [table_def[i]['column_name'] for i in range(0, len(table_def))]
datatypes= [table_def[i]['data_type'] for i in range(0, len(table_def))]

" Names and datatypes for columns NOT to be normalized "
row_headers= [headers[i-1] for i in which_nn]

row_datatype= []
for i in which_nn:
    dt= datatypes[i-1]
    if datatypes[i-1] == 'unknown':
        row_datatype.append('text')
    else:
        row_datatype.append(dt)

" Names and datatypes of the columns to be normalized "
norm_headers= [headers[i-1] for i in which]
norm_datatype= [table_def[i-1]['data_type'] for i in which]

" -------------------------[ Define normalized table ]----------------------- "

" Guess datatype for the normalized column "
if len(set(norm_datatype).difference(set(['bigint', 'int8', 'integer', 'int4', 'int', 'smallint']))) == 0:
    norm_datatype= 'bigint'
    
elif len(set(norm_datatype).difference(set(['bigint', 'int8', 'integer', 'int4', 'int', 'smallint', 'double precision', 'float8', 'numeric', 'decimal', 'real', 'float4']))) == 0:
    norm_datatype= 'double precision'
    
elif len(set(norm_datatype).difference(set(['bigint', 'int8', 'integer', 'int4', 'int', 'smallint', 'double precision', 'float8', 'numeric', 'decimal', 'real', 'float4', 'character varying', 'varchar']))) == 0:
    norm_datatype= 'varchar'
    
else:
    norm_datatype= 'text'

" Format column names and dataypes to go to CREATE statement "
all_colnames= row_headers + [level_header, value_header]
all_colnames= ['"' + x + '"' for x in all_colnames]

all_datatypes= row_datatype + ['text', norm_datatype]

defin= zip(all_colnames, all_datatypes)
" Prepare and execute CREATE statement for normalized table "
qry_check= "SELECT * FROM information_schema.columns WHERE table_name LIKE '" + dest_table + "';"
check_dt= plpy.execute(qry_check)

if overwrite is True and len(check_dt) != 0:
    try:
        qry_drop= 'DROP TABLE "' + dest_table + '";'
        plpy.execute(qry_drop)
    except:
        pass

if temp is True:
    temp= 'TEMPORARY'
else:
    temp= ''

qry_long= 'CREATE ' + temp + ' TABLE "' + dest_table + '" (\n  '

for xdef in defin:
    """                 col name         data-type       """
    qry_long= qry_long + xdef[0] + ' ' + xdef[1] + ',\n  '

qry_long= qry_long.rstrip(',\n  ')
qry_long= qry_long + '\n  );'
plpy.execute(qry_long)

times= plpy.execute('SELECT timeofday() AS this_time;')
times= times[0]['this_time']

qry_comment= 'COMMENT ON TABLE "' + dest_table + '" IS ' + '$$Table created from (' + ct_table + ') by function normalize() on ' + str(times) + '$$;'
plpy.execute(qry_comment)

" ---------------------[ Normalize data in ct_table  ]----------------------- "

qry_ct_data= 'SELECT * FROM tmp_normalized_x1z2v3;'
cross_tab= plpy.execute(qry_ct_data)

for i in range(0, len(cross_tab)):
    line= cross_tab[i]
    normalize_line()

tmp_f.close()
os.system('chmod 777 ' + tmp_file)
qry_copy= 'COPY ' + dest_table + " FROM '" + tmp_file + "' WITH CSV DELIMITER E'\t';"
plpy.execute(qry_copy)

plpy.execute('DROP TABLE tmp_normalized_x1z2v3;')
os.remove(tmp_file)

warn=str()
if len(which) != len(set(which)):
    which.sort()
    warn= "Warning: Duplicate column indexes found in arg 'which': " + str(which) + '\n'
return(warn + 'Normalized table sent to ' + temp + ' "' + dest_table + '".')

$_$;


ALTER FUNCTION public.normalize(arg_string text) OWNER TO dberaldi;

--
-- TOC entry 711 (class 1255 OID 116724)
-- Dependencies: 5
-- Name: nvl(anyelement, anyelement); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION nvl(anyelement, anyelement) RETURNS anyelement
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_nvl';


ALTER FUNCTION public.nvl(anyelement, anyelement) OWNER TO dberaldi;

--
-- TOC entry 712 (class 1255 OID 116725)
-- Dependencies: 5
-- Name: nvl2(anyelement, anyelement, anyelement); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION nvl2(anyelement, anyelement, anyelement) RETURNS anyelement
    LANGUAGE c IMMUTABLE
    AS '$libdir/orafunc', 'ora_nvl2';


ALTER FUNCTION public.nvl2(anyelement, anyelement, anyelement) OWNER TO dberaldi;

--
-- TOC entry 672 (class 1255 OID 30807)
-- Dependencies: 1590 5
-- Name: os_path_join(integer); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION os_path_join(integer) RETURNS text
    LANGUAGE plpython3u
    AS $$
import os

return(int)

$$;


ALTER FUNCTION public.os_path_join(integer) OWNER TO dberaldi;

--
-- TOC entry 673 (class 1255 OID 30809)
-- Dependencies: 1590 5
-- Name: os_path_join(text, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION os_path_join(p text, f text) RETURNS text
    LANGUAGE plpython3u
    AS $$
import os

return(os.path.join(p, f))

$$;


ALTER FUNCTION public.os_path_join(p text, f text) OWNER TO dberaldi;

--
-- TOC entry 676 (class 1255 OID 151413)
-- Dependencies: 5 1590
-- Name: pg_blast(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION pg_blast(arg_string text) RETURNS text
    LANGUAGE plpython3u
    AS $_$
"""
DOCUMENTATION
See http://code.google.com/p/postgresql-pg-blast/wiki/Manual
"""
import sys
import subprocess
import tempfile
import os
import datetime
import shutil

" ---------------------[ Parse arguments ]----------------------------------- "

## List of pseudo-arguments
query= 'query'           ## SELECT statement returning the query sequences. 1st column: sequence names, 2nd column: sequences, other cols ignored
db= 'db'                 ## SELECT statement returning the subject sequences (database sequences). 1st column: sequence names, 2nd column: sequences, other cols ignored
usedb= 'usedb'           ## Basename of the (local) subject database to query against. Incompatible with option db. <string deafult None>
outfile= 'outfile'       ## Name of the output file from blast. This is passed to arg blast's arg '-out'. 
outfmt= 'outfmt'         ## Output format for blast. Default is 6 (tabular) which will also cause pg_blast to upload the output file to postgres. Any other format will not be uploaded. <int>
blast_opt= 'blast_opt'   ## String of BLAST options <string>
table= 'table'           ## BLAST output is going to be uploaded by COPY to this table. It will be created anew <string | None>. None (default) will cause pg_blast() not to import the results.
temp= ''                 ## Should result table be created as temporary <True, False> ? Ignored if table: None
overwrite= 'overwrite'   ## If result table already exists, should it be overwritten <True, False>? Ignored if table: None
wdir= 'wdir'             ## Working dir for blast(). A dir called "pg_blast" here (if it doesn't exist already). Default to OS temp dir.
remove_dir= 'remove_dir' ## Should the working dir be removed at the end of the run? <True/False> Default False.
append= 'append'         ## Should the result table be appended to (existing) 'table'? If the table doesn't exist it will *not* be created and an exception will follow. <True|False> Default False

## Convert the argument string to a dictionary
try:
    arg_dict= eval('{' + arg_string + '}')
except:
    sys.exit("Error parsing the argument string:\n" + arg_string + 
           "\n- Does it contain '=' instead of ':' assignment sign?\n- Are the argument names correct?")

## Arg-parser
## Retrieve user's parameters (try:...) or assign defaults (except:...)
try:
    query= arg_dict[query]
except:
    sys.exit('Error in blast(): argument query is empty')
try:
    db= arg_dict[db]
except:
    db= None
try:
    usedb= arg_dict[usedb]
except:
    usedb= None
try:
    table= arg_dict[table]
except: 
    table= None
try:
    outfile= arg_dict[outfile]
except: 
    outfile= None
try:
    outfmt= arg_dict[outfmt]
except: 
    outfmt= None
try:
    blast_opt= arg_dict[blast_opt]
except:
    blast_opt= ''
try:
    temp= arg_dict[temp]
except:
    temp= False
try:
    overwrite= arg_dict[overwrite]
except:
    overwrite= False
try:
    wdir= arg_dict[wdir]
except:
    wdir= tempfile.gettempdir()
try:
    remove_dir= arg_dict[remove_dir]
except:
    remove_dir= False
try:
    append= arg_dict[append]
except:
    append= False
    
" -----------------------------[Check arguments]----------------------------- "
if temp is True:
    temp= 'TEMP'
elif temp is False:
    temp= ''
else:
    sys.exit('Argument temp is not of type boolean: %s' %temp)

if db is None and usedb is None:
    sys.exit('Args db and usedb are both missing (one and one only must be given)')
if db is not None and usedb is not None:
    sys.exit('Args db and usedb are both assigned (one and one only must be given)')

if type(overwrite) != bool:
    sys.exit('Argument overwrite is not of type boolean: %s' %overwrite)

if type(remove_dir) != bool:
    sys.exit('Argument remove_dir is not of type boolean: %s' %remove_dir)

if type(append) != bool:
    sys.exit('Argument append is not of type boolean: %s' %append)

if outfmt is None:
    outfmt= '-outfmt 6'
else:
    outfmt= '-outfmt ' + str(outfmt)

" -----------------------[ Settings ]---------------------------------------  "
## This variable has to be set before executing pg_blast-x.y.sql
blast_path= '/Applications/blast+/ncbi-blast-2.2.26+/bin' ## 'C:/"Program Files"/NCBI/blast-2.2.24+/bin'

" --------------------------[ Define  functions ]---------------------------- "

def get_wdir(wdir):
    """ Set the working dir for blast """
    if os.path.isdir(os.path.join(wdir, 'pg_blast')):
        wdir_readtable= os.path.join(wdir, 'pg_blast')
    else:
        try:
            wdir_readtable= os.path.join(wdir, 'pg_blast')
            os.mkdir(wdir_readtable)
        except:
            sys.exit("get_wdir: I cannot set or make dir '%s'" %(wdir_readtable))
    try:
        os.system('chmod 0777 %s' %(wdir_readtable))
        ## os.chmod(wdir_readtable, '0777')
    except:
        sys.exit("get_wdir: I cannot set permission on my working dir %s'" %(wdir_readtable))
    ## wdir_readtable= wdir_readtable.replace('\\', '/') ## This is ugly but necessary because COPY won't like backslashes
    return(wdir_readtable)

def right_now():
    """ Return current time as a string like this
    [2010-12-04 15:56:02.880000] 
    """
    t= '[' + datetime.datetime.now().strftime('%c') + ']'
    return(t)

def get_query_colnames(sql_query):
    """ Return a list with the column names in the query string sql_query.
    The order of names in the list is the same as in the query.
    """
    qry_table_colnames= 'DROP TABLE IF EXISTS colnames; CREATE TEMP TABLE colnames ON COMMIT DROP AS (SELECT * FROM (' + sql_query + ') AS t WHERE 1 = 2);'
    plpy.execute(qry_table_colnames)
    qry_colnames= "select * from information_schema.columns where table_name = 'colnames' order by ordinal_position;"
    colnames_results= plpy.execute(qry_colnames)
    nrows= colnames_results.nrows()
    colnames= []
    for i in range(0, nrows):
         colnames.append(colnames_results[i]["column_name"])
    return(colnames)

def cmdprep_makeblastdb(input_seq, blast_path= blast_path, dbtype= 'nucl'):
    """ Prepare the command line to run makeblastdb
    blast_path: path to blast suite
    input_seq:  fasta input file
    """
    makeblastdb= blast_path + '/' + 'makeblastdb'
    cmd_line= makeblastdb + ' -in ' + input_seq + ' -dbtype ' + dbtype 
    return(cmd_line)

def cmdprep_blast(outfmt, query, db, blast_outfile, blast_path= blast_path, blast_args= ''):
    """ Prepare the command line to run blast
    blast_path: path to blast suite
    db:         sequence database (passed to argument -db)
    blast_args: string of arguments passed to blastn, must not include the args: -query -db -outfmt -out (e.g. 'evalue 0.01 word_size 12' )
    """
    cmd_line= blast_path + '/blastn ' + outfmt + ' -query ' + query + ' -db ' + db + ' ' + blast_args + ' -out ' + blast_outfile
    return(cmd_line)

" -------------------------[ Set working dir ]------------------------------- "

wdir= get_wdir(wdir)
    
" -------------------------[ Open log file ]--------------------------------- "

"""
These are not used...
yy= str( (datetime.datetime.now()).year )
MM= str( (datetime.datetime.now()).month )
dd= str( (datetime.datetime.now()).day )
hh= str( (datetime.datetime.now()).hour )
mm= str( (datetime.datetime.now()).minute )
ss= str( (datetime.datetime.now()).second )
ms= str( (datetime.datetime.now()).microsecond )

current_time= yy + MM + dd + '_' + hh + 'h-' + mm + 'm-' + ss + 's-' + ms + 'us'
"""
p= subprocess.Popen(blast_path + '/blastn -version', shell=True, stdout= subprocess.PIPE, stderr= subprocess.PIPE)
blast_version= p.stdout.read()

log_filename= 'pg_blast.log'
log_filename= os.path.join(wdir, log_filename)
log_file= open(log_filename, 'w')
log_file.write('Log file for function "pg_blast" executed by PostgreSQL\n')
log_file.write('Log file created %s\n\n' %right_now())
log_file.write('blastn -version:                    %s\n' %blast_version)
log_file.write('Output directory:                   %s\n' %wdir)

" ----------------------[Prepare query sequences ]---------------------------- "

query_fasta= os.path.join(wdir, 'pg_blast_query.fa')
log_file.write('Query sequences from sql query:     %s\n'%query)
log_file.write('Query sequences sent to fasta file: %s\n' %query_fasta)

## Remove possible trailing ; from queries
query= query.strip()
query= query.rstrip(';')

## Get the names of the columns in the input query

colnames= get_query_colnames(query)
fasta_query_seqname= colnames[0]
fasta_query_sequence= colnames[1]

## Write-out query files in fasta format
query_table= plpy.execute(query)
nrows= query_table.nrows()

qout= open(query_fasta, 'w')

for i in range(0, nrows):
    seqname= query_table[i][fasta_query_seqname]
    qout.write('>' + seqname + '\n')
    sequence= query_table[i][fasta_query_sequence]
    qout.write(sequence + '\n')
qout.close()

" ----------------------[Prepare database sequences ]---------------------------- "

if db is not None:
    db_fasta= os.path.join(wdir, 'pg_blast_database.fa')
    log_file.write('BLAST database from sql query:      %s\n'%db)
    log_file.write('Database base filename:             %s\n' %db_fasta)

    ## Remove possible trailing ; from queries
    db= db.strip()
    db= db.rstrip(';')

    ## Get the names of the columns in the input query
    colnames= get_query_colnames(db)
    fasta_db_seqname= colnames[0]
    fasta_db_sequence= colnames[1]

    ## Write-out query files in fasta format
    db_table= plpy.execute(db)
    nrows= db_table.nrows()

    qout= open(db_fasta, 'w')

    for i in range(0, nrows):
        seqname= db_table[i][fasta_db_seqname]
        qout.write('>' + seqname + '\n')
        sequence= db_table[i][fasta_db_sequence]
        qout.write(sequence + '\n')
    qout.close()
elif usedb is not None:
    db_fasta= usedb
else:
    sys.exit('Unexpected error while trying to prepare the database files')
    
" -----------------------[ Prepare and run blast ]--------------------------- "

if usedb is None:
    cmd_makeblastdb= cmdprep_makeblastdb(db_fasta, blast_path= blast_path, dbtype= 'nucl')
    log_file.write('Execute makeblastdb:                %s\n' %cmd_makeblastdb)
    p= subprocess.Popen(cmd_makeblastdb, shell=True, stdout= subprocess.PIPE, stderr= subprocess.PIPE)
    makeblastdb_stdout= p.stdout.read().decode('utf-8')
    makeblastdb_stderr= p.stderr.read().decode('utf-8')
    if makeblastdb_stderr != "":
        log_file.write(makeblastdb_stderr)
        sys.exit(makeblastdb_stderr)

if outfile is None:
    blast_outfile= query_fasta + '.blastout'
else:
    blast_outfile= outfile

cmd_blast= cmdprep_blast(outfmt, query_fasta, blast_outfile= blast_outfile, blast_path= blast_path, db= db_fasta, blast_args= blast_opt)
log_file.write('Execute blastn:                     %s\n' %cmd_blast)
p= subprocess.Popen(cmd_blast, shell=True, stdout= subprocess.PIPE, stderr= subprocess.PIPE)
blast_stdout= p.stdout.read().decode('utf-8')
blast_stderr= p.stderr.read().decode('utf-8')
if blast_stderr != "":
    log_file.write(blast_stderr)
    sys.exit(blast_stderr)

" ------------------------------[ Import result table ]------------------------ "

if outfmt == '-outfmt 6' and table is not None:
    " Import only if output format is suitable "
    if append is False:
        " Create new table if results are not to be appended to existing table "
        if overwrite is True:
            qry_drop_table= 'DROP TABLE IF EXISTS ' + table
            plpy.execute(qry_drop_table)

        qry_table_blast= 'CREATE ' + temp + ' TABLE ' + table + """ (
            qseqid text,
            sseqid text,
            pident double precision,
            length int,
            mismatch int,
            gapopen int,
            qstart int,
            qend int,
            sstart int,
            send int,
            evalue double precision,
            bitscore double precision
        )"""
        plpy.execute(qry_table_blast)
        qry_comment= """COMMENT ON TABLE %s IS $$BLAST output generated by function pg_blast() on %s\nBLASTN command was\n%s\nSee also log dir %s$$""" %(table, right_now(), cmd_blast, wdir)
        plpy.execute(qry_comment)
    qry_copy_table= 'COPY ' + table + ' FROM $$' + blast_outfile + "$$ WITH DELIMITER E'\t'"
    plpy.execute(qry_copy_table)
    log_file.write('Results imported with:              %s\n' %qry_copy_table)
elif outfmt != '-outfmt 6' and table is not None:
    log_file.write('\n*** NOTICE: Blast output not imported to table %s as the blast output format is not compatible: %s\n' %(table, outfmt))
elif table is None:
    log_file.write('\n*** NOTICE: Blast output not imported to postgres as no output table has been specified\n')
else:
    sys.exit('Unexpected exception')

log_file.write('\nExecution completed %s' %right_now())
if remove_dir is True:
    log_file.write('\n\n(Working directory is going to be removed)')
log_file.close()
log_file= open(log_filename, 'r')
log_text= log_file.readlines()
log_text= ' '.join(log_text)
log_file.close()

if remove_dir is True:
    shutil.rmtree(wdir)
else:
    os.system('chmod -R %s 666' %(wdir))
return(log_text)

$_$;


ALTER FUNCTION public.pg_blast(arg_string text) OWNER TO dberaldi;

--
-- TOC entry 675 (class 1255 OID 30950)
-- Dependencies: 1589 5
-- Name: raise_exception(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION raise_exception(text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
-- This function raises an exception and returns a message passed as arg. It has been used in RULEs where an invalid insert or update is performed. 
  BEGIN
     -- Raise an exception.
    RAISE EXCEPTION '%', $1;
  END;
$_$;


ALTER FUNCTION public.raise_exception(text) OWNER TO dberaldi;

--
-- TOC entry 578 (class 1255 OID 24722)
-- Dependencies: 1590 5
-- Name: read_table(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION read_table(arg_string text) RETURNS text
    LANGUAGE plpython3u
    AS $_$
version= '0.97-alpha-py3'
docstring= """ read_table %s

Author: Dario Beraldi (dario<dot>beraldi<at>ed<dot>ac<dot>uk)

DESCRIPTION:
Function to parse and import data files to new or existing tables.
read_table() parses a data file (see 'Parsing options') and imports it (see
'COPY' and 'CREATE TABLE' opitions). If the target table does not exists
it will be created using the information provided, if given, or read_table 
will automatically create the table. 

The input data file can be gzip-compressed. Lines are not required to be
complete ('rugged' file)

Parsing of CSV files is accomplished through the csv module of Python.

If the data_type arg is None, column datatypes are set to double 
precision or text based on a sample of (up to) 100000 rows taken at regular 
intervals from the file.

At each execution of read_table, a log-file (<input file>.log) is produced
in the working directory given in wdir.

Excel support (new in version 0.96): Spreadsheet saved as txt by win32com.
Use of system independent libraries like xlrd is underway.

REMINDER - Order with which read_table parses each line in file:
skip > [ strip newline chars > apply > blank_lines_skip > comment_char check > 
         split string to list > (fill up incomplete lines) > 
         select > write to tmpfile > (store sample rows) > limit check ] >
CREATE TABLE and/or COPY.

ARGUMENTS:
read_table takes a single string as argument parsed by Python as a dictionary. 
E.g. SELECT read_table($$ <arg.1>:<parameter>, <arg.2>:<parameter> ... $$);

------------------------------[ Import Options ]--------------------------------

file: <string, no default, manadatory>
    File to be imported. If gzip or bzip2 compressed, read_table will read
    directly from it, without unpacking the whole file.
    See the opener() function for how this is done.

table: 'filename' <string>
    Name of the destination table. It can be schema qualified (public.mytable). 
    If not given or None, read_table will assign a tablename as filename(file) 
    without path and extension (e.g. if file:'path/mydata.txt' => table: 'mydata'), 
    in such case table will be created into the public schema (unless temp:True).
    
    Quote the name as necessary if it contains meta-characters 
    (e.g. "My.Table"). Double-quoting is not necessary to maintain 
    case-sensitivity ('public.MyTable' == 'public."MyTable"'). See append and 
    overwrite about how to handle existing tables.

wdir: tempfile.gettempdir()/read_table <None | string>
    Working directory for read_table. A directory named 'read_table' will be 
    created here. In dir read_table parsed temporary files, log files and python 
    functions are dumped. Default (None) to the first temporary dir that pyton 
    can find (e.g. '/tmp/read_table'). To change the default find & replace the 
    variable "wdir= tempfile.gettempdir()". Note that postgres needs permission
    to create its directory on wdir.

excel: <True|False>
    Is 'file' to be imported as Excel spreadsheet? If True, read_table() will try
    to open 'file' as Excel provided that the extension is .xls or .xlsx.
    
sheet: 0 <0|string>
    If file is an Excel spreadsheet, give here the name of the sheet to
    import. Default (0) imports the ActiveSheet.

remove_tmpfile: True <True/False>
    Should the parsed input file be deleted at end of the execution?
    tmp file is written to wdir as <file>.tmp.
       
-------------------------------[ Parsing options ]-----------------------------
       
skip: 0 <integer> 
    Number of lines to be skipped before reading-in the header (if 
    header: True) and the data lines. This many lines are skipped without any
    processing at all.

limit: 0 <integer> 
    Maximum number of data lines to read-in. The header line, if present, as 
    well as eventually commented, skipped, or blank lines (if
    blank_lines_skipped: True) are not counted towards limit.
    Anything other than a positive integer, zero included, means no limit 
   (the default).

blank_lines_skip: 'NA' <True/False | 'NA'>
    Should blank lines be skipped? True and False make such lines be skipped or
    imported, respectively. NA makes read_table assume that blank lines are not 
    present at all and will not check for their presence. NA combined
    with all the other defaults (no lines to skip, no commented, no apply or 
    select no limit) and with data_type set at least in part, will prevent 
    read_table to parse the file. This will make the import of data much faster. 
    NA is converted to True if the file does need to be parsed.
    Note: blank lines are those where line.rstrip('\\r\\n') returns ''. This 
    means that a line made only of tab-delimiters (e.g. \\t\\t\\...) is not 
    considered blank.

comment_char: '' <string>
    A character string which marks comment lines to be skipped. E.g. use '@' to
    skip header lines in a SAM file. Defualt is '' (interpretation of comments 
    turned off).

apply: None <string | list [module, function]>
    Apply to each line a custom defined Python function (actually a script).
    Before being passed to apply, lines are stripped off trailing newline chars.
    The only lines not touched by apply are those skipped by the skip arg.
    The apply function can be supplied directly as string or it can be invoked 
    from a script (module). To invoke from script use the syntax 
    apply:[<script.py>, <function name>].
    The apply function takes the current line as and return a string (the line 
    processed). 
    Reminder:
    - If passed as string, the function must be named apply. Note that
      backslashes must be doubled. Use triple quotes to define the string.
    - If passed as list [<script.py>, <function name>], the module can be 
      anywhere but it has to have extension '.py'
    - Write apply using Linux newline encoding ('\\n') not Windows ('\\r\\n'). 
      Notepad++ is good for this.
    - Variables declared outside apply(line) have to be declared global inside
      apply in order to be modified by apply.
    The string passed to apply is written to file pgrt_apply.py (in the current
    working directory '.../PostgreSQL/x.x/data') and imported as python module. 
    Similarly, if a script is to be loaded, it will be copied to the current
    working dir as pgrt_apply.py and imported.

    Example (more below):    
    apply: """"""
    def apply(line):
       x= 'foo' + line # actions on "line"
       return(x)
    """""" $$);
        
select: None <[list]>
    A python list to select which columns to import. Columns can be identified
    by their ordinal position (N.B. first column has index 0 not 1) or, if
    header:True, by their name. Mixing names and indexes is allowed as well as
    supplying nested list. Default is None which means every column is imported.
    If not not None, allow_rugged has to be False. However, the file can be 
    rugged as long as the columns to import are complete.

    E.g. select the first 2 and last 2 columns, the column named 'col1' and the
    columns between position 6 and 10:
    select: [0, 1, -2, -1, 'col1', range(5, 10)]

allow_rugged: False <True/False>
    Logical. Should incomplete lines be filled with blanks? If False, the 
    default, incomplete lines will rise an error when COPY is executed. 
    allow_rugged:True is incompatible with select not None.

----------------------------[ File format options ]-----------------------------

header: False <True/False | [list]>
    Logical or list. If True, the first non skipped line of file is used as 
    header. If not enough names are present in this line, read_table() will fill 
    the remaining with v1, v2 etc.
    If header: False (the default), file does not have an header and 
    read_table() will assign names as v1, v2 etc.
    If header is a list of names, this list will be used as header (e.g. 
    ['col 1', 'col 2', 'col 3']). Nested lists are allowed. If duplicate names 
    are found, read_table will edit them to be unique and a warning will be 
    reported in the log file.
    Trailing and leading double-quotes in the header names are stripped (names
    are then double-quoted when passed to CREATE TABLE).
    
sep: '\\t' <character>
    The string separating the columns. This argument is passed to 
    python csv.reader, csv.writer (when CSV:True) and DELIMITER in COPY.
    Default is the tab-character.

na_string: '' <string>
    String to identify missing values. Use '', the default, if empty 
    cell means missing value. This argument is passed to COPY NULL.

CSV: True <True/False>   
    Is file to be parsed as CSV? This arguments determines how python and 
    Postgres parse and read-in the data. 
    If True, lines will be parsed using python writer and reader functions in 
    the csv module. If False, lines will be split into columns at every 
    occurrence of sep, i.e. using line.split(sep).
    The CSV is slower than the plain text mode (approx. 1/2?)

quote: '"' <character>
    Used when CSV:True. Specifies the quotation character to pass to python
    csv.reader and csv.writer and to COPY. The default is double-quote.

--------------------------[ CREATE TABLE options ]-----------------------------

overwrite: False <True/False>
    Is the target table to be dropped before importing the new data? Such table 
    is dropped only if it has no dependecies (DROP... RESTRICT). False (default)
    will raise an exception if the target table exists (do not overwrite).

append: False <True/False>
    Should the data in file be appended to table? If append:True and table does 
    not exists it will be created. For safety, if both append and overwrite are
    True, read_table will raise an error.
                
temp: False <True/False>
    Boolean to determine whether target table has to be created as temporary 
    table. False means table will be static.

data_type: None <[list] | {dict}>
    A list or dictionary to instruct CREATE TABLE or None (default) if 
    read_table should infer the data types automatically.
    - If data_type is a list, these types will be assigned to each column 
      vis-a vis. Nested lists are allowed.
    - If data_type is a dictionary, each entry of the dict is a key/value pair
      where the value is the data type and the key is either a column name or an 
      integer corresponding to the column position.
    If not enough types are supplied, the remaining ones are set to text.
    N.B: Column positions start from 0 not 1.
     
    If None, read_table() will assign either int or double precision or text 
    according to a sample of (up to) 10000 rows taken from the file at regular 
    intervals (and including first and last row). 
    If the data is to be appended to an existing table, data_type is ignored.

    E.g: First 3 columns as bigint, 4th as int NOT NULL:
    data_type: [['bigint'] *3, 'int NOT NULL']
    First column to int, column 'col2' to bigint NOT NULL:
    data_type: {0:'int', 'col2':'bigint NOT NULL'}
 
KNOWN BUGS and WARNINGS:
- If data_type is not set, read_table() tries to guess the appropriate datatype
  from a sample of the data. If an exception is not sampled (e.g. a string in a 
  column of mostly numerics), COPY will fail.
- 'file' input is parsed and outputted as temporary file 'file.tmp'. If  
  something goes wrong and read_table cannot complete this file is not deleted.
- ...Surely some more.

EXAMPLES:

-- Print out the documentation:
select read_table('');

-- Say this the data file tab-separated:
xv1  xv2  xv3  xvz
1.1  2.1  3.1  z.1
1.2  2.2  3.2  z.2
1.3  2.3  3.3  z.3
1.4  2.4  3.4  z.4
1.5  2.5  3.5  z.5
1.6  2.6  3.6  z.6

--------------[ Simpleset import ]-----------------

SELECT read_table($$ file:'D:/Tritume/mydata.txt', table:'mytable' $$);

select * from mytable; -- (col names and types automatically assigned.)

  v1  |  v2  |  v3  | v4
------+------+------+-----
 xv1  | xv2  | xv3  | xvz
 1.1  | 2.1  | 3.1  | z.1
 1.2  | 2.2  | 3.2  | z.2
 1.3  | 2.3  | 3.3  | z.3
 1.4  | 2.4  | 3.4  | z.4
 1.5  | 2.5  | 3.5  | z.5
 1.6  | 2.6  | 3.6  | z.6
(7 rows)

--------------[ Import selected columns]----------

We want the first, the last, and the column named 'xv2'. Limit import to two rows:

SELECT read_table($$ select: [0, -1, 'xv2'], header: True, limit: 2, overwrite:True, file:'D:/Tritume/mydata.txt', table:'mytable' $$);

Note: To select all the columns between position i and j it is allowed to use "select:[range(i, j), ...]"

select * from mytable;

 xv1 | xvz | xv2
-----+-----+-----
 1.1 | z.1 | 2.1
 1.2 | z.2 | 2.2
(2 rows)


---------------[ Header and data types ]----------

Import file and assign the data type to 2 columns:

SELECT read_table($$ header: True, data_type:{'xv1':'numeric', 'xv2':'numeric UNIQUE NOT NULL'}, overwrite:True, file:'D:/Tritume/mydata.txt', table:'mytable' $$);

Note: 'text' in the 3rd and 4th column has been assigned by default.

SELECT column_name, is_nullable, data_type FROM information_schema.columns where table_name = 'mytable';

 column_name | is_nullable | data_type
-------------+-------------+-----------
 xv1         | YES         | numeric
 xv2         | NO          | numeric
 xv3         | YES         | text
 xvz         | YES         | text
(4 rows)
    

Assign column names and data types, skip the first line in mydata.txt:

SELECT read_table($$ header: ['a', 'b', 'c', 'd'], data_type:[['varchar NOT NULL']*2, 'numeric'], skip: 1, overwrite:True, file:'D:/Tritume/mydata.txt', table:'mytable' $$);

SELECT column_name, is_nullable, data_type FROM information_schema.columns where table_name = 'mytable';

 column_name | is_nullable |     data_type
-------------+-------------+-------------------
 a           | NO          | character varying
 b           | NO          | character varying
 c           | YES         | numeric
 d           | YES         | text
(4 rows)


------------[ Applying a custom function ]--------------

Assuming in D:/Tritume/myfun.py you have the following python functions:

def zreplace(line):
    " Replace '.z' with '.a' in column 4 "
    line= line.split('\t')
    line[3]= line[3].replace('z.', 'a.')
    line= '\t'.join(line)
    return(line)

def filter_out(line):
    " Filter out lines where column 2 is '2.3' "
    line= line.split('\t')
    if line[1] == '2.3':
        return('')
    else:
        line= '\t'.join(line)
        return(line)

nline= 0
def line_increment(line):
    " Add an incremental number to each row "
    global nline
    if nline == 0:
        line= 'line_increment\t' + line
        nline += 1
    else:
        line= str(nline) + '\t' + line
        nline += 1
    return(line)

1) Replace .z with .a in the fourth column:

SELECT read_table($$ apply: ['D:/Tritume/myfun.py', 'zreplace'], header: True, overwrite:True, file:'D:/Tritume/mydata.txt', table:'mytable' $$);
select * from mytable;

 xv1 | xv2 | xv3 | xvz
-----+-----+-----+-----
 1.1 | 2.1 | 3.1 | a.1
 1.2 | 2.2 | 3.2 | a.2
 1.3 | 2.3 | 3.3 | a.3
 1.4 | 2.4 | 3.4 | a.4
 1.5 | 2.5 | 3.5 | a.5
 1.6 | 2.6 | 3.6 | a.6
(6 rows)

2) Skip lines where the value in the second column is '2.3':

SELECT read_table($$ apply: ['D:/Tritume/myfun.py', 'filter_out'], header: True, overwrite:True, file:'D:/Tritume/mydata.txt', table:'mytable' $$);

select * from mytable;

 xv1 | xv2 | xv3 | xvz
-----+-----+-----+-----
 1.1 | 2.1 | 3.1 | z.1
 1.2 | 2.2 | 3.2 | z.2
 1.4 | 2.4 | 3.4 | z.4
 1.5 | 2.5 | 3.5 | z.5
 1.6 | 2.6 | 3.6 | z.6
(5 rows)

3) Add an incremental number to each row as first column

SELECT read_table($$ apply: ['D:/Tritume/myfun.py', 'line_increment'], header: True, overwrite:True, file:'D:/Tritume/mydata.txt', table:'mytable' $$);

select * from mytable;
 line_increment | xv1 | xv2 | xv3 | xvz
----------------+-----+-----+-----+-----
              1 | 1.1 | 2.1 | 3.1 | z.1
              2 | 1.2 | 2.2 | 3.2 | z.2
              3 | 1.3 | 2.3 | 3.3 | z.3
              4 | 1.4 | 2.4 | 3.4 | z.4
              5 | 1.5 | 2.5 | 3.5 | z.5
              6 | 1.6 | 2.6 | 3.6 | z.6
(6 rows)

------------[ Reading a rugged file ]------------

For example data file is:

xv1
1.1	
1.2	2.2
1.3	2.3	3.3
1.4	2.4	3.4
1.5	2.5	3.5	z.5
1.6	2.6	3.6	z.6


SELECT read_table($$ allow_rugged:True, header: True, overwrite:True, file:'D:/Tritume/mydata.txt', table:'mytable' $$);

select * from mytable; -- Incomplete rows have been filled-in with ''.

 xv1 | v1  | v2  | v3
-----+-----+-----+-----
 1.1 |     |     |
 1.2 | 2.2 |     |
 1.3 | 2.3 | 3.3 |
 1.4 | 2.4 | 3.4 |
 1.5 | 2.5 | 3.5 | z.5
 1.6 | 2.6 | 3.6 | z.6
(6 rows)

THINGS TO DO WHEN THIS FUNCTION IS MODIFIED:
- Update the version variable above
- Update documentation
- If new arguments are added, edit the sections headed by the following headers:
  ## List of pseudo-arguments
  ## Arg-parser
  ## Parsed-args
""" %version

" '-----------------------[ Function starts here ]------------------------------ "
argstr= arg_string.strip()
if argstr == 'man' or argstr == 'help' or argstr == 'h' or argstr == '':
    return(docstring)

import os
import gzip
import bz2
import time
import datetime
import csv
import tempfile
import sys
import shutil
from imp import reload     ## This is py3 specific. Necessary for imp.reload (py2 was just reload() )

t0= time.time()

n_lines_datatype= 100000 ## Number of lines to sample to determine datatypes

try:
    " Enusure each new run of read_table uses the newest pgrt_apply module "
    del(sys.modules['pgrt_apply'])
except:
    pass

" ---------------------[ Define functions ]----------------- "

def make_tablename(file):
    """ If the name of the destrination table is not given, 
    make up a default one using the file name stripped of
    the path and extension. Table will go to public schema 
    unless it has to be temporary """
    pathname= os.path.splitext(file)[0]
    tablename= '"' + os.path.basename(pathname) + '"'
    if temp is not 'TEMP':
        tablename= 'public.' + tablename
    return(tablename)

def get_wdir(wdir):
    """ Set the working dir for read_table """
    if os.path.isdir(os.path.join(wdir, 'read_table')):
        wdir_readtable= os.path.join(wdir, 'read_table')
    else:
        try:
            wdir_readtable= os.path.join(wdir, 'read_table')
            os.mkdir(wdir_readtable)
        except:
            sys.exit("get_wdir: I cannot set or make dir '%s'" %wdir_readtable)
    try:
        os.chmod(wdir_readtable, int('777', 8))
    except:
        sys.exit("get_wdir: I cannot set permission on my working dir %s'" %wdir_readtable)
    wdir_readtable= wdir_readtable.replace('\\', '/') ## This is ugly but necessary because COPY won't like backslashes
    return(wdir_readtable)

def f_copy_table():
    " Determine how COPY should be executed "
    if tmpfile_is_parsed is True:
        " This block uses COPY without header, this is always the case with parsed file "
        if CSV is True:
            copy_table= "COPY %s FROM E'%s' WITH DELIMITER E'%s' NULL E'%s' CSV QUOTE $quote$%s$quote$;" %(qualified_tablename, parsed_file, sep, na_string, quote)
            return(copy_table)
        else:
            copy_table= "COPY %s FROM E'%s' WITH DELIMITER E'%s' NULL E'%s';" %(qualified_tablename, parsed_file, sep, na_string)
            return(copy_table)
    elif tmpfile_is_parsed is False:
        """ This block deals with unparsed file which can be 
        1) CSV with header 
        2) CSV without header
        3) Plain without header
        Plain with header is not accepted by COPY """
        if CSV is True and header is True:
            copy_table= "COPY %s FROM E'%s' WITH DELIMITER E'%s' NULL E'%s' CSV HEADER QUOTE $quote$%s$quote$;" %(qualified_tablename, parsed_file, sep, na_string, quote)
            return(copy_table)
        elif CSV is True and (header is False or type(header) == list):
            copy_table= "COPY %s FROM E'%s' WITH DELIMITER E'%s' NULL E'%s' CSV QUOTE $quote$%s$quote$;" %(qualified_tablename, parsed_file, sep, na_string, quote)
            return(copy_table)
        elif CSV is False and (header is False or type(header) == list):
            copy_table= "COPY %s FROM E'%s' WITH DELIMITER E'%s' NULL E'%s';" %(qualified_tablename, parsed_file, sep, na_string)
            return(copy_table)
        else:
            sys.exit('f_copy_table: Combination of CSV and header options not compatible.')

def opener(file):
    """ read file using standard open() or gzip.open() or bz2.BZ2File() for compressed stuff """
    global file_gz;  file_gz= False   ## These are to tell later what decompression to use
    global file_bz2; file_bz2= False
    try:
        """ Try to unpack with gzip  """
        open_con= gzip.open(file)
        open_con.readline()  ## Open file, read one line, then close to check if it is readable by gzip
        open_con.close()     ##        
        file_gz= True
        return(gzip.open(file))
    except:
        try:
            """ Try bzip2 """ 
            open_con= bz2.BZ2File(file)
            open_con.readline()  ## Open file, read one line, then close to check if it is readable by bz2
            open_con.close()     ##        
            file_bz2= True
            return(bz2.BZ2File(file))
        except:
            return(open(file))

def flatten(lst):
    """ Returns a flat list from a list containing nested lists 
    Example: 
    xv= [1, 2, [3,4, ('x', 'v')], ('a', 'b')]
    list(flatten(xv))
    [1, 2, 3, 4, 'x', 'v', 'a', 'b']
    Used to unnest lists passed to 'select'
    """
    for elem in lst:
        if type(elem) in (tuple, list):
            for i in flatten(elem):
                yield(i)
        else:
            yield(elem)

def data_typer_none(colnames, data_sample, na_string):
    """ Determine the datatype of the columns of a table (list of lists). 
    Input is a list of lists and a list of column names.
    Output is a list of data types (chosen from double precision, int, or text)
    Example:
    data_sample= [[1, 1.0, 'a', ''],
                  [2, 2.1, 'b', '']
                 ]
    colnames= ['v1', 'v2', 'v3', 'v4']

    returns: column_types= ['int', 'double precision', 'text', 'text']
    """

    column_types= []
    for i in range(0, len(colnames)):
        " Test data type of each column "
        col_i= [x[i] for x in data_sample if x[i] != na_string] ## Fetch one column and remove NAs from it. NAs are always allowed so don't consider them to determine datatypes
        if set(col_i) == set([]):
            " If a column is all NULLs set it to type text "
            column_types.append('text')
            continue
        try:
            """ Try to convert each element to float. If this is possible,  
            see if the module of %1 is always zero. """
            test_float= set([float(x)%1 for x in col_i])
            if test_float == set([0.0]) and all(['.' not in str(x) for x in col_i ]):
                " If the module %1 is 0 and there are no decimals ('e.g. 1.0') set type to int "
                col_i_type= 'int' 
            else:
                col_i_type= 'double precision' 
        except:
            " If can't convert to float set type to text "
            col_i_type= 'text'
        column_types.append(col_i_type)
    return(column_types)

def data_typer_list(colnames, data_type):
    """ Assign data types provided as list to column names.
    If not enough types are supplied, assign text to the remaining ones.
    Input:
    colnames= list
    data_type= lists of data types
    
    Example:
    colnames= ['v1', 'v2', 'v3', 'v4']
    data_type= ['int', 'text']
    returns: column_types= ['int', 'text', 'text', 'text']
    """
    column_types= list(flatten(data_type))
    miss_cols= len(colnames) - len(column_types)
    column_types= column_types + (['text'] * miss_cols)
    return(column_types)

    
def data_typer_dict(colnames, data_type):
    """ Assigns data types to a list of column names given
    a dictionary which links column names to type or column 
    position to type. If not enough data types are supplied, assign 'text'
    to the renmaining ones.
    Example:
    colnames=  ['v1', 'v2', 'v3', 'v4']
    data_type= {'v1': 'int', 1: 'double precision', 2: 'numeric'}
    returns: column_types= ['int', 'double precision', 'numeric', 'text']
    """
    column_types= ['text'] * len(colnames)
    for k in data_type:
        if type(k) == int:
            column_types[k]= data_type[k]
        else:
            try:
                kn= colnames.index(k)
            except:
                sys.exit('Column name ' + k + ' not found in list of column names:\n' + str(colnames))
            column_types[kn]= data_type[k]
    return(column_types)
           
def right_now():
    """ Return current time as a string like this
    [2010-12-04 15:56:02.880000] 
    """
    t= '[' + datetime.datetime.now().strftime('%c') + ']'
    return(t)

def line_reader(line_string):
    """ Parse a line (str) read from a file using line.split() if CSV:False,
    or csv.reader() if CSV:True (CSV mode).
    Note that line.split() is approx. x2 faster than csv.reader()
    Input is string and output is a list with an item per column """
    line= line_string.rstrip('\r\n')
    if CSV is True:
        r= csv.reader([line], delimiter= sep, quotechar= quote)
        return([x for x in r][0])
    else:
        return(line.split(sep))
        
def line_writer(line_list, tmpfile):
    """ Writes a list to an open connection as a line.
    If CSV:True use the connection prepared by csv.writer() and write
    using .writerow(line) method.
    If CSV:False write out using .write(sep.join(line)). """
    if CSV is True:
        tmpfile.writerow(line_list)
    else:
        tmpfile.write(sep.join(line_list) + '\n')

def header_getter():
    """ Prepares the header according to requirements.
    Input line should be after lines have been skipped according to skip, 
    and according to comment_char, blank_line_skip, apply. Input line is a list returned by line_reader.
    Output is a list of column names. This list might be parsed by select.
    The number of columns has been already computed and it is in var maxcols.
     """
    log_file= open(log_file_name, 'a')
    if header is False: ## and append is False:
        """Case 1: File has no header, no header is supplied as list. 
        Use dummy names v1, v2 ... vN """
        colnames= ['v' + str(x) for x in range(1, maxcols + 1)]
    elif header is True:
        """ Case 2: The first read-in line is the header. 
                    Use this line for names even if append is True. """
        colnames= line
    elif type(header)== list:
        """ Case 3: Column names are supplied by the user as a list """
        colnames= [str(x) for x in header]
        if len(colnames) > maxcols:
            log_file.write('header_getter: Warning: %d column names found but %d were counted. List of names will be trimmed.\n' %(len(colnames), maxcols))
            colnames= colnames[0:maxcols]
        if len(colnames) < maxcols:
            log_file.write('header_getter: Warning: %d column names found but %d were counted. List of names will be extended.\n' %(len(colnames), maxcols))
            colnames= colnames + ['']*(maxcols - len(colnames)) ## The QC below will replace '' with v1, v2 etc.
    """ Quality control of column names  """
    col_number= 1
    for i in range(0, len(colnames)):
        " Strip double quotes from names and convert to string "
        colnames[i]= str(colnames[i].strip('"'))
        " If there are nulls replace them with dummy v1, v2, vN"
        if colnames[i] == '':
            colnames[i]= 'v' + str(col_number)
            log_file.write('header_getter: Warning: Column name at position %d is blank. Replacing it with v%d\n' %( (i+1), col_number ))
            col_number += 1
        if len(colnames[i]) > 63:
            log_file.write('header_getter: Warning: Column name %s is more than 63 char long. Postgres will truncate it.\n' %colnames[i])
    " Edit duplicate names to be unique "
    """ colnames_unique: names to be changed one by one until they are unique.
    In reverse order so that the leftmost is least changed """
    colnames_unique= [x for x in colnames][::-1]
    for i in range(0, len(colnames))[::-1]:
        name= colnames_unique[i]
        " Make blank the name being tested in the original list "
        colnames_blank= [x for x in colnames_unique]
        colnames_blank[i]= None
        try:
            """ See if there is a name duplicate of the one currently being tested.
            The name being edited is the first one found duplicate, not the one being tested. """
            duplicate_name_index= colnames_blank.index(name)
        except:
            " If the name being tested has no duplicates: "
            colnames_unique[i]= name
            continue
        log_file.write('header_getter: Warning: Duplicate column name found for %s\n' %name)
        col_index= 1
        name_to_uniquify= colnames_blank[duplicate_name_index]
        while True:
            """ Add an incremental number as suffix until the new name is unique """
            suffix= '_' + str(col_index)
            name_to_uniquify= name_to_uniquify + suffix
            if name_to_uniquify in colnames_blank:
                " Remove the previous suffix: "
                name_to_uniquify= name_to_uniquify[:-len(suffix)]
                col_index += 1
            else:
                colnames_unique[duplicate_name_index]= name_to_uniquify
                break
    " Final check just in case... "
    log_file.close()
    if len(set(colnames_unique)) != len(colnames):
        sys.exit('duplicate column names found.')
    return(colnames_unique[::-1]) ## Back to original order

def select_parser(line_to_parse, select, colnames):
    """ Returns columns according to ordinal positions or column names found in
    the arg select. line_to_parse is a list. Return a list. """
    parsed_line= []
    for x in select:
        if type(x) == int:
            parsed_line.append(line_to_parse[x])
        else:
            x= colnames.index(x)
            parsed_line.append(line_to_parse[x])
    return(parsed_line)

def get_excel_outfile(file_name, wdir, sheet):
    """
    Helper function fo read_excel*: Get a suitable output file name
    from the input name working dir, and sheet
    """
    outfile= os.path.basename(file_name) + '.' + str(sheet) + '.txt'
    outfile= os.path.join(wdir, outfile)
    try:
        os.remove(outfile)
    except:
        pass
    return(outfile)


def read_excel_2003(file_name, wdir, sheet):
    """ 
    NOTE: This function uses xlrd module but it doesn't support Excel 2007.
    Read an excel file and write the selected sheet to 
    a temp text file. This file will be used as argument 'file'
     
    xls_file   Input Excel file
    wdir       Where temp file will be, with name <xls_file>.txt
    sheet      Sheet to import, default to first found

    Returns the name of the text file produced, including path.
    
    """
    outfile= get_excel_outfile(file_name, wdir, sheet)
    outf= open(outfile, 'w')
    
    wb = xlrd.open_workbook(file_name)
    "Get the appropriate Sheet "
    if type(sheet) == int:
        sh = wb.sheet_by_index(sheet)
    else:
        sh = wb.sheet_by_name('%s' %(sheet))
    for rownum in range(sh.nrows):
        line= []
        for cell in sh.row_values(rownum):
            if cell is 'None':
                cell= ''
            line.append(str(cell))
        line= '\t'.join(line)
        outf.write(line + '\n')
    outf.close()
    return(outfile)

def read_excel_2007(file_name, wdir, sheet):
    """ Similar to read_excel() above but suited to excel 2007 """    
    outfile= get_excel_outfile(file_name, wdir, sheet)
    outf= open(outfile, 'w')
    
    wb = load_workbook(filename = file_name)
    if type(sheet) == int:
        ws= wb.worksheets[sheet]        
    else:
        ws = wb.get_sheet_by_name(name = sheet)
    for row in ws.rows:
        line=[]
        for cell in row:
            x= cell.value
            if x is None:
                x= ''
            line.append(str(x))
        line= '\t'.join(line)
        outf.write(line + '\n')
    outf.close()
    return(outfile)

def read_excel_win32(file_name, wdir, sheet):
    """
    Convert file_name from Excel (2003 or 2007) to plain text using win32com:
    Advantages over read_table_2003/7
    - Faster
    - Output cell values the same as doing Save As *.txt.
    Disadvantages:
    - Works on windows (32bit?) only
    - Possible clashes with excel open in the background 
    """
    import win32com.client
    outfile= os.path.basename(file_name)
    outfile= os.path.join(wdir, outfile) + '.txt'
    outfile= outfile.replace('/', '\\')
    
    win32com.client.gencache.EnsureDispatch('Excel.Application')
    excel = win32com.client.Dispatch("Excel.Application")
    workbook= excel.Workbooks.Open(file_name, UpdateLinks= False, ReadOnly= True)
    if sheet == 0:
        worksheet= workbook.ActiveSheet
    else:
        worksheet=workbook.Worksheets(sheet)
    try:
        os.remove(outfile)
    except:
        pass
    worksheet.SaveAs(Filename=outfile, FileFormat=win32com.client.constants.xlTextMSDOS)
    workbook.Close(False)
    excel.Quit()
    del excel
    return(outfile)
    
def exit_action():
    " At the end of the execution, after having imported eveything, do these things "
    if remove_tmpfile is True:
        " Remove the parsed input file if required "
        os.remove(parsed_file)
        if xls_file_exists is True:
            " If input file was from Excel saved as text, remove it"
            os.remove(file)
    ex_time= time.time() -t0
    log_file.write('\n\n--------------------------' + right_now() + '-------------------------\n')
    log_nlines= "%s lines imported in %.2f s to table '%s'.\nSee '%s' for more details." %(lines_to_tmpfile, ex_time, table, log_file_name)
    log_file.write('\n' + log_nlines + '\n')
    if tmpfile_is_parsed is True:
        log_file.write('\nLines imported:             ' + str(lines_to_tmpfile))
        log_file.write('\nLines skipped:              ' + str(nskipped_lines))
        log_file.write('\nLines commented:            ' + str(ncommented_lines))
        log_file.write("\nLines filled-in ('rugged'): " + str(nrugged_lines))
        log_file.write('\nBlank lines skipped:        ' + str(nblank_lines))
        log_file.close()
    return(log_nlines)

" ---------------------[ Parse arguments ]----------------------------------- "

## List of pseudo-arguments
file= 'file'
table= 'table'
wdir= 'wdir'
header= 'header'
sep= 'sep'
skip= 'skip'
na_string= 'na_string'
apply= 'apply'
limit= 'limit'
blank_lines_skip= 'blank_lines_skip'
data_type= 'data_type'
overwrite= 'overwrite'
append= 'append'
quote= 'quote'
comment_char= 'comment_char'
allow_rugged= 'allow_rugged'
CSV= 'CSV'
temp= 'temp'
select= 'select'
excel= 'excel'
sheet= 'sheet'
remove_tmpfile= 'remove_tmpfile'

## Convert the argument string to a dictionary
try:
    arg_dict= eval('{' + arg_string + '}')
except:
    sys.exit("Error parsing the argument string:\n" + arg_string + 
           "\n- Does it contain '=' instead of ':' assignment sign?\n- Are the argument names correct?")

## Arg-parser
## Retrieve user's parameters (try:...) or assign defaults (except:...)
try:
    file= arg_dict[file]
except:
    sys.exit('Error in read_table(): argument file is empty')
try:
    table= arg_dict[table]
except:
    table= None
try:
    header= arg_dict[header]
except:
    header= False
try:
    sep= arg_dict[sep]
except:
    sep= '\t'
try:
    skip= arg_dict[skip]
    if type(skip) != int or skip<0:
        skip= 0
except:
    skip= 0
try:
    na_string= arg_dict[na_string]
except:
    na_string= ''
try:
    apply= arg_dict[apply]
except:
    apply= None
try:
    blank_lines_skip= arg_dict[blank_lines_skip]
except:
    blank_lines_skip= 'NA'
try:
    data_type= arg_dict[data_type]
except:
    data_type= None
try:
    overwrite= arg_dict[overwrite]
    if type(overwrite) != bool:
        sys.exit('Error. Argument overwrite is not of type boolean (True/False)')
except:
    overwrite= False
try:
    append= arg_dict[append]
    if type(append) != bool:
        sys.exit('Error. Argument append is not of type boolean (True/False)')
except:
    append= False
try:
    quote= arg_dict[quote]
except:
    quote= '"'
try:
    comment_char= arg_dict[comment_char]
except:
    comment_char= ''
try:
    limit= arg_dict[limit]
    if limit <= 0 or type(limit)!= type(1):
        limit= None ## Set nrow -1 or string char to infinity
except:
    limit= None
try:
    allow_rugged= arg_dict[allow_rugged]
    if type(allow_rugged) != bool:
        sys.exit('Error. Argument allow_rugged is not of type boolean (True/False)')
except:
    allow_rugged= False

try:
    CSV= arg_dict[CSV]
    if type(CSV) != bool:
        sys.exit('Error. Argument CSV is not of type boolean (True/False)')
except:
    CSV= True

try:
    temp= arg_dict[temp]
except:
    temp= False
if type(temp) != bool:
    sys.exit('Error. Argument temp is not of type boolean (True/False)')
if temp is True:
    temp= 'TEMP'
else:
    temp= ''

try:
    wdir= arg_dict[wdir]
    if wdir is None:
        wdir= tempfile.gettempdir()
except:
    wdir= tempfile.gettempdir()

try:
    remove_tmpfile= arg_dict[remove_tmpfile]
    if type(remove_tmpfile) != bool:
        sys.exit('Error: remove_tmpfile is not of type boolean (True/False)')
except:
    remove_tmpfile= True

try:
    excel= arg_dict[excel]
except:
    excel= True

try:
    sheet= arg_dict[sheet]
except:
    sheet= 0
    
try:
    select= arg_dict[select]
except:
    select= None


""" Parse select argument """    
if select is not None and allow_rugged is True:
    sys.exit('Execution stopped: "select not None" is not compatible with allow_rugged:True')
if select is not None:
    select= list(flatten(select))

" ---------------------[ Some checks on the arguments ]---------------------- "

" Make a tablename if none given. "
if table is None:
    table= make_tablename(file)

if append is True and overwrite is True:
    sys.exit('I cannot procede with append:True and overwrite:True\nSet one of the two to False.')
if header is not True and select is not None and (str in [type(x) for x in select]):
    sys.exit('String element found in arg select and header is not True.\n(Column names in select are meaningful only if the datafile has header.)')
if blank_lines_skip not in [True, False, 'NA']:
    sys.exit("blank_lines_skip: '" + blank_lines_skip + "' is not a valid option (allowed are True/False/'NA')")

""" See if there are the conditions to procede to straight data import: """
if skip == 0 and (limit == apply == select == None) and data_type is not None and allow_rugged is False and blank_lines_skip == 'NA' and (CSV is True or header is False):
    file_needs_parsing= False
elif blank_lines_skip == 'NA':
    file_needs_parsing= True
    blank_lines_skip = True
else:
    file_needs_parsing= True

" --------------------------------[ Working settings ]----------------------- "

""" Parse table and get the current working schema & database and the user's schema 
REMINDER of varables:
table= Argument passed to read_table as is. E.g. 'Myschema.mytable'
table_name= Target table name only (no schema qualified) and not quoted. E.g. 'mytable'
user_schema, user_database= Names of the schema and db as extracted from table, not quoted. E.g. 'Myschema' or None if unqualified
qualified_tablename= Target table quoted and qualified with the info extracted from table string. E.g. '"Myschema"."mytable"'
current_schema, current_database= As the name says, but not necessarily where the target table is/will be.

This will parse the table string from string to list like this 
'Database.schema.table' -> ['Database', 'schema', 'table'] """
csvname= csv.reader([table], quotechar= '"', delimiter= '.')
names= [x for x in csvname][0]
if len(names) == 1:
    " table is not database and schema qualified, set user's schema and db to None (unqualified)"
    table_name= names[0]
    user_schema= None
    user_database= None
elif len(names) == 2:
    " table is schema qualified, set db to None (unqualified)"
    table_name= names[1]
    user_schema= names[0]
    user_database= None
elif len(names) == 3:
    " table is fully qualified "
    table_name= names[2]
    user_schema= names[1]
    user_database= names[0]

" Current database working settings "
current_schema= plpy.execute("SELECT COALESCE(current_schema(), 'N/A') AS current_schema;")
current_schema= current_schema[0]['current_schema']
current_database= plpy.execute('SELECT current_database();')
current_database= current_database[0]['current_database']

""" Rejoin table name: from ['mydb', 'myschema', 'mytable'] to "mydb"."myschema"."mytable" """
qualified_tablename= ''
for name in [user_database, user_schema, table_name]:
    if name is None:
        pass
    else:
        qualified_tablename= '%s"%s".' %(qualified_tablename, name)
" Use qualified_tablename in COPY and CREATE statements"
qualified_tablename= qualified_tablename.rstrip('.')

" read_table wdir: Where parsed file, log file, pgrt_apply.py will go "
wdir_rt= get_wdir(wdir) ## previous variable name was tmp_dir

" Postgres data directory "
pg_data_dir= 'show data_directory;'
pg_data_dir= plpy.execute(pg_data_dir)
pg_data_dir= pg_data_dir[0]['data_directory']


#" Add the working dir to pythopath (for apply script)"
#sys.path.append(wdir_rt)

" ----------------------------[ Open log file ]-------------------------------- "

## Parsed-args
if apply is not None:
    apply_sub= 'See below'
else:
    apply_sub= None
parsed_args= ['  file:             ', file, '\n',
              '  table:            ', table, '\n',
              '  wdir              ', wdir, '\n',
              '  excel             ', excel, '\n',
              '  sheet             ', sheet, '\n',
              '  remove_tmpfile:   ', remove_tmpfile, '\n',              
              '  header:           ', header, '\n',
              "  sep:              '", sep, "'\n",
              "  quote:            '", quote, "'\n",
              "  na_string:        '", na_string, "'\n",
              '  CSV:              ', CSV, '\n',
              '  skip:             ', skip, '\n',
              '  limit:            ', limit, '\n',
              '  blank_lines_skip: ', blank_lines_skip, '\n',
              "  comment_char:     '", comment_char, "'\n",
              '  apply:            ', apply_sub, '\n',
              '  select:           ', select, '\n',
              '  allow_rugged:     ', allow_rugged, '\n',
              '  overwrite:        ', overwrite, '\n',
              '  append:           ', append, '\n',
              '  temp:             ', temp, '\n',
              '  data_type:        ', data_type]
parsed_args= ''.join([str(x) for x in parsed_args])

log_file_name= wdir_rt + '/' + os.path.basename(file) + '.log'
log_file= open(log_file_name, 'w')
os.chmod(log_file_name, int('744', 8))

plpy.info('Logging to file: %s' %log_file_name)

try:
    log_file.write('-------------------------------------------------------------------------------\n')
    log_file.write('\nLog file produced by PostgreSQL function read_table() ' + 'version ' + version + '\n\n')
    log_file.write('-------------------------------------------------------------------------------\n')
    log_file.write('\n' + right_now() + '\n')
    log_file.write('These parameters have been used:\n\n')
    log_file.write(parsed_args + '\n')
except:
    pass
log_file.write('\nPostgreSQL version:      ' + plpy.execute('SELECT version();')[0]['version'])
log_file.write('\nPython version:          ' + sys.version.split(' ')[0] + ' on ' + sys.platform)
log_file.write('\nCurrent database:        ' + current_database)
log_file.write('\nCurrent schema:          ' + current_schema)
log_file.write('\nTarget table:            ' + table_name)
log_file.write('\nread_table working dir.: ' + wdir_rt)
log_file.write('\nPostgres data dir. :     ' + pg_data_dir)
# log_file.write('\nParsed input file:       ' + parsed_file)
log_file.write('\nLogging to file:         ' + log_file_name + '\n\n')


" --------------------[ Compile apply function/script ]---------------------- "

if apply is not None:
    if type(apply) is str:
        """ If the apply function is passed as string with the definition, write it
        to the file pgrt_apply.py in the wdir_rt an import it as a python module.
        The apply function is imported as apply_fun.
        """
        applyf= open(os.path.join(wdir_rt, 'pgrt_apply.py'), 'w')
        applyf.write('## %s script created by postgresql read_table()\n' %right_now())
        applyf.write(apply)
        applyf.close()
    if type(apply) is list:
        """ If apply is passed as dict with script name and function name to apply,
        copy that script as pgrt_apply.py in current dir and load it as module.
        The function to apply given is imported as apply_fun """
        try:
            module= apply[0]
            function= apply[1]
        except:
            sys.exit("apply: %s is not correct.\nMake sure it is in the format {'import':'mymodule', 'function':'myfun'}" %apply)
        shutil.copyfile(module, os.path.join(wdir_rt, 'pgrt_apply.py'))
    os.chmod(os.path.join(wdir_rt, 'pgrt_apply.py'), int('744', 8))
    try:
        " Add and remove the working dir to pythopath (for apply script)"
        sys.path.append(wdir_rt); import pgrt_apply; del(sys.path[sys.path.index(wdir_rt)])
    except:
        del(sys.path[sys.path.index(wdir_rt)])
        sys.exit('apply: I cannot import module pgrt_apply. Check for errors in %s' %(wdir_rt + '/pgrt_apply.py'))
    sys.path.append(wdir_rt); reload(pgrt_apply); del(sys.path[sys.path.index(wdir_rt)])
    if type(apply) is str:
        sys.path.append(wdir_rt)
        from pgrt_apply import apply as apply_fun
        del(sys.path[sys.path.index(wdir_rt)])
        " Log what has been done "
        log_file.write("Requested to apply to each line the apply function:\n")
        log_file.write(apply)
        log_file.write("\nPassed as string. Written, compiled and imported from pgrt_apply module in %s/pgrt_apply.py\n\n" %wdir_rt)
    if type(apply) is list:
        apply_fun= eval('pgrt_apply.' + apply[1])
        log_file.write("Requested to apply to each line function %s in module %s\n\n" %(apply[1], apply[0]))

""" -----------------------[ Check if table exists ]---------------------------------  """

" query pg_tables "
if user_schema is not None:
    qry_if_table_exists= "SELECT tablename FROM pg_tables WHERE schemaname = '%s' AND tablename = '%s';" %(user_schema, table_name)
else:
    qry_if_table_exists= "SELECT tablename FROM pg_tables WHERE" + " tablename = '%s';" %table_name
log_file.write("%s Querying: %s"  %(right_now(), qry_if_table_exists) )
pg_tables= plpy.execute(qry_if_table_exists)
log_file.write(' -- Done\n')

""" If zero rows are returned, then table does not exists. """
table_exists= len(pg_tables)
if table_exists == 0 and append is True:
    sys.exit('I cannot find table ' + table_name + '\nSet append:False to create it new.')

if table_exists > 0 and append is True:
    " Set data_type to not None (for later switches) "
    data_type= 'Data types found in table'

"""
TODO here: If file does not need any parsing (skip= 0, comment_char= disabled, select= None, 
apply= None, data_type is known and/or table is to be appended and is not 
gzipped), then just issue the CREATE and COPY statements.
"""

" ------------[ Collect details of about the data to import ]---------------- "

""" This section scans the input file to compute the numebr of columns (always)
and the number of rows.
"""

xls_file_exists= False ## Variable to see whether a plain text file produced by read_excel() exists.

if excel is True and (file.endswith('.xls') or file.endswith('.xlsx')):
    log_file.write(right_now() + ' Converting %s from Excel to text...\n' %(file))
    log_file.close()
    file= read_excel_win32(file, wdir_rt, sheet)
    xls_file_exists= True
    log_file= open(log_file_name, 'a'); log_file.write(right_now() + ' Converted file to import is "%s"\n' %(file))
    """
    if file.endswith('.xls'):
        log_file.write(right_now() + ' Converting %s from Excel 2003 to text.\n' %(file))
        import xlrd
        file= read_excel_2003(file, wdir_rt, sheet)
        xls_file_exists= True
    elif file.endswith('.xlsx'):
        log_file.write(right_now() + ' Converting %s from Excel 2007 to text.\n' %(file))
        from openpyxl.reader.excel import load_workbook
        file= read_excel_2007(file, wdir_rt, sheet)
        xls_file_exists= True
    log_file.write(right_now() + ' Converted file to import is "%s"\n' %(file))
    """
infile= opener(file)

""" If it is necessary to determine the data-types and/or allow_rugged is True (file is 'rugged'), 
    count the total rows, the rows to sample and number of columns necessary """    
log_file.write(right_now() + ' Scanning the datafile to count the number of rows and columns... ')
log_file.close()
data_sample= []
maxcols= 0 #var for number of columns required
nrows_read= 0
tmp_header= header # A switch to determine what to do with the first non-skipped line
ncols_collected= False # A switch to determine whether the number of columns in the datafile has been established
""" Scan the input file before importing for one or more of these reasons:
1) data type is unknown (and data is not to be appended)
2) File might be rugged and we need to know the maximum number of columns
3) Blank lines are not to be skipped so we need to know how many blank cells to concatenate to make a row.
 """
" Skip rows as necessary "
nskip= skip
while nskip > 0:
    infile.readline()
    nskip -= 1
for line in infile:
    if type(line) == bytes:
        " This is necessary in py3 "
        line= line.decode('utf-8')
    line= line.rstrip('\r\n')
    if apply is not None:
        line= apply_fun(line)
    if blank_lines_skip is True and line == '':
        " Skip blank rows "
        continue
    if comment_char != '' and line.startswith(comment_char):
        " Skip comments "
        continue
    if tmp_header is True:
        """ If the first read-in line is the header, don't count it as data row
        but you can use it for the number of columns """
        maxcols= len(line_reader(line))
        tmp_header = False
        continue
    """ If you pass this point you are reading data lines. """
    if (allow_rugged is False) and (data_type is not None) and (line != ''):
        """ If data type is given at least in part and the file is not rugged,
        it's not necessary to scan it to the end. Just get the number of columns
        from the first non-skipped line. The number of rows is not of interest. 
        because we do not need to sample from the whole file since data type is given """
        maxcols= len(line_reader(line))
        ncols_collected= True
        break
    elif (allow_rugged is False) and (data_type is None) and (line != '') and ncols_collected is False:
        """ This if is similar to the previous one with the difference that 
        data type is not none so you cannot break out the loop, just get 
        the number of columns and keep counting lines. """
        maxcols= len(line_reader(line))
        ncols_collected= True
    elif allow_rugged is True:
        """ If the file is rugged you need to count the number of columns in each row 
        to get the maximum number. """
        ncols= len(line_reader(line))
        if ncols > maxcols:
            maxcols= ncols
    nrows_read += 1
    if limit is not None and nrows_read >= limit:
        break
    n_sample= nrows_read / n_lines_datatype ## n_sample is how often a row should be sampled to determine data_type, if the number of rows of data is less than n_lines_datatype (10000), sample every line by setting n=1
    if n_sample<1: 
        n_sample=1
ncols_collected= True
log_file= open(log_file_name, 'a'); log_file.write(str(maxcols) + ' columns found.\n')
infile.close()
" This reload will erase variables defined during the first scan of the input file "
if apply is not None:
    if type(apply) is str:
        sys.path.append(wdir_rt); reload(pgrt_apply); del(sys.path[sys.path.index(wdir_rt)])
        sys.path.append(wdir_rt)
        from pgrt_apply import apply as apply_fun
        del(sys.path[sys.path.index(wdir_rt)])
    elif type(apply) is list:
        sys.path.append(wdir_rt); reload(pgrt_apply); del(sys.path[sys.path.index(wdir_rt)])
        apply_fun= eval('pgrt_apply.' + apply[1])

""" ----------------------------[ Parse input file ]----------------------  """


""" Temp file where to dump the parsed input. tmpfile should contain the data 
parsed and ready to import, without header. If allow_rugged is True right-filled with None """
file_name= os.path.basename(file) + '.tmp'
parsed_file= wdir_rt + '/' + file_name

log_file.write(right_now() + ' Start parsing input file "%s"...\n\n' %(file))
log_file.close()
infile= opener(file)

" Some useful variables "
header_prepared= False ## This switch will determine wheter the header has been prepared
lines_to_tmpfile= 0 ## Lines written to tmp file
tmpfile_is_parsed= True ## If file does not require parsing switch this to Fales to instruct f_copy_table()
nskipped_lines= 0
ncommented_lines= 0
nrugged_lines= 0
nblank_lines= 0


" Open the connection using the appropriate method depending on whether the input/output is CSV "
if CSV is True:
    tmpfilecsv= open(parsed_file, 'w')
    tmpfile= csv.writer(tmpfilecsv, delimiter= sep, quotechar= quote, lineterminator= '\n') ## Use this lineterm. otherwise postgres won't like the default \r\n 
else:
    tmpfile= open(parsed_file, 'w')
    
" Skip rows as necessary "
nskip= skip
while nskip > 0:
    infile.readline()
    nskipped_lines += 1
    nskip -= 1

for line in infile:
    line= line.rstrip('\r\n')
    if apply is not None:
        line= apply_fun(line)
    if blank_lines_skip is True and line == '':
        " Skip blank rows "
        nblank_lines += 1
        continue
    if comment_char != '' and line.startswith(comment_char):
        ncommented_lines += 1
        " Skip comments "
        continue
    """ For lines not skipped, not commented, not null (as required):
    line string is converted to LIST using either line.split() or csv.reader method. """
    line= line_reader(line)
    if allow_rugged is True:
        " Right-fill eventual incomplete rows "
        c= len(line)
        if c < maxcols:
            line.extend([''] * (maxcols - c))
            nrugged_lines += 1
    if header_prepared is False:
        colnames_before_select= header_getter()
        if select is not None:
            " Determine which column names to import according to select "
            try:
                colnames= select_parser(colnames_before_select, select, colnames_before_select)
            except:
                sys.exit('select_parser: I cannot parse the header line.\nHeader:\n' + str(colnames_before_select) + '\nselect:\n' + str(select))
        else:
            colnames= colnames_before_select
        header_prepared= True ## Header prepared, so do not do this block anymore
        log_file= open(log_file_name, 'a')
        log_file.write('Column names found or assigned to input data:\n' + str(colnames_before_select) + '\n\n')
        log_file.close()
        """ Header has been prepared but we need to check whether the line passed to 
        header_getter() was column names to be now discarded or data to be sent to output. """
        if header is True:
            continue
    if header_prepared is True and file_needs_parsing is False:
        """ If all the above conditions are satisfied it means that the input 
        file is ready to be loaded with COPY without any further processing so exit the loop. 
        (CSV is True or header is False) is necessary because COPY can use the first line as header only in CSV mode """
        log_file= open(log_file_name, 'a')
        log_file.write(right_now() + ' No parsing necessary.\n')
        tmpfile_is_parsed = False
        infile.close()
        if CSV is True:
           tmpfilecsv.close()
        else:
           tmpfile.close()
        if file_gz is True:
            " If the input file is gzipped, unpack it "
            infile = gzip.open(file)
            tmpfile= open(parsed_file, 'w')
            for line in infile:
                line= line.rstrip() ## This strip is necessary to deal with \r which is not stripped by gzip
                tmpfile.write(line + '\n')
            tmpfile.close()
            infile.close()
        elif file_bz2 is True:
            " If the input file is bzipped, unpack it "
            infile = bz2.BZ2File(file)
            tmpfile= open(parsed_file, 'w')
            for line in infile:
                line= line.rstrip() ## This strip is necessary to deal with \r which is not stripped by bz2
                tmpfile.write(line + '\n')
            tmpfile.close()
            infile.close()
        else:
            parsed_file= file
            remove_tmpfile= False ## This is necessary otherwise the original input is going to be deleted
        lines_to_tmpfile= 'N/A'
        break
    if select is not None:
        " Determine which columns to import "
        try:
            line= select_parser(line, select, colnames_before_select)
        except:
            sys.exit('select_parser: I cannot parse line ' + str(lines_to_tmpfile) + '\nCheck indexes and column names in select are correct.')
    line_writer(line, tmpfile)
    lines_to_tmpfile += 1
    if data_type is None and (lines_to_tmpfile % n_sample == 0 or lines_to_tmpfile == 1 or lines_to_tmpfile == nrows_read):
        " Store lines to determine datatypes "
        data_sample.append(line)
    if limit is not None and lines_to_tmpfile >= limit:
        " See if limit is reached "
        break
if CSV is True:
    tmpfilecsv.close()
else:
    tmpfile.close()
infile.close()

log_file= open(log_file_name, 'a')
log_file.write(right_now() + ' Data is ready to load.\n')
" Log a summary of what has been selected for importing: "
colnames_indexes= [str(colnames_before_select.index(x)) for x in colnames]
colnames_report=[]
for i in range(0, len(colnames)):
    rep= colnames[i] + '\t' + colnames_indexes[i]
    colnames_report.append(rep)
colnames_report= '\n'.join(colnames_report)
log_file.write('\nThe follwing columns have been selected for importing:\nName\tIndex (0-based)\n' + '-'*30 +'\n' + colnames_report + '\n' + '-'*30 + '\n\n')


" -----------------------[ CREATE TABLE and import with COPY ]--------------- "

if append is False:
    " This block prepares the data types, so skip it if data is to be appended (append:True)"
    log_file.write(right_now() + ' Determining data types... ')
    if data_type is None:
        """ Determine datatypes using sampled data. data_sample is a list of lists """
        column_types= data_typer_none(colnames, data_sample, na_string)
    elif type(data_type) == list:
        column_types= data_typer_list(colnames, data_type)
    elif type(data_type) == dict:
        column_types= data_typer_dict(colnames, data_type)

    data_definition= list()
    for i in range(len(colnames)):
        data_definition.append('  "%s" %s,\n' %(colnames[i], column_types[i]) )
       
    data_definition[-1]= data_definition[-1].rstrip(',\n')
    data_definition= ''.join(data_definition)
    log_file.write('Done\n')
    " -----------------[ End of data type assignment ]----------------- "
    
    if overwrite is True:
        qry_drop_table= 'DROP TABLE IF EXISTS %s;' %qualified_tablename
        log_file.write('%s Querying: %s' %(right_now(), qry_drop_table))
        plpy.execute(qry_drop_table)
        log_file.write(' -- Done\n')
    " If append is False the table has to be created "
    qry_create_table= 'CREATE %s TABLE %s (\n%s \n  );' %(temp, qualified_tablename, data_definition) 
    log_file.write(right_now() + ' Querying:\n\n' + qry_create_table )
    plpy.execute(qry_create_table);
    log_file.write(' -- Done.\n\n')

qry_copy_table= f_copy_table()
log_file.write(right_now() + ' Importing with: ' + qry_copy_table)
log_file.close()
plpy.execute(qry_copy_table)
log_file= open(log_file_name, 'a')
log_file.write(' -- Done\n')
byebye= exit_action()
return(byebye)

$_$;


ALTER FUNCTION public.read_table(arg_string text) OWNER TO dberaldi;

--
-- TOC entry 689 (class 1255 OID 116694)
-- Dependencies: 5
-- Name: sinh(double precision); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION sinh(double precision) RETURNS double precision
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT (exp($1) - exp(-$1)) / 2; $_$;


ALTER FUNCTION public.sinh(double precision) OWNER TO dberaldi;

--
-- TOC entry 671 (class 1255 OID 30431)
-- Dependencies: 5
-- Name: sort(anyarray); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION sort(anyarray) RETURNS anyarray
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
/*
   Sort array of type varchar (Note that for int arrays there is a sort function already)
   See also http://postgresql.1045698.n5.nabble.com/array-sort-for-varchar-arrays-td1884543.html
   USAGE:
   select sort('{10,3,6}'::int[])    >>> {3,6,10}
   select sort('{10,3,6}'::text[])   >>> {10,3,6}  
*/
    select array(select $1[i] from generate_series(array_lower($1,1),
    array_upper($1,1)) g(i) order by 1)
$_$;


ALTER FUNCTION public.sort(anyarray) OWNER TO dberaldi;

--
-- TOC entry 670 (class 1255 OID 30430)
-- Dependencies: 5
-- Name: sort_distinct(anyarray); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION sort_distinct(anyarray) RETURNS anyarray
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
/*
   Sort array of type varchar and return unique elements
   See also http://postgresql.1045698.n5.nabble.com/array-sort-for-varchar-arrays-td1884543.html
   USAGE:
   select sort_distinct('{10,3,6,10}'::int[])    >>> {3,6,10}
   select sort_distinct('{10,3,6,10}'::text[])   >>> {10,3,6}   
*/
    select array(select distinct $1[i] from generate_series(array_lower($1,1),
    array_upper($1,1)) g(i) order by 1)
$_$;


ALTER FUNCTION public.sort_distinct(anyarray) OWNER TO dberaldi;

--
-- TOC entry 691 (class 1255 OID 116696)
-- Dependencies: 5
-- Name: tanh(double precision); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION tanh(double precision) RETURNS double precision
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT sinh($1) / cosh($1); $_$;


ALTER FUNCTION public.tanh(double precision) OWNER TO dberaldi;

--
-- TOC entry 687 (class 1255 OID 116692)
-- Dependencies: 5
-- Name: to_multi_byte(text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION to_multi_byte(str text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/orafunc', 'orafce_to_multi_byte';


ALTER FUNCTION public.to_multi_byte(str text) OWNER TO dberaldi;

--
-- TOC entry 3708 (class 0 OID 0)
-- Dependencies: 687
-- Name: FUNCTION to_multi_byte(str text); Type: COMMENT; Schema: public; Owner: dberaldi
--

COMMENT ON FUNCTION to_multi_byte(str text) IS 'Convert all single-byte characters to their corresponding multibyte characters';


--
-- TOC entry 685 (class 1255 OID 29945)
-- Dependencies: 1590 5
-- Name: update_filing_order(); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION update_filing_order() RETURNS text
    LANGUAGE plpython3u
    AS $$

"""
Remove rows in filing_order not prepsent in pg_tables and insert rows in filing_order found 
in pg_tables.

In other words, makes sure that filing_order contains all and only the table names in the 
main schema.

Column "filing_order" gets NULL value when rows are inserted

"""

USE_SCHEMA= 'main' ## schemaname in pg_tables to query 

deleted_rows= []
inserted_rows= []


missing_row= plpy.execute("""
    select tablename 
    from pg_tables left join filing_order on 
        pg_tables.tablename = filing_order.table_name
    where filing_order.table_name is null and
    pg_tables.schemaname = %s 
    """ %(plpy.quote_literal(USE_SCHEMA) ))
if missing_row.nrows() > 0:
    for i in range(0, missing_row.nrows()):
        xrow= missing_row[i]['tablename']
        plpy.execute("""
            insert into filing_order values (null, %s)
            """ %( plpy.quote_literal(xrow) )
            )
        inserted_rows.append(xrow)
extra_row= plpy.execute("""
    select table_name 
    from filing_order left join pg_tables on 
        filing_order.table_name = pg_tables.tablename
    where pg_tables.tablename is null
    """)
    
if extra_row.nrows() > 0:
    for i in range(0, extra_row.nrows()):
        xrow= extra_row[i]['table_name']
        plpy.execute("""
            delete from filing_order where table_name = %s
        """ %( plpy.quote_literal(xrow) )
        )
        deleted_rows.append(xrow)
return('Rows deleted: %s; Rows inserted: %s' %('; '.join(deleted_rows), ', '.join(inserted_rows)))
$$;


ALTER FUNCTION public.update_filing_order() OWNER TO dberaldi;

--
-- TOC entry 868 (class 1255 OID 52812)
-- Dependencies: 5 1589
-- Name: upload_bamqc(text, text); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION upload_bamqc(filename text, bamqc_table text DEFAULT 'bamqc'::text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
/*
Upload the output of bamqc.py to a target table.
Duplicate rows or rows already in the target table are skipped therefore
it is fine to import files with redundant rows.

See also http://code.google.com/p/bioinformatics-misc/source/browse/trunk/bamqc.py

ARGUMENTS:
    filename: File containing the bamqc output to import.
              Without header. No default required 

    bamqc_table: Append to this table. Default is bamqc

REQUIREMENTS:
    Funtion read_table. See http://code.google.com/p/postgresql-read-table/source/browse/trunk/read_table-0.97-alpha-py3.sql
*/
BEGIN
-- Import data file
EXECUTE 'CREATE TABLE bamqc_upload_tmp (LIKE ' || quote_ident(bamqc_table) || ' INCLUDING DEFAULTS)';
EXECUTE 'COPY bamqc_upload_tmp FROM ' || quote_literal(filename) || $del$ WITH CSV DELIMITER E'\t'$del$;
--'SELECT read_table($$ file: ' || quote_literal(filename) || ', header:False, temp:False, table: "bamqc_upload_tmp", overwrite:True $$)';
-- Remove duplicates
EXECUTE 'INSERT INTO ' || quote_ident(bamqc_table) ||
    ' SELECT DISTINCT * FROM bamqc_upload_tmp
      EXCEPT
      SELECT * FROM ' || quote_ident(bamqc_table); 
EXECUTE 'DROP TABLE bamqc_upload_tmp';
END
$_$;


ALTER FUNCTION public.upload_bamqc(filename text, bamqc_table text) OWNER TO dberaldi;

--
-- TOC entry 677 (class 1255 OID 103865)
-- Dependencies: 1589 5
-- Name: validate_exp_values(); Type: FUNCTION; Schema: public; Owner: dberaldi
--

CREATE FUNCTION validate_exp_values() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    sqlstring text;
    value_type_array text[];

BEGIN
sqlstring := 'SELECT DISTINCT ARRAY[exp_values.s_value, exp_variables.variable_type]
              FROM exp_values INNER JOIN exp_variables ON exp_values.s_variable = exp_variables.s_variable';

FOR value_type_array IN EXECUTE sqlstring
LOOP
    sqlstring := 'select ' || quote_literal(value_type_array[1]) || '::' || value_type_array[2];
    EXECUTE sqlstring;
END LOOP;
RETURN null;  
END;
$$;


ALTER FUNCTION public.validate_exp_values() OWNER TO dberaldi;

SET search_path = utl_file, pg_catalog;

--
-- TOC entry 621 (class 1255 OID 116935)
-- Dependencies: 1329 1329 55
-- Name: fclose(file_type); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fclose(file file_type) RETURNS file_type
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fclose';


ALTER FUNCTION utl_file.fclose(file file_type) OWNER TO dberaldi;

--
-- TOC entry 3709 (class 0 OID 0)
-- Dependencies: 621
-- Name: FUNCTION fclose(file file_type); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fclose(file file_type) IS 'Close file';


--
-- TOC entry 622 (class 1255 OID 116936)
-- Dependencies: 55
-- Name: fclose_all(); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fclose_all() RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fclose_all';


ALTER FUNCTION utl_file.fclose_all() OWNER TO dberaldi;

--
-- TOC entry 3710 (class 0 OID 0)
-- Dependencies: 622
-- Name: FUNCTION fclose_all(); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fclose_all() IS 'Close all open files.';


--
-- TOC entry 626 (class 1255 OID 116940)
-- Dependencies: 55
-- Name: fcopy(text, text, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fcopy';


ALTER FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text) OWNER TO dberaldi;

--
-- TOC entry 3711 (class 0 OID 0)
-- Dependencies: 626
-- Name: FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text) IS 'Copy a text file.';


--
-- TOC entry 627 (class 1255 OID 116941)
-- Dependencies: 55
-- Name: fcopy(text, text, text, text, integer); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fcopy';


ALTER FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer) OWNER TO dberaldi;

--
-- TOC entry 3712 (class 0 OID 0)
-- Dependencies: 627
-- Name: FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer) IS 'Copy a text file.';


--
-- TOC entry 628 (class 1255 OID 116942)
-- Dependencies: 55
-- Name: fcopy(text, text, text, text, integer, integer); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer, end_line integer) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fcopy';


ALTER FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer, end_line integer) OWNER TO dberaldi;

--
-- TOC entry 3713 (class 0 OID 0)
-- Dependencies: 628
-- Name: FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer, end_line integer); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer, end_line integer) IS 'Copy a text file.';


--
-- TOC entry 620 (class 1255 OID 116934)
-- Dependencies: 1329 55
-- Name: fflush(file_type); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fflush(file file_type) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fflush';


ALTER FUNCTION utl_file.fflush(file file_type) OWNER TO dberaldi;

--
-- TOC entry 3714 (class 0 OID 0)
-- Dependencies: 620
-- Name: FUNCTION fflush(file file_type); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fflush(file file_type) IS 'This procedure makes sure that all pending data for specified file is written physically out to a file';


--
-- TOC entry 629 (class 1255 OID 116943)
-- Dependencies: 55
-- Name: fgetattr(text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fgetattr(location text, filename text, OUT fexists boolean, OUT file_length bigint, OUT blocksize integer) RETURNS record
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fgetattr';


ALTER FUNCTION utl_file.fgetattr(location text, filename text, OUT fexists boolean, OUT file_length bigint, OUT blocksize integer) OWNER TO dberaldi;

--
-- TOC entry 3715 (class 0 OID 0)
-- Dependencies: 629
-- Name: FUNCTION fgetattr(location text, filename text, OUT fexists boolean, OUT file_length bigint, OUT blocksize integer); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fgetattr(location text, filename text, OUT fexists boolean, OUT file_length bigint, OUT blocksize integer) IS 'Get file attributes.';


--
-- TOC entry 604 (class 1255 OID 116917)
-- Dependencies: 55 1329
-- Name: fopen(text, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fopen(location text, filename text, open_mode text) RETURNS file_type
    LANGUAGE sql
    AS $_$SELECT utl_file.fopen($1, $2, $3, 1024); $_$;


ALTER FUNCTION utl_file.fopen(location text, filename text, open_mode text) OWNER TO dberaldi;

--
-- TOC entry 603 (class 1255 OID 116916)
-- Dependencies: 1329 55
-- Name: fopen(text, text, text, integer); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fopen(location text, filename text, open_mode text, max_linesize integer) RETURNS file_type
    LANGUAGE c SECURITY DEFINER
    AS '$libdir/orafunc', 'utl_file_fopen';


ALTER FUNCTION utl_file.fopen(location text, filename text, open_mode text, max_linesize integer) OWNER TO dberaldi;

--
-- TOC entry 3716 (class 0 OID 0)
-- Dependencies: 603
-- Name: FUNCTION fopen(location text, filename text, open_mode text, max_linesize integer); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fopen(location text, filename text, open_mode text, max_linesize integer) IS 'The FOPEN function open file and return file handle';


--
-- TOC entry 602 (class 1255 OID 116915)
-- Dependencies: 1329 55
-- Name: fopen(text, text, text, integer, name); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fopen(location text, filename text, open_mode text, max_linesize integer, encoding name) RETURNS file_type
    LANGUAGE c SECURITY DEFINER
    AS '$libdir/orafunc', 'utl_file_fopen';


ALTER FUNCTION utl_file.fopen(location text, filename text, open_mode text, max_linesize integer, encoding name) OWNER TO dberaldi;

--
-- TOC entry 3717 (class 0 OID 0)
-- Dependencies: 602
-- Name: FUNCTION fopen(location text, filename text, open_mode text, max_linesize integer, encoding name); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fopen(location text, filename text, open_mode text, max_linesize integer, encoding name) IS 'The FOPEN function open file and return file handle';


--
-- TOC entry 623 (class 1255 OID 116937)
-- Dependencies: 55
-- Name: fremove(text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION fremove(location text, filename text) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_fremove';


ALTER FUNCTION utl_file.fremove(location text, filename text) OWNER TO dberaldi;

--
-- TOC entry 3718 (class 0 OID 0)
-- Dependencies: 623
-- Name: FUNCTION fremove(location text, filename text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION fremove(location text, filename text) IS 'Remove file.';


--
-- TOC entry 625 (class 1255 OID 116939)
-- Dependencies: 55
-- Name: frename(text, text, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION frename(location text, filename text, dest_dir text, dest_file text) RETURNS void
    LANGUAGE sql
    AS $_$SELECT utl_file.frename($1, $2, $3, $4, false);$_$;


ALTER FUNCTION utl_file.frename(location text, filename text, dest_dir text, dest_file text) OWNER TO dberaldi;

--
-- TOC entry 3719 (class 0 OID 0)
-- Dependencies: 625
-- Name: FUNCTION frename(location text, filename text, dest_dir text, dest_file text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION frename(location text, filename text, dest_dir text, dest_file text) IS 'Rename file.';


--
-- TOC entry 624 (class 1255 OID 116938)
-- Dependencies: 55
-- Name: frename(text, text, text, text, boolean); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION frename(location text, filename text, dest_dir text, dest_file text, overwrite boolean) RETURNS void
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_frename';


ALTER FUNCTION utl_file.frename(location text, filename text, dest_dir text, dest_file text, overwrite boolean) OWNER TO dberaldi;

--
-- TOC entry 3720 (class 0 OID 0)
-- Dependencies: 624
-- Name: FUNCTION frename(location text, filename text, dest_dir text, dest_file text, overwrite boolean); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION frename(location text, filename text, dest_dir text, dest_file text, overwrite boolean) IS 'Rename file.';


--
-- TOC entry 606 (class 1255 OID 116919)
-- Dependencies: 1329 55
-- Name: get_line(file_type); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION get_line(file file_type, OUT buffer text) RETURNS text
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_get_line';


ALTER FUNCTION utl_file.get_line(file file_type, OUT buffer text) OWNER TO dberaldi;

--
-- TOC entry 3721 (class 0 OID 0)
-- Dependencies: 606
-- Name: FUNCTION get_line(file file_type, OUT buffer text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION get_line(file file_type, OUT buffer text) IS 'Returns one line from file';


--
-- TOC entry 607 (class 1255 OID 116920)
-- Dependencies: 55 1329
-- Name: get_line(file_type, integer); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION get_line(file file_type, OUT buffer text, len integer) RETURNS text
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_get_line';


ALTER FUNCTION utl_file.get_line(file file_type, OUT buffer text, len integer) OWNER TO dberaldi;

--
-- TOC entry 3722 (class 0 OID 0)
-- Dependencies: 607
-- Name: FUNCTION get_line(file file_type, OUT buffer text, len integer); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION get_line(file file_type, OUT buffer text, len integer) IS 'Returns one line from file';


--
-- TOC entry 608 (class 1255 OID 116921)
-- Dependencies: 1329 55
-- Name: get_nextline(file_type); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION get_nextline(file file_type, OUT buffer text) RETURNS text
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_get_nextline';


ALTER FUNCTION utl_file.get_nextline(file file_type, OUT buffer text) OWNER TO dberaldi;

--
-- TOC entry 3723 (class 0 OID 0)
-- Dependencies: 608
-- Name: FUNCTION get_nextline(file file_type, OUT buffer text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION get_nextline(file file_type, OUT buffer text) IS 'Returns one line from file or returns NULL';


--
-- TOC entry 605 (class 1255 OID 116918)
-- Dependencies: 55 1329
-- Name: is_open(file_type); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION is_open(file file_type) RETURNS boolean
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_is_open';


ALTER FUNCTION utl_file.is_open(file file_type) OWNER TO dberaldi;

--
-- TOC entry 3724 (class 0 OID 0)
-- Dependencies: 605
-- Name: FUNCTION is_open(file file_type); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION is_open(file file_type) IS 'Functions returns true if handle points to file that is open';


--
-- TOC entry 610 (class 1255 OID 116924)
-- Dependencies: 55 1329
-- Name: new_line(file_type); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION new_line(file file_type) RETURNS boolean
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_new_line';


ALTER FUNCTION utl_file.new_line(file file_type) OWNER TO dberaldi;

--
-- TOC entry 3725 (class 0 OID 0)
-- Dependencies: 610
-- Name: FUNCTION new_line(file file_type); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION new_line(file file_type) IS 'Function inserts one ore more newline characters in specified file';


--
-- TOC entry 611 (class 1255 OID 116925)
-- Dependencies: 55 1329
-- Name: new_line(file_type, integer); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION new_line(file file_type, lines integer) RETURNS boolean
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_new_line';


ALTER FUNCTION utl_file.new_line(file file_type, lines integer) OWNER TO dberaldi;

--
-- TOC entry 594 (class 1255 OID 116922)
-- Dependencies: 1329 55
-- Name: put(file_type, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION put(file file_type, buffer text) RETURNS boolean
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_put';


ALTER FUNCTION utl_file.put(file file_type, buffer text) OWNER TO dberaldi;

--
-- TOC entry 3726 (class 0 OID 0)
-- Dependencies: 594
-- Name: FUNCTION put(file file_type, buffer text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION put(file file_type, buffer text) IS 'Puts data to specified file';


--
-- TOC entry 609 (class 1255 OID 116923)
-- Dependencies: 1329 55
-- Name: put(file_type, anyelement); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION put(file file_type, buffer anyelement) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.put($1, $2::text); $_$;


ALTER FUNCTION utl_file.put(file file_type, buffer anyelement) OWNER TO dberaldi;

--
-- TOC entry 3727 (class 0 OID 0)
-- Dependencies: 609
-- Name: FUNCTION put(file file_type, buffer anyelement); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION put(file file_type, buffer anyelement) IS 'Puts data to specified file';


--
-- TOC entry 612 (class 1255 OID 116926)
-- Dependencies: 1329 55
-- Name: put_line(file_type, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION put_line(file file_type, buffer text) RETURNS boolean
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_put_line';


ALTER FUNCTION utl_file.put_line(file file_type, buffer text) OWNER TO dberaldi;

--
-- TOC entry 3728 (class 0 OID 0)
-- Dependencies: 612
-- Name: FUNCTION put_line(file file_type, buffer text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION put_line(file file_type, buffer text) IS 'Puts data to specified file and append newline character';


--
-- TOC entry 668 (class 1255 OID 116991)
-- Dependencies: 1329 55
-- Name: put_line(file_type, anyelement); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION put_line(file file_type, buffer anyelement) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.put_line($1, $2::text); $_$;


ALTER FUNCTION utl_file.put_line(file file_type, buffer anyelement) OWNER TO dberaldi;

--
-- TOC entry 3729 (class 0 OID 0)
-- Dependencies: 668
-- Name: FUNCTION put_line(file file_type, buffer anyelement); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION put_line(file file_type, buffer anyelement) IS 'Puts data to specified file and append newline character';


--
-- TOC entry 613 (class 1255 OID 116927)
-- Dependencies: 55 1329
-- Name: put_line(file_type, text, boolean); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION put_line(file file_type, buffer text, autoflush boolean) RETURNS boolean
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_put_line';


ALTER FUNCTION utl_file.put_line(file file_type, buffer text, autoflush boolean) OWNER TO dberaldi;

--
-- TOC entry 3730 (class 0 OID 0)
-- Dependencies: 613
-- Name: FUNCTION put_line(file file_type, buffer text, autoflush boolean); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION put_line(file file_type, buffer text, autoflush boolean) IS 'Puts data to specified file and append newline character';


--
-- TOC entry 669 (class 1255 OID 116992)
-- Dependencies: 1329 55
-- Name: put_line(file_type, anyelement, boolean); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION put_line(file file_type, buffer anyelement, autoflush boolean) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.put_line($1, $2::text, true); $_$;


ALTER FUNCTION utl_file.put_line(file file_type, buffer anyelement, autoflush boolean) OWNER TO dberaldi;

--
-- TOC entry 3731 (class 0 OID 0)
-- Dependencies: 669
-- Name: FUNCTION put_line(file file_type, buffer anyelement, autoflush boolean); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION put_line(file file_type, buffer anyelement, autoflush boolean) IS 'Puts data to specified file and append newline character';


--
-- TOC entry 619 (class 1255 OID 116933)
-- Dependencies: 1329 55
-- Name: putf(file_type, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION putf(file file_type, format text) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.putf($1, $2, NULL, NULL, NULL, NULL, NULL); $_$;


ALTER FUNCTION utl_file.putf(file file_type, format text) OWNER TO dberaldi;

--
-- TOC entry 3732 (class 0 OID 0)
-- Dependencies: 619
-- Name: FUNCTION putf(file file_type, format text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION putf(file file_type, format text) IS 'Puts formatted data to specified file';


--
-- TOC entry 618 (class 1255 OID 116932)
-- Dependencies: 55 1329
-- Name: putf(file_type, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION putf(file file_type, format text, arg1 text) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.putf($1, $2, $3, NULL, NULL, NULL, NULL); $_$;


ALTER FUNCTION utl_file.putf(file file_type, format text, arg1 text) OWNER TO dberaldi;

--
-- TOC entry 3733 (class 0 OID 0)
-- Dependencies: 618
-- Name: FUNCTION putf(file file_type, format text, arg1 text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION putf(file file_type, format text, arg1 text) IS 'Puts formatted data to specified file';


--
-- TOC entry 617 (class 1255 OID 116931)
-- Dependencies: 1329 55
-- Name: putf(file_type, text, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION putf(file file_type, format text, arg1 text, arg2 text) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.putf($1, $2, $3, $4, NULL, NULL, NULL); $_$;


ALTER FUNCTION utl_file.putf(file file_type, format text, arg1 text, arg2 text) OWNER TO dberaldi;

--
-- TOC entry 616 (class 1255 OID 116930)
-- Dependencies: 55 1329
-- Name: putf(file_type, text, text, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.putf($1, $2, $3, $4, $5, NULL, NULL); $_$;


ALTER FUNCTION utl_file.putf(file file_type, format text, arg1 text, arg2 text, arg3 text) OWNER TO dberaldi;

--
-- TOC entry 3734 (class 0 OID 0)
-- Dependencies: 616
-- Name: FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text) IS 'Puts formatted data to specified file';


--
-- TOC entry 615 (class 1255 OID 116929)
-- Dependencies: 1329 55
-- Name: putf(file_type, text, text, text, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text) RETURNS boolean
    LANGUAGE sql
    AS $_$SELECT utl_file.putf($1, $2, $3, $4, $5, $6, NULL); $_$;


ALTER FUNCTION utl_file.putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text) OWNER TO dberaldi;

--
-- TOC entry 3735 (class 0 OID 0)
-- Dependencies: 615
-- Name: FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text) IS 'Puts formatted data to specified file';


--
-- TOC entry 614 (class 1255 OID 116928)
-- Dependencies: 55 1329
-- Name: putf(file_type, text, text, text, text, text, text); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text, arg5 text) RETURNS boolean
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_putf';


ALTER FUNCTION utl_file.putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text, arg5 text) OWNER TO dberaldi;

--
-- TOC entry 3736 (class 0 OID 0)
-- Dependencies: 614
-- Name: FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text, arg5 text); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION putf(file file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text, arg5 text) IS 'Puts formatted data to specified file';


--
-- TOC entry 630 (class 1255 OID 116944)
-- Dependencies: 55
-- Name: tmpdir(); Type: FUNCTION; Schema: utl_file; Owner: dberaldi
--

CREATE FUNCTION tmpdir() RETURNS text
    LANGUAGE c
    AS '$libdir/orafunc', 'utl_file_tmpdir';


ALTER FUNCTION utl_file.tmpdir() OWNER TO dberaldi;

--
-- TOC entry 3737 (class 0 OID 0)
-- Dependencies: 630
-- Name: FUNCTION tmpdir(); Type: COMMENT; Schema: utl_file; Owner: dberaldi
--

COMMENT ON FUNCTION tmpdir() IS 'Get temp directory path.';


SET search_path = "20120622_rnaseq_pdsa", pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 439 (class 1259 OID 172984)
-- Dependencies: 105
-- Name: cufflinks_gtf; Type: TABLE; Schema: 20120622_rnaseq_pdsa; Owner: dberaldi; Tablespace: 
--

CREATE TABLE cufflinks_gtf (
    chrom text,
    library_id text,
    feature text,
    fstart integer,
    fend integer,
    score integer,
    strand text,
    frame text,
    gene_id text,
    transcript_id text,
    fpkm text,
    frac double precision,
    conf_lo double precision,
    conf_hi double precision,
    cov double precision,
    attributes text,
    project_id text
);


ALTER TABLE "20120622_rnaseq_pdsa".cufflinks_gtf OWNER TO dberaldi;

SET search_path = dbms_pipe, pg_catalog;

--
-- TOC entry 434 (class 1259 OID 116790)
-- Dependencies: 3224 46
-- Name: db_pipes; Type: VIEW; Schema: dbms_pipe; Owner: dberaldi
--

CREATE VIEW db_pipes AS
    SELECT __list_pipes.name, __list_pipes.items, __list_pipes.size, __list_pipes."limit", __list_pipes.private, __list_pipes.owner FROM __list_pipes() __list_pipes(name character varying, items integer, size integer, "limit" integer, private boolean, owner character varying);


ALTER TABLE dbms_pipe.db_pipes OWNER TO dberaldi;

SET search_path = django_admin, pg_catalog;

--
-- TOC entry 404 (class 1259 OID 31279)
-- Dependencies: 39
-- Name: auth_group; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE django_admin.auth_group OWNER TO dberaldi;

--
-- TOC entry 403 (class 1259 OID 31277)
-- Dependencies: 404 39
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.auth_group_id_seq OWNER TO dberaldi;

--
-- TOC entry 3740 (class 0 OID 0)
-- Dependencies: 403
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- TOC entry 402 (class 1259 OID 31264)
-- Dependencies: 39
-- Name: auth_group_permissions; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE django_admin.auth_group_permissions OWNER TO dberaldi;

--
-- TOC entry 401 (class 1259 OID 31262)
-- Dependencies: 402 39
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.auth_group_permissions_id_seq OWNER TO dberaldi;

--
-- TOC entry 3741 (class 0 OID 0)
-- Dependencies: 401
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- TOC entry 412 (class 1259 OID 31344)
-- Dependencies: 39
-- Name: auth_message; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE auth_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL
);


ALTER TABLE django_admin.auth_message OWNER TO dberaldi;

--
-- TOC entry 411 (class 1259 OID 31342)
-- Dependencies: 39 412
-- Name: auth_message_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE auth_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.auth_message_id_seq OWNER TO dberaldi;

--
-- TOC entry 3742 (class 0 OID 0)
-- Dependencies: 411
-- Name: auth_message_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE auth_message_id_seq OWNED BY auth_message.id;


--
-- TOC entry 400 (class 1259 OID 31254)
-- Dependencies: 39
-- Name: auth_permission; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE django_admin.auth_permission OWNER TO dberaldi;

--
-- TOC entry 399 (class 1259 OID 31252)
-- Dependencies: 400 39
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.auth_permission_id_seq OWNER TO dberaldi;

--
-- TOC entry 3743 (class 0 OID 0)
-- Dependencies: 399
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- TOC entry 410 (class 1259 OID 31324)
-- Dependencies: 39
-- Name: auth_user; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE django_admin.auth_user OWNER TO dberaldi;

--
-- TOC entry 408 (class 1259 OID 31309)
-- Dependencies: 39
-- Name: auth_user_groups; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE django_admin.auth_user_groups OWNER TO dberaldi;

--
-- TOC entry 407 (class 1259 OID 31307)
-- Dependencies: 39 408
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.auth_user_groups_id_seq OWNER TO dberaldi;

--
-- TOC entry 3744 (class 0 OID 0)
-- Dependencies: 407
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- TOC entry 409 (class 1259 OID 31322)
-- Dependencies: 410 39
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.auth_user_id_seq OWNER TO dberaldi;

--
-- TOC entry 3745 (class 0 OID 0)
-- Dependencies: 409
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- TOC entry 406 (class 1259 OID 31294)
-- Dependencies: 39
-- Name: auth_user_user_permissions; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE django_admin.auth_user_user_permissions OWNER TO dberaldi;

--
-- TOC entry 405 (class 1259 OID 31292)
-- Dependencies: 406 39
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.auth_user_user_permissions_id_seq OWNER TO dberaldi;

--
-- TOC entry 3746 (class 0 OID 0)
-- Dependencies: 405
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- TOC entry 419 (class 1259 OID 31401)
-- Dependencies: 3290 39
-- Name: django_admin_log; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin.django_admin_log OWNER TO dberaldi;

--
-- TOC entry 418 (class 1259 OID 31399)
-- Dependencies: 419 39
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.django_admin_log_id_seq OWNER TO dberaldi;

--
-- TOC entry 3747 (class 0 OID 0)
-- Dependencies: 418
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- TOC entry 414 (class 1259 OID 31360)
-- Dependencies: 39
-- Name: django_content_type; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_admin.django_content_type OWNER TO dberaldi;

--
-- TOC entry 413 (class 1259 OID 31358)
-- Dependencies: 39 414
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.django_content_type_id_seq OWNER TO dberaldi;

--
-- TOC entry 3748 (class 0 OID 0)
-- Dependencies: 413
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- TOC entry 415 (class 1259 OID 31373)
-- Dependencies: 39
-- Name: django_session; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_admin.django_session OWNER TO dberaldi;

--
-- TOC entry 417 (class 1259 OID 31383)
-- Dependencies: 39
-- Name: django_site; Type: TABLE; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE django_admin.django_site OWNER TO dberaldi;

--
-- TOC entry 416 (class 1259 OID 31381)
-- Dependencies: 39 417
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: django_admin; Owner: dberaldi
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin.django_site_id_seq OWNER TO dberaldi;

--
-- TOC entry 3749 (class 0 OID 0)
-- Dependencies: 416
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: django_admin; Owner: dberaldi
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


SET search_path = main, pg_catalog;

--
-- TOC entry 436 (class 1259 OID 117037)
-- Dependencies: 1304 7
-- Name: bamqc; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE bamqc (
    bamfile text,
    fullname text,
    md5sum md5sum,
    fsize bigint,
    ctime timestamp without time zone,
    mtime timestamp without time zone,
    len_median double precision,
    len_sd double precision,
    n integer,
    aln integer,
    perc_aln double precision,
    mapq_0 integer,
    mapq_5 integer,
    mapq_10 integer,
    mapq_15 integer,
    mapq_20 integer,
    mapq_25 integer,
    mapq_30 integer,
    mapq_35 integer,
    mapq_40 integer,
    mapq_255 integer,
    nm_0 integer,
    nm_1 integer,
    nm_2 integer,
    nm_3 integer,
    nm_4 integer,
    nm_5 integer,
    nm_6 integer,
    nm_na integer,
    mapq_quant_0_05 double precision,
    mapq_quant_0_25 double precision,
    mapq_quant_0_5 double precision,
    mapq_quant_0_75 double precision,
    mapq_quant_0_95 double precision,
    samflags text
);


ALTER TABLE main.bamqc OWNER TO dberaldi;

--
-- TOC entry 389 (class 1259 OID 29355)
-- Dependencies: 7
-- Name: barcodes; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE barcodes (
    barcode_id text NOT NULL,
    barcode_sequence text,
    adapter_sequence text,
    description text
);


ALTER TABLE main.barcodes OWNER TO dberaldi;

--
-- TOC entry 467 (class 1259 OID 630046)
-- Dependencies: 7
-- Name: barcodes_bak; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE barcodes_bak (
    barcode_id text,
    barcode_sequence text,
    adapter_sequence text,
    description text
);


ALTER TABLE main.barcodes_bak OWNER TO dberaldi;

--
-- TOC entry 444 (class 1259 OID 209604)
-- Dependencies: 7
-- Name: bismark_mapping_report; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE bismark_mapping_report (
    bismark_report_for text,
    full_path text,
    bismark_version text,
    ref_genome text,
    bowtie_options text,
    is_directional text,
    seqs_tot bigint,
    seqs_alned_uniq bigint,
    mapping_efficiency text,
    seqs_not_alned bigint,
    seqs_not_uniq bigint,
    discarded_seqs bigint,
    "OT" bigint,
    "OB" bigint,
    "CTOT" bigint,
    "CTOB" bigint,
    tot_cs bigint,
    "mC_cpg" bigint,
    "mC_chg" bigint,
    "mC_chh" bigint,
    c2t_cpg bigint,
    c2t_chg bigint,
    c2t_chh bigint,
    "perc_mC_cpg" double precision,
    "perc_mC_chg" double precision,
    "perc_mC_chh" double precision,
    report_name text
);


ALTER TABLE main.bismark_mapping_report OWNER TO dberaldi;

--
-- TOC entry 390 (class 1259 OID 29383)
-- Dependencies: 7
-- Name: contacts; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE contacts (
    contact_name text NOT NULL,
    initials text
);


ALTER TABLE main.contacts OWNER TO dberaldi;

--
-- TOC entry 437 (class 1259 OID 151925)
-- Dependencies: 1304 7
-- Name: demux_report; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE demux_report (
    fastqfile_demux text,
    fastqfile_master text,
    barcode_sequence text,
    barcode_id text,
    nreads bigint,
    nreads_master bigint,
    percent_demux numeric,
    nreads_lost bigint,
    percent_lost numeric,
    md5sum md5sum,
    fsize bigint,
    mtime timestamp without time zone,
    path text,
    match_report text[],
    spurious_report text[]
);


ALTER TABLE main.demux_report OWNER TO dberaldi;

--
-- TOC entry 458 (class 1259 OID 256688)
-- Dependencies: 7
-- Name: encodings; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE encodings (
    encoding text NOT NULL,
    description text
);


ALTER TABLE main.encodings OWNER TO dberaldi;

--
-- TOC entry 3750 (class 0 OID 0)
-- Dependencies: 458
-- Name: TABLE encodings; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE encodings IS 'Allowed encodings for fastqfiles as reported by GEO.';


--
-- TOC entry 382 (class 1259 OID 24621)
-- Dependencies: 3267 7
-- Name: exp_design; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design (
    sample_id text NOT NULL,
    s_variable text NOT NULL,
    s_value text NOT NULL,
    id integer NOT NULL,
    CONSTRAINT exp_design_s_value_check CHECK ((s_value IS NOT NULL))
);


ALTER TABLE main.exp_design OWNER TO dberaldi;

--
-- TOC entry 3751 (class 0 OID 0)
-- Dependencies: 382
-- Name: TABLE exp_design; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE exp_design IS 'Info about each sample';


--
-- TOC entry 3752 (class 0 OID 0)
-- Dependencies: 382
-- Name: COLUMN exp_design.sample_id; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN exp_design.sample_id IS 'Biological source of this sample';


--
-- TOC entry 3753 (class 0 OID 0)
-- Dependencies: 382
-- Name: COLUMN exp_design.s_variable; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN exp_design.s_variable IS 'Treatment applied';


--
-- TOC entry 3754 (class 0 OID 0)
-- Dependencies: 382
-- Name: COLUMN exp_design.s_value; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN exp_design.s_value IS 'Any commnent here';


--
-- TOC entry 420 (class 1259 OID 31709)
-- Dependencies: 7 382
-- Name: exp_design_id_seq; Type: SEQUENCE; Schema: main; Owner: dberaldi
--

CREATE SEQUENCE exp_design_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main.exp_design_id_seq OWNER TO dberaldi;

--
-- TOC entry 3755 (class 0 OID 0)
-- Dependencies: 420
-- Name: exp_design_id_seq; Type: SEQUENCE OWNED BY; Schema: main; Owner: dberaldi
--

ALTER SEQUENCE exp_design_id_seq OWNED BY exp_design.id;


--
-- TOC entry 423 (class 1259 OID 31974)
-- Dependencies: 7
-- Name: exp_values; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_values (
    s_variable text,
    s_value text,
    id integer NOT NULL,
    description text
);


ALTER TABLE main.exp_values OWNER TO dberaldi;

--
-- TOC entry 424 (class 1259 OID 31987)
-- Dependencies: 7 423
-- Name: exp_values_id_seq; Type: SEQUENCE; Schema: main; Owner: dberaldi
--

CREATE SEQUENCE exp_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main.exp_values_id_seq OWNER TO dberaldi;

--
-- TOC entry 3756 (class 0 OID 0)
-- Dependencies: 424
-- Name: exp_values_id_seq; Type: SEQUENCE OWNED BY; Schema: main; Owner: dberaldi
--

ALTER SEQUENCE exp_values_id_seq OWNED BY exp_values.id;


--
-- TOC entry 394 (class 1259 OID 30387)
-- Dependencies: 3276 3277 7
-- Name: exp_variables; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_variables (
    s_variable text NOT NULL,
    description text NOT NULL,
    in_use boolean DEFAULT true,
    variable_type text DEFAULT 'text'::text
);


ALTER TABLE main.exp_variables OWNER TO dberaldi;

--
-- TOC entry 3757 (class 0 OID 0)
-- Dependencies: 394
-- Name: TABLE exp_variables; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE exp_variables IS 'Look-up table for experimental variables in exp_design';


--
-- TOC entry 3758 (class 0 OID 0)
-- Dependencies: 394
-- Name: COLUMN exp_variables.in_use; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN exp_variables.in_use IS 'Is this variable currently in use or deprecated? False implies that it is no longer necessary and should not be used, it could be deleted but it is temporarily kept for safety';


--
-- TOC entry 3759 (class 0 OID 0)
-- Dependencies: 394
-- Name: COLUMN exp_variables.variable_type; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN exp_variables.variable_type IS 'The type of values that the variable takes (all values in exp_values.s_values are stored as text). It should be a valid SQL data type applicaple to underlying values in exp_values.s_values.';


--
-- TOC entry 468 (class 1259 OID 911953)
-- Dependencies: 1304 7
-- Name: fastqc; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE fastqc (
    fastqc text,
    base_stats text,
    filename text,
    file_type text,
    encoding text,
    tot_sequences bigint,
    fitered_sequences bigint,
    sequence_length_all text,
    gc_cont double precision,
    md5sum md5sum,
    per_base_sequence_quality text,
    pbsq_mean double precision[],
    pbsq_median double precision[],
    pbsq_lower_quartile double precision[],
    pbsq_upper_quartile double precision[],
    pbsq_10th_percentile double precision[],
    pbsq_90th_percentile double precision[],
    per_sequence_quality_scores text,
    psqs_quality bigint[],
    psqs_count double precision[],
    per_base_sequence_content text,
    pbsc_g double precision[],
    pbsc_a double precision[],
    pbsc_t double precision[],
    pbsc_c double precision[],
    per_base_gc_content text,
    pbgc double precision[],
    per_sequence_gc_content text,
    ps_gc_content double precision[],
    ps_gc_count double precision[],
    per_base_n_content text,
    pb_n_count double precision[],
    sequence_length_distribution text,
    sequence_length text[],
    sequence_length_count double precision[],
    sequence_duplication_levels text,
    tot_dupl_percentage double precision,
    dupl_level double precision[],
    dupl_level_relative_count double precision[],
    overrepresented_sequences text,
    overrepresented_sequence text[],
    overrepresented_sequence_count bigint[],
    overrepresented_sequence_percent double precision[],
    possible_source text[],
    kmer_content text,
    kmer_sequence text[],
    kmer_count bigint[],
    obs_exp_overall double precision[],
    obs_exp_max double precision[],
    max_obs_exp_position text[],
    fastqc_file text
);


ALTER TABLE main.fastqc OWNER TO dberaldi;

--
-- TOC entry 453 (class 1259 OID 224534)
-- Dependencies: 7 1304
-- Name: fastqc_bak; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE fastqc_bak (
    fastqc text,
    base_stats text,
    filename text,
    file_type text,
    encoding text,
    tot_sequences integer,
    fitered_sequences integer,
    sequence_length_all text,
    gc_cont double precision,
    md5sum md5sum,
    per_base_sequence_quality text,
    pbsq_mean double precision[],
    pbsq_median double precision[],
    pbsq_lower_quartile double precision[],
    pbsq_upper_quartile double precision[],
    pbsq_10th_percentile double precision[],
    pbsq_90th_percentile double precision[],
    per_sequence_quality_scores text,
    psqs_quality integer[],
    psqs_count double precision[],
    per_base_sequence_content text,
    pbsc_g double precision[],
    pbsc_a double precision[],
    pbsc_t double precision[],
    pbsc_c double precision[],
    per_base_gc_content text,
    pbgc double precision[],
    per_sequence_gc_content text,
    ps_gc_content double precision[],
    ps_gc_count double precision[],
    per_base_n_content text,
    pb_n_count double precision[],
    sequence_length_distribution text,
    sequence_length text[],
    sequence_length_count double precision[],
    sequence_duplication_levels text,
    tot_dupl_percentage double precision,
    dupl_level double precision[],
    dupl_level_relative_count double precision[],
    overrepresented_sequences text,
    overrepresented_sequence text[],
    overrepresented_sequence_count integer[],
    overrepresented_sequence_percent double precision[],
    possible_source text[],
    kmer_content text,
    kmer_sequence text[],
    kmer_count integer[],
    obs_exp_overall double precision[],
    obs_exp_max double precision[],
    max_obs_exp_position text[],
    fastqc_file text
);


ALTER TABLE main.fastqc_bak OWNER TO dberaldi;

--
-- TOC entry 395 (class 1259 OID 30549)
-- Dependencies: 7 1304
-- Name: fastqfiles; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE fastqfiles (
    fastqfile text NOT NULL,
    encoding text NOT NULL,
    md5sum md5sum NOT NULL,
    description text,
    service_id_deprecated text,
    library_id text NOT NULL,
    sequencing_platform text,
    sequencer_id text,
    read text
);


ALTER TABLE main.fastqfiles OWNER TO dberaldi;

--
-- TOC entry 3760 (class 0 OID 0)
-- Dependencies: 395
-- Name: TABLE fastqfiles; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE fastqfiles IS 'Fastqfiles in this table should be ready for import to GEO. That is:
- Assigned to one library only (i.e. *demultiplexed*, multiple files from the same library NOT concatenated even if they are from the same flowcell)
- Reads untrimmed, unfiltered.
- Converted to Sanger encoding (optional but highly recommended)
- Gzipped (optional but highly recommended)
';


--
-- TOC entry 391 (class 1259 OID 29459)
-- Dependencies: 7
-- Name: filing_order; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE filing_order (
    filing_order numeric,
    table_name text NOT NULL
);


ALTER TABLE main.filing_order OWNER TO dberaldi;

--
-- TOC entry 3761 (class 0 OID 0)
-- Dependencies: 391
-- Name: TABLE filing_order; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE filing_order IS ' Order in which the tables in the "main" schema should be filled when new samples or projects arrive. This order prevents foreign key inconsistencies and makes it more logical to fill the database. Tabes are extracted from """select tablename from pg_tables where schemaname = ''main'';""" ';


--
-- TOC entry 430 (class 1259 OID 52894)
-- Dependencies: 7
-- Name: lib2seq; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE lib2seq (
    library_id text NOT NULL,
    service_id text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE main.lib2seq OWNER TO dberaldi;

--
-- TOC entry 429 (class 1259 OID 52892)
-- Dependencies: 430 7
-- Name: lib2seq_id_seq; Type: SEQUENCE; Schema: main; Owner: dberaldi
--

CREATE SEQUENCE lib2seq_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main.lib2seq_id_seq OWNER TO dberaldi;

--
-- TOC entry 3762 (class 0 OID 0)
-- Dependencies: 429
-- Name: lib2seq_id_seq; Type: SEQUENCE OWNED BY; Schema: main; Owner: dberaldi
--

ALTER SEQUENCE lib2seq_id_seq OWNED BY lib2seq.id;


--
-- TOC entry 398 (class 1259 OID 30996)
-- Dependencies: 3278 3279 7
-- Name: libraries; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE libraries (
    library_id text NOT NULL,
    sample_id text NOT NULL,
    barcode_id text DEFAULT 'not_multiplexed'::text,
    contact text NOT NULL,
    service_id_deprecated text,
    description text,
    refdate date DEFAULT ('now'::text)::date,
    library_type text,
    fragment_size_old integer,
    fragment_size text
);


ALTER TABLE main.libraries OWNER TO dberaldi;

--
-- TOC entry 3763 (class 0 OID 0)
-- Dependencies: 398
-- Name: TABLE libraries; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE libraries IS 'Solexa libraries derived from *biological* samples in samples.sample_id. library_id refers to a single library (i.e. not multiplexed)';


--
-- TOC entry 3764 (class 0 OID 0)
-- Dependencies: 398
-- Name: COLUMN libraries.fragment_size; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN libraries.fragment_size IS 'Range for fragment_size as text in the form "200-400"';


--
-- TOC entry 466 (class 1259 OID 350797)
-- Dependencies: 7
-- Name: libraries_bak; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE libraries_bak (
    library_id text,
    sample_id text,
    barcode_id text,
    contact text,
    service_id_deprecated text,
    description text,
    refdate date,
    library_type text,
    fragment_size integer
);


ALTER TABLE main.libraries_bak OWNER TO dberaldi;

--
-- TOC entry 427 (class 1259 OID 46524)
-- Dependencies: 3292 7
-- Name: library_types; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE library_types (
    library_type text NOT NULL,
    description text NOT NULL,
    is_geo boolean DEFAULT false NOT NULL
);


ALTER TABLE main.library_types OWNER TO dberaldi;

--
-- TOC entry 3765 (class 0 OID 0)
-- Dependencies: 427
-- Name: TABLE library_types; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE library_types IS 'Look-up table contatining the allowed types of libraries referenced in table libraries.';


--
-- TOC entry 440 (class 1259 OID 184095)
-- Dependencies: 3294 7
-- Name: molecules; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE molecules (
    molecule text NOT NULL,
    is_geo boolean DEFAULT false NOT NULL,
    description text
);


ALTER TABLE main.molecules OWNER TO dberaldi;

--
-- TOC entry 3766 (class 0 OID 0)
-- Dependencies: 440
-- Name: TABLE molecules; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE molecules IS 'Type of molecule to describe each sample';


--
-- TOC entry 3767 (class 0 OID 0)
-- Dependencies: 440
-- Name: COLUMN molecules.is_geo; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN molecules.is_geo IS 'True/False if the molecule is a valid GEO entry';


--
-- TOC entry 441 (class 1259 OID 184109)
-- Dependencies: 7
-- Name: organisms; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE organisms (
    organism text NOT NULL,
    description text
);


ALTER TABLE main.organisms OWNER TO dberaldi;

--
-- TOC entry 3768 (class 0 OID 0)
-- Dependencies: 441
-- Name: TABLE organisms; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE organisms IS 'Available organsims to describe samples';


--
-- TOC entry 384 (class 1259 OID 24639)
-- Dependencies: 7
-- Name: project_samples; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE project_samples (
    project text NOT NULL,
    sample_id text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE main.project_samples OWNER TO dberaldi;

--
-- TOC entry 422 (class 1259 OID 31739)
-- Dependencies: 7 384
-- Name: project_samples_id_seq; Type: SEQUENCE; Schema: main; Owner: dberaldi
--

CREATE SEQUENCE project_samples_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main.project_samples_id_seq OWNER TO dberaldi;

--
-- TOC entry 3769 (class 0 OID 0)
-- Dependencies: 422
-- Name: project_samples_id_seq; Type: SEQUENCE OWNED BY; Schema: main; Owner: dberaldi
--

ALTER SEQUENCE project_samples_id_seq OWNED BY project_samples.id;


--
-- TOC entry 383 (class 1259 OID 24627)
-- Dependencies: 3268 3269 3270 7
-- Name: projects; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE projects (
    project text NOT NULL,
    start_date date DEFAULT ('now'::text)::date NOT NULL,
    contact text NOT NULL,
    description text NOT NULL,
    is_active boolean DEFAULT true,
    is_deprecated boolean DEFAULT false,
    redmine_page text
);


ALTER TABLE main.projects OWNER TO dberaldi;

--
-- TOC entry 457 (class 1259 OID 231060)
-- Dependencies: 7
-- Name: protocol2library; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE protocol2library (
    library_id text,
    protocol_id text
);


ALTER TABLE main.protocol2library OWNER TO dberaldi;

--
-- TOC entry 456 (class 1259 OID 231044)
-- Dependencies: 7
-- Name: protocol2sample; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE protocol2sample (
    sample_id text,
    protocol_id text
);


ALTER TABLE main.protocol2sample OWNER TO dberaldi;

--
-- TOC entry 454 (class 1259 OID 230960)
-- Dependencies: 7
-- Name: protocol_types; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE protocol_types (
    protocol_type text NOT NULL,
    description text NOT NULL
);


ALTER TABLE main.protocol_types OWNER TO dberaldi;

--
-- TOC entry 455 (class 1259 OID 231022)
-- Dependencies: 7
-- Name: protocols; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE protocols (
    protocol_id text NOT NULL,
    protocol_type text,
    protocol_title text NOT NULL,
    contact_name text NOT NULL,
    protocol_text text NOT NULL,
    description text
);


ALTER TABLE main.protocols OWNER TO dberaldi;

--
-- TOC entry 397 (class 1259 OID 30818)
-- Dependencies: 1304 7
-- Name: reference_seqs; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE reference_seqs (
    reference_seq text NOT NULL,
    filename text,
    format text,
    md5sum md5sum,
    source text,
    description text
);


ALTER TABLE main.reference_seqs OWNER TO dberaldi;

--
-- TOC entry 3770 (class 0 OID 0)
-- Dependencies: 397
-- Name: TABLE reference_seqs; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE reference_seqs IS 'Available reference sequences for various purposes but mostly for alignments. Refer preferably to fasta format for reference sequences. 
NOTE: reference_seq is the identifier of the file which might or might be not the filename itself (e.g. "hg18", "mm9")';


--
-- TOC entry 442 (class 1259 OID 184130)
-- Dependencies: 7
-- Name: sample_sources; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE sample_sources (
    source_name text NOT NULL,
    description text
);


ALTER TABLE main.sample_sources OWNER TO dberaldi;

--
-- TOC entry 3771 (class 0 OID 0)
-- Dependencies: 442
-- Name: TABLE sample_sources; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE sample_sources IS 'Source describing each sample. Should be suitable for GEO submission, avoid duplication with table exp_design';


--
-- TOC entry 385 (class 1259 OID 24677)
-- Dependencies: 3272 7
-- Name: samples; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE samples (
    sample_id text NOT NULL,
    contact text NOT NULL,
    description text,
    refdate date DEFAULT ('now'::text)::date,
    source_name text NOT NULL,
    organism text NOT NULL,
    molecule text NOT NULL
);


ALTER TABLE main.samples OWNER TO dberaldi;

--
-- TOC entry 3772 (class 0 OID 0)
-- Dependencies: 385
-- Name: COLUMN samples.source_name; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN samples.source_name IS 'Source name of the biological material. It should be suitable for GEO submission.';


--
-- TOC entry 3773 (class 0 OID 0)
-- Dependencies: 385
-- Name: COLUMN samples.organism; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN samples.organism IS 'Name of the organism from which the sample comes from. Should be suitable for upload to GEO. Use <species> <genre> format.';


--
-- TOC entry 3774 (class 0 OID 0)
-- Dependencies: 385
-- Name: COLUMN samples.molecule; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN samples.molecule IS 'Type of molecule describing the sample. Should be suitable entry for submission to GEO.';


--
-- TOC entry 464 (class 1259 OID 329356)
-- Dependencies: 3300 3301 3302 3303 3304 3305 3306 3307 3308 3309 3310 3311 1304 7
-- Name: samtools_flagstat; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE samtools_flagstat (
    bamfile text NOT NULL,
    md5sum md5sum NOT NULL,
    mate text NOT NULL,
    tot bigint NOT NULL,
    duplicates bigint NOT NULL,
    mapped bigint NOT NULL,
    pe_seq bigint NOT NULL,
    read1 bigint NOT NULL,
    read2 bigint NOT NULL,
    prop_pe bigint NOT NULL,
    itself_mate bigint NOT NULL,
    singletons bigint NOT NULL,
    mate_diff_chr bigint NOT NULL,
    mate_diff_chr_mapq5 bigint NOT NULL,
    CONSTRAINT samtools_flagstat_duplicates_check CHECK ((duplicates >= 0)),
    CONSTRAINT samtools_flagstat_itself_mate_check CHECK ((itself_mate >= 0)),
    CONSTRAINT samtools_flagstat_mapped_check CHECK ((mapped >= 0)),
    CONSTRAINT samtools_flagstat_mate_check CHECK ((mate = ANY (ARRAY['1'::text, '2'::text]))),
    CONSTRAINT samtools_flagstat_mate_diff_chr_check CHECK ((mate_diff_chr >= 0)),
    CONSTRAINT samtools_flagstat_mate_diff_chr_mapq5_check CHECK ((mate_diff_chr_mapq5 >= 0)),
    CONSTRAINT samtools_flagstat_pe_seq_check CHECK ((pe_seq >= 0)),
    CONSTRAINT samtools_flagstat_prop_pe_check CHECK ((prop_pe >= 0)),
    CONSTRAINT samtools_flagstat_read1_check CHECK ((read1 >= 0)),
    CONSTRAINT samtools_flagstat_read2_check CHECK ((read2 >= 0)),
    CONSTRAINT samtools_flagstat_singletons_check CHECK ((singletons >= 0)),
    CONSTRAINT samtools_flagstat_tot_check CHECK ((tot >= 0))
);


ALTER TABLE main.samtools_flagstat OWNER TO dberaldi;

--
-- TOC entry 3775 (class 0 OID 0)
-- Dependencies: 464
-- Name: TABLE samtools_flagstat; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE samtools_flagstat IS 'Output from `samtools flagstat`. Typically uploaded with flagstat_to_sblab.py. For meaning of columns from tot omwards see flagstat';


--
-- TOC entry 463 (class 1259 OID 328205)
-- Dependencies: 3296 3297 3298 3299 1304 7
-- Name: samtools_idxstats; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE samtools_idxstats (
    sequence_name text DEFAULT '*'::text NOT NULL,
    sequence_length bigint DEFAULT 0 NOT NULL,
    reads_mapped bigint DEFAULT 0 NOT NULL,
    reads_unmapped bigint DEFAULT 0 NOT NULL,
    bamfile text NOT NULL,
    md5sum md5sum
);


ALTER TABLE main.samtools_idxstats OWNER TO dberaldi;

--
-- TOC entry 3776 (class 0 OID 0)
-- Dependencies: 463
-- Name: TABLE samtools_idxstats; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE samtools_idxstats IS 'Output from `samtools idxstats`. See also idxstats_to_sblab.py';


--
-- TOC entry 459 (class 1259 OID 262250)
-- Dependencies: 7
-- Name: sequencers; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE sequencers (
    sequencer_id text NOT NULL,
    sequencing_platform text,
    sequencer_ip text,
    location text
);


ALTER TABLE main.sequencers OWNER TO dberaldi;

--
-- TOC entry 451 (class 1259 OID 212614)
-- Dependencies: 7
-- Name: sequencing_platforms; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE sequencing_platforms (
    sequencing_platform text NOT NULL,
    description text
);


ALTER TABLE main.sequencing_platforms OWNER TO dberaldi;

--
-- TOC entry 381 (class 1259 OID 24615)
-- Dependencies: 3263 3264 3265 7
-- Name: solexa_lims; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE solexa_lims (
    refdate date DEFAULT ('now'::text)::date,
    service_id text NOT NULL,
    contact text,
    description text,
    end_type text DEFAULT 'unknown'::text,
    instrument_deprecated text,
    CONSTRAINT check_end_type CHECK ((end_type = ANY (ARRAY['single_end'::text, 'paired_end'::text, 'unknown'::text])))
);


ALTER TABLE main.solexa_lims OWNER TO dberaldi;

--
-- TOC entry 3777 (class 0 OID 0)
-- Dependencies: 381
-- Name: TABLE solexa_lims; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE solexa_lims IS 'Information on samples submitted to solexa for sequencing. These info comes from CRI LIMS (SLX-ID) or from outside. A service is one library or a pool of libraries to be loaded to a sequencer. 
You don''t know what name the fastq file will have until it is produced but you know the service_id which will link the fastq file to the libraries.

See also table_definitions.sql.';


--
-- TOC entry 3778 (class 0 OID 0)
-- Dependencies: 381
-- Name: COLUMN solexa_lims.service_id; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN solexa_lims.service_id IS 'Solexa ID as given by the LIMS';


--
-- TOC entry 3779 (class 0 OID 0)
-- Dependencies: 381
-- Name: COLUMN solexa_lims.contact; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN solexa_lims.contact IS 'Reference contact for information about the sample';


--
-- TOC entry 462 (class 1259 OID 323025)
-- Dependencies: 7
-- Name: synthetic_sequences; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE synthetic_sequences (
    sequence_name text NOT NULL,
    base_position bigint NOT NULL,
    base_iupac text,
    base_modified text
);


ALTER TABLE main.synthetic_sequences OWNER TO dberaldi;

--
-- TOC entry 461 (class 1259 OID 323015)
-- Dependencies: 7
-- Name: synthetic_sequences_codes; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE synthetic_sequences_codes (
    base_modified text NOT NULL,
    description text NOT NULL,
    base_iupac text NOT NULL,
    short_description text
);


ALTER TABLE main.synthetic_sequences_codes OWNER TO dberaldi;

--
-- TOC entry 3780 (class 0 OID 0)
-- Dependencies: 461
-- Name: TABLE synthetic_sequences_codes; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE synthetic_sequences_codes IS 'Codes allowed in synthetic_sequences.sequences_modified';


--
-- TOC entry 465 (class 1259 OID 331839)
-- Dependencies: 7
-- Name: synthetic_sequences_names; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE synthetic_sequences_names (
    sequence_name text NOT NULL,
    sequence_string text,
    description text
);


ALTER TABLE main.synthetic_sequences_names OWNER TO dberaldi;

--
-- TOC entry 3781 (class 0 OID 0)
-- Dependencies: 465
-- Name: COLUMN synthetic_sequences_names.sequence_string; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON COLUMN synthetic_sequences_names.sequence_string IS ' A string representing the sequence (iupac only) which should match select array_to_string(array_agg(base_iupac), '''') from (select * from synthetic_sequences order by sequence_name, base_position) As t group by sequence_name;';


--
-- TOC entry 445 (class 1259 OID 210804)
-- Dependencies: 7
-- Name: trim_galore_report; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE trim_galore_report (
    input_filename text,
    phred_cutoff text,
    adapter_seq text,
    min_adapt_overlap integer,
    is_paired text,
    cutadapt_version text,
    cutadapt_parameters text,
    max_error_perc double precision,
    proc_reads bigint,
    trimmed integer,
    trimmed_perc double precision,
    too_short integer,
    too_short_perc double precision,
    time_sec double precision,
    time_read_ms double precision,
    adapt_hist text[],
    adapt_hist_freq text[],
    report_name text
);


ALTER TABLE main.trim_galore_report OWNER TO dberaldi;

--
-- TOC entry 449 (class 1259 OID 211967)
-- Dependencies: 3227 7
-- Name: view_multiplexed_services; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_multiplexed_services AS
    SELECT count(libraries.library_id) AS no_libs, lib2seq.service_id FROM (lib2seq JOIN libraries ON ((lib2seq.library_id = libraries.library_id))) WHERE (libraries.barcode_id <> 'not_multiplexed'::text) GROUP BY lib2seq.service_id ORDER BY lib2seq.service_id;


ALTER TABLE main.view_multiplexed_services OWNER TO dberaldi;

--
-- TOC entry 3782 (class 0 OID 0)
-- Dependencies: 449
-- Name: VIEW view_multiplexed_services; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_multiplexed_services IS 'Number of barcoded libraries loaded on the same sequencing run (service_id). These services produce multiplexed fastq files.';


--
-- TOC entry 450 (class 1259 OID 211971)
-- Dependencies: 3228 7
-- Name: view_demultiplex_service; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_demultiplex_service AS
    SELECT view_multiplexed_services.service_id, lib2seq.library_id, libraries.barcode_id, barcodes.barcode_sequence, (barcodes.barcode_sequence || 'A'::text) AS sequence4demux FROM (((view_multiplexed_services JOIN lib2seq ON ((view_multiplexed_services.service_id = lib2seq.service_id))) JOIN libraries ON ((libraries.library_id = lib2seq.library_id))) JOIN barcodes ON ((libraries.barcode_id = barcodes.barcode_id))) ORDER BY view_multiplexed_services.service_id, lib2seq.library_id;


ALTER TABLE main.view_demultiplex_service OWNER TO dberaldi;

--
-- TOC entry 3783 (class 0 OID 0)
-- Dependencies: 450
-- Name: VIEW view_demultiplex_service; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_demultiplex_service IS 'Libraries included in each multiplexed service with barcode. This view to be read for demultiplexing fastq files produced by these services.';


--
-- TOC entry 431 (class 1259 OID 53198)
-- Dependencies: 3221 7
-- Name: view_demux; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_demux AS
    SELECT libraries.library_id, fastqfiles.fastqfile, fastqfiles.service_id_deprecated AS service_id, barcodes.barcode_sequence, libraries.barcode_id, (((((barcodes.barcode_sequence || 'A '::text) || libraries.library_id) || '.'::text) || lower(fastqfiles.service_id_deprecated)) || '.fq'::text) AS demux_sheet, (((libraries.library_id || '.'::text) || lower(fastqfiles.service_id_deprecated)) || '.fq'::text) AS demultiplexed_file FROM (((libraries LEFT JOIN barcodes ON ((libraries.barcode_id = barcodes.barcode_id))) LEFT JOIN lib2seq ON ((libraries.library_id = lib2seq.library_id))) LEFT JOIN fastqfiles ON ((lib2seq.service_id = fastqfiles.service_id_deprecated))) ORDER BY libraries.library_id, fastqfiles.service_id_deprecated, libraries.barcode_id;


ALTER TABLE main.view_demux OWNER TO dberaldi;

--
-- TOC entry 3784 (class 0 OID 0)
-- Dependencies: 431
-- Name: VIEW view_demux; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_demux IS 'Link libraries to fastqfiles to have a draft for sample sheet to pass to demux. The demultiplexed file is composed by:
library_id.slx-id.fq
(memo demux usage: demux <sample sheet> <fastqfile not zipped>)';


--
-- TOC entry 452 (class 1259 OID 221390)
-- Dependencies: 3229 7
-- Name: view_demux_report; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_demux_report AS
    SELECT regexp_replace(demux_report.fastqfile_demux, '.*/'::text, ''::text) AS fastqfile_demux, regexp_replace(demux_report.fastqfile_master, '.*/'::text, ''::text) AS master_fastq, demux_report.nreads_master, (demux_report.nreads_master - demux_report.nreads_lost) AS nreads_assigned, round(((((demux_report.nreads_master)::numeric - (demux_report.nreads_lost)::numeric) / (demux_report.nreads_master)::numeric) * (100)::numeric), 2) AS percent_assigned, (demux_report.nreads_master - (demux_report.match_report[2][2])::integer) AS nreads_with_perfect_match, round(((((demux_report.nreads_master)::numeric - ((demux_report.match_report[2][2])::integer)::numeric) / (demux_report.nreads_master)::numeric) * (100)::numeric), 2) AS percent_with_perfect_match, demux_report.nreads_lost, demux_report.percent_lost, demux_report.match_report[1][2] AS nreads_with_n, demux_report.spurious_report[3][2] AS n_best_unspec_barcode, demux_report.barcode_id, demux_report.barcode_sequence, demux_report.nreads AS nreads_in_barcode, demux_report.percent_demux AS percent_in_barcode FROM demux_report ORDER BY regexp_replace(demux_report.fastqfile_master, '.*/'::text, ''::text), (demux_report.nreads_master - demux_report.nreads_lost);


ALTER TABLE main.view_demux_report OWNER TO dberaldi;

--
-- TOC entry 446 (class 1259 OID 210870)
-- Dependencies: 3226 7
-- Name: view_fastq_for_library_deprecated; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_fastq_for_library_deprecated AS
    SELECT libraries.library_id, CASE WHEN (fastqfiles.fastqfile IS NULL) THEN 'No fastq file found'::text ELSE fastqfiles.fastqfile END AS fastqfile, CASE WHEN (solexa_lims.service_id IS NULL) THEN 'No service_id found'::text ELSE solexa_lims.service_id END AS service_id, libraries.barcode_id, CASE WHEN (barcodes.barcode_id = 'not_multiplexed'::text) THEN fastqfiles.fastqfile ELSE (((libraries.library_id || '.'::text) || regexp_replace(fastqfiles.fastqfile, '_sequence\.sanger|_sequence|\.fq\.gz$|\.fastq\.gz$|\.txt\.gz$'::text, ''::text, 'g'::text)) || '.fq'::text) END AS demultiplexed_file, CASE WHEN (barcodes.barcode_id = 'not_multiplexed'::text) THEN ''::text ELSE (((((barcodes.barcode_sequence || 'A '::text) || libraries.library_id) || '.'::text) || regexp_replace(fastqfiles.fastqfile, '_sequence\.sanger|_sequence|\.fq\.gz|\.txt\.gz'::text, ''::text, 'g'::text)) || '.fq'::text) END AS demux_sheet FROM ((((libraries LEFT JOIN barcodes ON ((libraries.barcode_id = barcodes.barcode_id))) LEFT JOIN lib2seq ON ((libraries.library_id = lib2seq.library_id))) LEFT JOIN solexa_lims ON ((solexa_lims.service_id = lib2seq.service_id))) LEFT JOIN fastqfiles ON ((fastqfiles.service_id_deprecated = solexa_lims.service_id))) ORDER BY libraries.library_id, CASE WHEN (solexa_lims.service_id IS NULL) THEN 'No service_id found'::text ELSE solexa_lims.service_id END, libraries.barcode_id;


ALTER TABLE main.view_fastq_for_library_deprecated OWNER TO dberaldi;

--
-- TOC entry 3785 (class 0 OID 0)
-- Dependencies: 446
-- Name: VIEW view_fastq_for_library_deprecated; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_fastq_for_library_deprecated IS 'Link libraries to fastqfiles to have a draft for sample sheet to pass to demux. The demultiplexed file is composed by:
library_id.slx-id.fq
(memo demux usage: demux <sample sheet> <fastqfile not zipped>)';


--
-- TOC entry 460 (class 1259 OID 289253)
-- Dependencies: 3230 7
-- Name: view_library_service_fastq; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_library_service_fastq AS
    SELECT solexa_lims.service_id, libraries.library_id, solexa_lims.contact AS service_contact, fastqfiles.fastqfile FROM (((solexa_lims LEFT JOIN lib2seq ON ((solexa_lims.service_id = lib2seq.service_id))) LEFT JOIN libraries ON ((lib2seq.library_id = libraries.library_id))) LEFT JOIN fastqfiles ON ((libraries.library_id = fastqfiles.library_id))) ORDER BY CASE WHEN (fastqfiles.fastqfile IS NULL) THEN 0 ELSE 1 END, solexa_lims.service_id DESC, libraries.library_id, fastqfiles.fastqfile;


ALTER TABLE main.view_library_service_fastq OWNER TO dberaldi;

--
-- TOC entry 3786 (class 0 OID 0)
-- Dependencies: 460
-- Name: VIEW view_library_service_fastq; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_library_service_fastq IS 'Table of services associated to libraries and fastqfiles';


--
-- TOC entry 443 (class 1259 OID 192312)
-- Dependencies: 3225 7
-- Name: view_max_initials; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_max_initials AS
    SELECT regexp_replace(samples.sample_id, '\d.*'::text, ''::text) AS initials, contacts.contact_name, max((regexp_replace(regexp_replace(samples.sample_id, '^[A-Z0]*'::text, ''::text), '_.*'::text, ''::text))::integer) AS int_max FROM (samples JOIN contacts ON ((regexp_replace(samples.sample_id, '\d.*'::text, ''::text) = upper(contacts.initials)))) GROUP BY regexp_replace(samples.sample_id, '\d.*'::text, ''::text), contacts.contact_name ORDER BY regexp_replace(samples.sample_id, '\d.*'::text, ''::text);


ALTER TABLE main.view_max_initials OWNER TO dberaldi;

--
-- TOC entry 3787 (class 0 OID 0)
-- Dependencies: 443
-- Name: VIEW view_max_initials; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_max_initials IS 'Show for each initial/contact name the sample_id having the largest integer part. E.g. if DB has sample_ids [DB001, DB002, DB003] returns 3 for DB';


--
-- TOC entry 432 (class 1259 OID 63639)
-- Dependencies: 3222 7
-- Name: view_parse_sample_id; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_parse_sample_id AS
    SELECT contacts.contact_name, contacts.initials, samples.sample_id, regexp_replace(ltrim(regexp_replace(samples.sample_id, contacts.initials, ''::text), '0'::text), '_.*'::text, ''::text) AS rank_id, row_number() OVER (PARTITION BY contacts.initials ORDER BY samples.sample_id) AS rank FROM (contacts JOIN samples ON ((contacts.contact_name = samples.contact))) ORDER BY contacts.initials, samples.sample_id;


ALTER TABLE main.view_parse_sample_id OWNER TO dberaldi;

--
-- TOC entry 3788 (class 0 OID 0)
-- Dependencies: 432
-- Name: VIEW view_parse_sample_id; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_parse_sample_id IS 'Parse the sample_id to get the incremental number following the initials';


--
-- TOC entry 428 (class 1259 OID 47566)
-- Dependencies: 3220 7
-- Name: view_project_fastq; Type: VIEW; Schema: main; Owner: dberaldi
--

CREATE VIEW view_project_fastq AS
    SELECT DISTINCT projects.project, projects.start_date, samples.sample_id, libraries.library_id, fastqfiles.fastqfile, libraries.barcode_id, libraries.service_id_deprecated AS service_id FROM ((((projects JOIN project_samples ON ((projects.project = project_samples.project))) JOIN samples ON ((project_samples.sample_id = samples.sample_id))) JOIN libraries ON ((samples.sample_id = libraries.sample_id))) JOIN fastqfiles ON ((libraries.library_id = fastqfiles.library_id))) ORDER BY projects.project, samples.sample_id;


ALTER TABLE main.view_project_fastq OWNER TO dberaldi;

--
-- TOC entry 3789 (class 0 OID 0)
-- Dependencies: 428
-- Name: VIEW view_project_fastq; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON VIEW view_project_fastq IS 'Fastq files associated to each project';


--
-- TOC entry 448 (class 1259 OID 211948)
-- Dependencies: 7
-- Name: zzz_md5sum; Type: TABLE; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE TABLE zzz_md5sum (
    md5sum text,
    fastqfile text
);


ALTER TABLE main.zzz_md5sum OWNER TO dberaldi;

--
-- TOC entry 3790 (class 0 OID 0)
-- Dependencies: 448
-- Name: TABLE zzz_md5sum; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON TABLE zzz_md5sum IS 'Probably to be thrown away. Not sure what this table is for. Original name of this table was "md5sum"';


SET search_path = materialized_views, pg_catalog;

--
-- TOC entry 481 (class 1259 OID 1284741)
-- Dependencies: 40
-- Name: exp_design_20111206_chipseq_foxm1_debbies; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20111206_chipseq_foxm1_debbies (
    project text,
    sample_id text,
    cell_line text,
    chip_target text,
    dna_substrate_type text,
    drug text,
    foxm1_cat_id text,
    replicate text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20111206_chipseq_foxm1_debbies OWNER TO dberaldi;

--
-- TOC entry 3791 (class 0 OID 0)
-- Dependencies: 481
-- Name: TABLE exp_design_20111206_chipseq_foxm1_debbies; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20111206_chipseq_foxm1_debbies IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 482 (class 1259 OID 1284753)
-- Dependencies: 40 481
-- Name: exp_design_20111206_chipseq_foxm1_debbies_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20111206_chipseq_foxm1_debbies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20111206_chipseq_foxm1_debbies_id_seq OWNER TO dberaldi;

--
-- TOC entry 3792 (class 0 OID 0)
-- Dependencies: 482
-- Name: exp_design_20111206_chipseq_foxm1_debbies_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20111206_chipseq_foxm1_debbies_id_seq OWNED BY exp_design_20111206_chipseq_foxm1_debbies.id;


--
-- TOC entry 484 (class 1259 OID 1284773)
-- Dependencies: 40
-- Name: exp_design_20111206_chipseq_gquad_lame; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20111206_chipseq_gquad_lame (
    project text,
    sample_id text,
    cell_line text,
    cell_phase text,
    chip_target text,
    dna_substrate_type text,
    replicate text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20111206_chipseq_gquad_lame OWNER TO dberaldi;

--
-- TOC entry 3793 (class 0 OID 0)
-- Dependencies: 484
-- Name: TABLE exp_design_20111206_chipseq_gquad_lame; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20111206_chipseq_gquad_lame IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 485 (class 1259 OID 1284785)
-- Dependencies: 484 40
-- Name: exp_design_20111206_chipseq_gquad_lame_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20111206_chipseq_gquad_lame_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20111206_chipseq_gquad_lame_id_seq OWNER TO dberaldi;

--
-- TOC entry 3794 (class 0 OID 0)
-- Dependencies: 485
-- Name: exp_design_20111206_chipseq_gquad_lame_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20111206_chipseq_gquad_lame_id_seq OWNED BY exp_design_20111206_chipseq_gquad_lame.id;


--
-- TOC entry 493 (class 1259 OID 1284869)
-- Dependencies: 40
-- Name: exp_design_20111212_chipseq_formylseq_raiberea; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20111212_chipseq_formylseq_raiberea (
    project text,
    sample_id text,
    cell_line text,
    chip_target text,
    sirna text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20111212_chipseq_formylseq_raiberea OWNER TO dberaldi;

--
-- TOC entry 3795 (class 0 OID 0)
-- Dependencies: 493
-- Name: TABLE exp_design_20111212_chipseq_formylseq_raiberea; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20111212_chipseq_formylseq_raiberea IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 494 (class 1259 OID 1284881)
-- Dependencies: 40 493
-- Name: exp_design_20111212_chipseq_formylseq_raiberea_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20111212_chipseq_formylseq_raiberea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20111212_chipseq_formylseq_raiberea_id_seq OWNER TO dberaldi;

--
-- TOC entry 3796 (class 0 OID 0)
-- Dependencies: 494
-- Name: exp_design_20111212_chipseq_formylseq_raiberea_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20111212_chipseq_formylseq_raiberea_id_seq OWNED BY exp_design_20111212_chipseq_formylseq_raiberea.id;


--
-- TOC entry 511 (class 1259 OID 1285061)
-- Dependencies: 40
-- Name: exp_design_20120305_pif1; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20120305_pif1 (
    project text,
    sample_id text,
    cell_line text,
    chip_target text,
    treatment text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20120305_pif1 OWNER TO dberaldi;

--
-- TOC entry 3797 (class 0 OID 0)
-- Dependencies: 511
-- Name: TABLE exp_design_20120305_pif1; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20120305_pif1 IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 512 (class 1259 OID 1285073)
-- Dependencies: 40 511
-- Name: exp_design_20120305_pif1_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20120305_pif1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20120305_pif1_id_seq OWNER TO dberaldi;

--
-- TOC entry 3798 (class 0 OID 0)
-- Dependencies: 512
-- Name: exp_design_20120305_pif1_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20120305_pif1_id_seq OWNED BY exp_design_20120305_pif1.id;


--
-- TOC entry 490 (class 1259 OID 1284837)
-- Dependencies: 40
-- Name: exp_design_20120306_sanneh_gquad; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20120306_sanneh_gquad (
    project text,
    sample_id text,
    cell_line text,
    chip_target text,
    clonal_line text,
    dna_substrate_type text,
    tetr_gene text,
    tetr_induction text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20120306_sanneh_gquad OWNER TO dberaldi;

--
-- TOC entry 3799 (class 0 OID 0)
-- Dependencies: 490
-- Name: TABLE exp_design_20120306_sanneh_gquad; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20120306_sanneh_gquad IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 491 (class 1259 OID 1284849)
-- Dependencies: 40 490
-- Name: exp_design_20120306_sanneh_gquad_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20120306_sanneh_gquad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20120306_sanneh_gquad_id_seq OWNER TO dberaldi;

--
-- TOC entry 3800 (class 0 OID 0)
-- Dependencies: 491
-- Name: exp_design_20120306_sanneh_gquad_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20120306_sanneh_gquad_id_seq OWNED BY exp_design_20120306_sanneh_gquad.id;


--
-- TOC entry 472 (class 1259 OID 1284645)
-- Dependencies: 40
-- Name: exp_design_20120330_ramon_fixai; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20120330_ramon_fixai (
    project text,
    sample_id text,
    fixai_target text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20120330_ramon_fixai OWNER TO dberaldi;

--
-- TOC entry 3801 (class 0 OID 0)
-- Dependencies: 472
-- Name: TABLE exp_design_20120330_ramon_fixai; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20120330_ramon_fixai IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 473 (class 1259 OID 1284657)
-- Dependencies: 40 472
-- Name: exp_design_20120330_ramon_fixai_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20120330_ramon_fixai_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20120330_ramon_fixai_id_seq OWNER TO dberaldi;

--
-- TOC entry 3802 (class 0 OID 0)
-- Dependencies: 473
-- Name: exp_design_20120330_ramon_fixai_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20120330_ramon_fixai_id_seq OWNED BY exp_design_20120330_ramon_fixai.id;


--
-- TOC entry 499 (class 1259 OID 1284933)
-- Dependencies: 40
-- Name: exp_design_20120516_pierre_ribosome_profiling; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20120516_pierre_ribosome_profiling (
    project text,
    sample_id text,
    cell_line text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20120516_pierre_ribosome_profiling OWNER TO dberaldi;

--
-- TOC entry 3803 (class 0 OID 0)
-- Dependencies: 499
-- Name: TABLE exp_design_20120516_pierre_ribosome_profiling; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20120516_pierre_ribosome_profiling IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 500 (class 1259 OID 1284945)
-- Dependencies: 499 40
-- Name: exp_design_20120516_pierre_ribosome_profiling_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20120516_pierre_ribosome_profiling_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20120516_pierre_ribosome_profiling_id_seq OWNER TO dberaldi;

--
-- TOC entry 3804 (class 0 OID 0)
-- Dependencies: 500
-- Name: exp_design_20120516_pierre_ribosome_profiling_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20120516_pierre_ribosome_profiling_id_seq OWNED BY exp_design_20120516_pierre_ribosome_profiling.id;


--
-- TOC entry 475 (class 1259 OID 1284677)
-- Dependencies: 40
-- Name: exp_design_20120522_oxbsseq_mesc; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20120522_oxbsseq_mesc (
    project text,
    sample_id text,
    bisulfite_reaction text,
    cell_line text,
    dna_substrate_type text,
    n_pcr_cycles text,
    replicate text,
    synthetic_strand_percent text,
    synthetic_strands text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20120522_oxbsseq_mesc OWNER TO dberaldi;

--
-- TOC entry 3805 (class 0 OID 0)
-- Dependencies: 475
-- Name: TABLE exp_design_20120522_oxbsseq_mesc; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20120522_oxbsseq_mesc IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 476 (class 1259 OID 1284689)
-- Dependencies: 475 40
-- Name: exp_design_20120522_oxbsseq_mesc_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20120522_oxbsseq_mesc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20120522_oxbsseq_mesc_id_seq OWNER TO dberaldi;

--
-- TOC entry 3806 (class 0 OID 0)
-- Dependencies: 476
-- Name: exp_design_20120522_oxbsseq_mesc_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20120522_oxbsseq_mesc_id_seq OWNED BY exp_design_20120522_oxbsseq_mesc.id;


--
-- TOC entry 469 (class 1259 OID 1284613)
-- Dependencies: 40
-- Name: exp_design_20120622_rnaseq_pdsa; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20120622_rnaseq_pdsa (
    project text,
    sample_id text,
    cell_line text,
    chip_target text,
    "pyridostatin_uM" text,
    replicate text,
    treatment text,
    treatment_time text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20120622_rnaseq_pdsa OWNER TO dberaldi;

--
-- TOC entry 3807 (class 0 OID 0)
-- Dependencies: 469
-- Name: TABLE exp_design_20120622_rnaseq_pdsa; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20120622_rnaseq_pdsa IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 470 (class 1259 OID 1284625)
-- Dependencies: 40 469
-- Name: exp_design_20120622_rnaseq_pdsa_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20120622_rnaseq_pdsa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20120622_rnaseq_pdsa_id_seq OWNER TO dberaldi;

--
-- TOC entry 3808 (class 0 OID 0)
-- Dependencies: 470
-- Name: exp_design_20120622_rnaseq_pdsa_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20120622_rnaseq_pdsa_id_seq OWNED BY exp_design_20120622_rnaseq_pdsa.id;


--
-- TOC entry 478 (class 1259 OID 1284709)
-- Dependencies: 40
-- Name: exp_design_20120925_mdip_hematop_sc; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20120925_mdip_hematop_sc (
    project text,
    sample_id text,
    chip_target text,
    mnase_time text,
    replicate text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20120925_mdip_hematop_sc OWNER TO dberaldi;

--
-- TOC entry 3809 (class 0 OID 0)
-- Dependencies: 478
-- Name: TABLE exp_design_20120925_mdip_hematop_sc; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20120925_mdip_hematop_sc IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 479 (class 1259 OID 1284721)
-- Dependencies: 40 478
-- Name: exp_design_20120925_mdip_hematop_sc_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20120925_mdip_hematop_sc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20120925_mdip_hematop_sc_id_seq OWNER TO dberaldi;

--
-- TOC entry 3810 (class 0 OID 0)
-- Dependencies: 479
-- Name: exp_design_20120925_mdip_hematop_sc_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20120925_mdip_hematop_sc_id_seq OWNED BY exp_design_20120925_mdip_hematop_sc.id;


--
-- TOC entry 502 (class 1259 OID 1284965)
-- Dependencies: 40
-- Name: exp_design_20121015_hmc_lambda; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20121015_hmc_lambda (
    project text,
    sample_id text,
    replicate text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20121015_hmc_lambda OWNER TO dberaldi;

--
-- TOC entry 3811 (class 0 OID 0)
-- Dependencies: 502
-- Name: TABLE exp_design_20121015_hmc_lambda; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20121015_hmc_lambda IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 503 (class 1259 OID 1284977)
-- Dependencies: 502 40
-- Name: exp_design_20121015_hmc_lambda_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20121015_hmc_lambda_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20121015_hmc_lambda_id_seq OWNER TO dberaldi;

--
-- TOC entry 3812 (class 0 OID 0)
-- Dependencies: 503
-- Name: exp_design_20121015_hmc_lambda_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20121015_hmc_lambda_id_seq OWNED BY exp_design_20121015_hmc_lambda.id;


--
-- TOC entry 514 (class 1259 OID 1285093)
-- Dependencies: 40
-- Name: exp_design_20121122_oxbseq_kit_toby; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20121122_oxbseq_kit_toby (
    project text,
    sample_id text,
    hpa_ilmn_ratio text,
    synthetic_strand_percent text,
    synthetic_strands text,
    trialist text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20121122_oxbseq_kit_toby OWNER TO dberaldi;

--
-- TOC entry 3813 (class 0 OID 0)
-- Dependencies: 514
-- Name: TABLE exp_design_20121122_oxbseq_kit_toby; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20121122_oxbseq_kit_toby IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 515 (class 1259 OID 1285105)
-- Dependencies: 40 514
-- Name: exp_design_20121122_oxbseq_kit_toby_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20121122_oxbseq_kit_toby_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20121122_oxbseq_kit_toby_id_seq OWNER TO dberaldi;

--
-- TOC entry 3814 (class 0 OID 0)
-- Dependencies: 515
-- Name: exp_design_20121122_oxbseq_kit_toby_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20121122_oxbseq_kit_toby_id_seq OWNED BY exp_design_20121122_oxbseq_kit_toby.id;


--
-- TOC entry 505 (class 1259 OID 1284997)
-- Dependencies: 40
-- Name: exp_design_20121408_mikeb_oxbs_mtdna; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20121408_mikeb_oxbs_mtdna (
    project text,
    sample_id text,
    cell_line text,
    replicate text,
    synthetic_strands text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20121408_mikeb_oxbs_mtdna OWNER TO dberaldi;

--
-- TOC entry 3815 (class 0 OID 0)
-- Dependencies: 505
-- Name: TABLE exp_design_20121408_mikeb_oxbs_mtdna; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20121408_mikeb_oxbs_mtdna IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 506 (class 1259 OID 1285009)
-- Dependencies: 40 505
-- Name: exp_design_20121408_mikeb_oxbs_mtdna_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20121408_mikeb_oxbs_mtdna_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20121408_mikeb_oxbs_mtdna_id_seq OWNER TO dberaldi;

--
-- TOC entry 3816 (class 0 OID 0)
-- Dependencies: 506
-- Name: exp_design_20121408_mikeb_oxbs_mtdna_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20121408_mikeb_oxbs_mtdna_id_seq OWNED BY exp_design_20121408_mikeb_oxbs_mtdna.id;


--
-- TOC entry 547 (class 1259 OID 1285445)
-- Dependencies: 40
-- Name: exp_design_20130214_oxbs_vs_tab; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130214_oxbs_vs_tab (
    project text,
    sample_id text,
    synthetic_strand_percent text,
    synthetic_strands text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130214_oxbs_vs_tab OWNER TO dberaldi;

--
-- TOC entry 3817 (class 0 OID 0)
-- Dependencies: 547
-- Name: TABLE exp_design_20130214_oxbs_vs_tab; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130214_oxbs_vs_tab IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 548 (class 1259 OID 1285457)
-- Dependencies: 547 40
-- Name: exp_design_20130214_oxbs_vs_tab_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130214_oxbs_vs_tab_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130214_oxbs_vs_tab_id_seq OWNER TO dberaldi;

--
-- TOC entry 3818 (class 0 OID 0)
-- Dependencies: 548
-- Name: exp_design_20130214_oxbs_vs_tab_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130214_oxbs_vs_tab_id_seq OWNED BY exp_design_20130214_oxbs_vs_tab.id;


--
-- TOC entry 517 (class 1259 OID 1285125)
-- Dependencies: 40
-- Name: exp_design_20130312_oxbs_optimization_nmb; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130312_oxbs_optimization_nmb (
    project text,
    sample_id text,
    bisulfite_molar_conc text,
    synthetic_strand_percent text,
    synthetic_strands text,
    treatment_time text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130312_oxbs_optimization_nmb OWNER TO dberaldi;

--
-- TOC entry 3819 (class 0 OID 0)
-- Dependencies: 517
-- Name: TABLE exp_design_20130312_oxbs_optimization_nmb; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130312_oxbs_optimization_nmb IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 518 (class 1259 OID 1285137)
-- Dependencies: 517 40
-- Name: exp_design_20130312_oxbs_optimization_nmb_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130312_oxbs_optimization_nmb_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130312_oxbs_optimization_nmb_id_seq OWNER TO dberaldi;

--
-- TOC entry 3820 (class 0 OID 0)
-- Dependencies: 518
-- Name: exp_design_20130312_oxbs_optimization_nmb_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130312_oxbs_optimization_nmb_id_seq OWNED BY exp_design_20130312_oxbs_optimization_nmb.id;


--
-- TOC entry 523 (class 1259 OID 1285189)
-- Dependencies: 40
-- Name: exp_design_20130409_reduced_bsseq; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130409_reduced_bsseq (
    project text,
    sample_id text,
    cell_line text,
    rrbs_enzyme text,
    sirna text,
    strain text,
    synthetic_strands text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130409_reduced_bsseq OWNER TO dberaldi;

--
-- TOC entry 3821 (class 0 OID 0)
-- Dependencies: 523
-- Name: TABLE exp_design_20130409_reduced_bsseq; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130409_reduced_bsseq IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 524 (class 1259 OID 1285201)
-- Dependencies: 40 523
-- Name: exp_design_20130409_reduced_bsseq_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130409_reduced_bsseq_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130409_reduced_bsseq_id_seq OWNER TO dberaldi;

--
-- TOC entry 3822 (class 0 OID 0)
-- Dependencies: 524
-- Name: exp_design_20130409_reduced_bsseq_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130409_reduced_bsseq_id_seq OWNED BY exp_design_20130409_reduced_bsseq.id;


--
-- TOC entry 508 (class 1259 OID 1285029)
-- Dependencies: 40
-- Name: exp_design_20130424_rnaseq_mikeg; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130424_rnaseq_mikeg (
    project text,
    sample_id text,
    cell_line text,
    treatment_time text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130424_rnaseq_mikeg OWNER TO dberaldi;

--
-- TOC entry 3823 (class 0 OID 0)
-- Dependencies: 508
-- Name: TABLE exp_design_20130424_rnaseq_mikeg; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130424_rnaseq_mikeg IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 509 (class 1259 OID 1285041)
-- Dependencies: 40 508
-- Name: exp_design_20130424_rnaseq_mikeg_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130424_rnaseq_mikeg_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130424_rnaseq_mikeg_id_seq OWNER TO dberaldi;

--
-- TOC entry 3824 (class 0 OID 0)
-- Dependencies: 509
-- Name: exp_design_20130424_rnaseq_mikeg_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130424_rnaseq_mikeg_id_seq OWNED BY exp_design_20130424_rnaseq_mikeg.id;


--
-- TOC entry 526 (class 1259 OID 1285221)
-- Dependencies: 40
-- Name: exp_design_20130507_rnaseq_rhau_mchen; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130507_rnaseq_rhau_mchen (
    project text,
    sample_id text,
    cell_line text,
    sirna text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130507_rnaseq_rhau_mchen OWNER TO dberaldi;

--
-- TOC entry 3825 (class 0 OID 0)
-- Dependencies: 526
-- Name: TABLE exp_design_20130507_rnaseq_rhau_mchen; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130507_rnaseq_rhau_mchen IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 527 (class 1259 OID 1285233)
-- Dependencies: 526 40
-- Name: exp_design_20130507_rnaseq_rhau_mchen_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130507_rnaseq_rhau_mchen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130507_rnaseq_rhau_mchen_id_seq OWNER TO dberaldi;

--
-- TOC entry 3826 (class 0 OID 0)
-- Dependencies: 527
-- Name: exp_design_20130507_rnaseq_rhau_mchen_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130507_rnaseq_rhau_mchen_id_seq OWNED BY exp_design_20130507_rnaseq_rhau_mchen.id;


--
-- TOC entry 541 (class 1259 OID 1285381)
-- Dependencies: 40
-- Name: exp_design_20130520_chipseq_olivia; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130520_chipseq_olivia (
    project text,
    sample_id text,
    amino_acid text,
    cell_line text,
    chip_target text,
    harvest_time text,
    hydroxygluterate_feeding text,
    idh2_mutant text,
    light text,
    photocaged text,
    transient_transfection text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130520_chipseq_olivia OWNER TO dberaldi;

--
-- TOC entry 3827 (class 0 OID 0)
-- Dependencies: 541
-- Name: TABLE exp_design_20130520_chipseq_olivia; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130520_chipseq_olivia IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 542 (class 1259 OID 1285393)
-- Dependencies: 40 541
-- Name: exp_design_20130520_chipseq_olivia_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130520_chipseq_olivia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130520_chipseq_olivia_id_seq OWNER TO dberaldi;

--
-- TOC entry 3828 (class 0 OID 0)
-- Dependencies: 542
-- Name: exp_design_20130520_chipseq_olivia_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130520_chipseq_olivia_id_seq OWNED BY exp_design_20130520_chipseq_olivia.id;


--
-- TOC entry 553 (class 1259 OID 1285509)
-- Dependencies: 40
-- Name: exp_design_20130610_5fc_linker_gordon; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130610_5fc_linker_gordon (
    project text,
    sample_id text,
    chip_target text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130610_5fc_linker_gordon OWNER TO dberaldi;

--
-- TOC entry 3829 (class 0 OID 0)
-- Dependencies: 553
-- Name: TABLE exp_design_20130610_5fc_linker_gordon; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130610_5fc_linker_gordon IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 554 (class 1259 OID 1285521)
-- Dependencies: 553 40
-- Name: exp_design_20130610_5fc_linker_gordon_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130610_5fc_linker_gordon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130610_5fc_linker_gordon_id_seq OWNER TO dberaldi;

--
-- TOC entry 3830 (class 0 OID 0)
-- Dependencies: 554
-- Name: exp_design_20130610_5fc_linker_gordon_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130610_5fc_linker_gordon_id_seq OWNED BY exp_design_20130610_5fc_linker_gordon.id;


--
-- TOC entry 556 (class 1259 OID 1285541)
-- Dependencies: 40
-- Name: exp_design_20130705_oxbs_rna; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130705_oxbs_rna (
    project text,
    sample_id text,
    bisulfite_reaction text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130705_oxbs_rna OWNER TO dberaldi;

--
-- TOC entry 3831 (class 0 OID 0)
-- Dependencies: 556
-- Name: TABLE exp_design_20130705_oxbs_rna; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130705_oxbs_rna IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 557 (class 1259 OID 1285553)
-- Dependencies: 556 40
-- Name: exp_design_20130705_oxbs_rna_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130705_oxbs_rna_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130705_oxbs_rna_id_seq OWNER TO dberaldi;

--
-- TOC entry 3832 (class 0 OID 0)
-- Dependencies: 557
-- Name: exp_design_20130705_oxbs_rna_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130705_oxbs_rna_id_seq OWNED BY exp_design_20130705_oxbs_rna.id;


--
-- TOC entry 535 (class 1259 OID 1285317)
-- Dependencies: 40
-- Name: exp_design_20130722_oxbseq_450k_sally; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130722_oxbseq_450k_sally (
    project text,
    sample_id text,
    rrbs_enzyme text,
    tumor_condition text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130722_oxbseq_450k_sally OWNER TO dberaldi;

--
-- TOC entry 3833 (class 0 OID 0)
-- Dependencies: 535
-- Name: TABLE exp_design_20130722_oxbseq_450k_sally; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130722_oxbseq_450k_sally IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 536 (class 1259 OID 1285329)
-- Dependencies: 40 535
-- Name: exp_design_20130722_oxbseq_450k_sally_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130722_oxbseq_450k_sally_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130722_oxbseq_450k_sally_id_seq OWNER TO dberaldi;

--
-- TOC entry 3834 (class 0 OID 0)
-- Dependencies: 536
-- Name: exp_design_20130722_oxbseq_450k_sally_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130722_oxbseq_450k_sally_id_seq OWNED BY exp_design_20130722_oxbseq_450k_sally.id;


--
-- TOC entry 544 (class 1259 OID 1285413)
-- Dependencies: 40
-- Name: exp_design_20130906_faire_seq_robert; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130906_faire_seq_robert (
    project text,
    sample_id text,
    amount text,
    cell_line text,
    chip_target text,
    "gamma_Gy" text,
    is_faire_input text,
    pull_repl text,
    "pyridostatin_uM" text,
    replicate text,
    treatment text,
    treatment_conc text,
    treatment_time text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130906_faire_seq_robert OWNER TO dberaldi;

--
-- TOC entry 3835 (class 0 OID 0)
-- Dependencies: 544
-- Name: TABLE exp_design_20130906_faire_seq_robert; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130906_faire_seq_robert IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 545 (class 1259 OID 1285425)
-- Dependencies: 40 544
-- Name: exp_design_20130906_faire_seq_robert_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130906_faire_seq_robert_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130906_faire_seq_robert_id_seq OWNER TO dberaldi;

--
-- TOC entry 3836 (class 0 OID 0)
-- Dependencies: 545
-- Name: exp_design_20130906_faire_seq_robert_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130906_faire_seq_robert_id_seq OWNED BY exp_design_20130906_faire_seq_robert.id;


--
-- TOC entry 529 (class 1259 OID 1285253)
-- Dependencies: 40
-- Name: exp_design_20130906_foxm1_gfp; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130906_foxm1_gfp (
    project text,
    sample_id text,
    chip_target text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130906_foxm1_gfp OWNER TO dberaldi;

--
-- TOC entry 3837 (class 0 OID 0)
-- Dependencies: 529
-- Name: TABLE exp_design_20130906_foxm1_gfp; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130906_foxm1_gfp IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 530 (class 1259 OID 1285265)
-- Dependencies: 40 529
-- Name: exp_design_20130906_foxm1_gfp_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130906_foxm1_gfp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130906_foxm1_gfp_id_seq OWNER TO dberaldi;

--
-- TOC entry 3838 (class 0 OID 0)
-- Dependencies: 530
-- Name: exp_design_20130906_foxm1_gfp_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130906_foxm1_gfp_id_seq OWNED BY exp_design_20130906_foxm1_gfp.id;


--
-- TOC entry 496 (class 1259 OID 1284901)
-- Dependencies: 40
-- Name: exp_design_20130916_sureselect_euni; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20130916_sureselect_euni (
    project text,
    sample_id text,
    cell_line text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20130916_sureselect_euni OWNER TO dberaldi;

--
-- TOC entry 3839 (class 0 OID 0)
-- Dependencies: 496
-- Name: TABLE exp_design_20130916_sureselect_euni; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20130916_sureselect_euni IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 497 (class 1259 OID 1284913)
-- Dependencies: 40 496
-- Name: exp_design_20130916_sureselect_euni_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20130916_sureselect_euni_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20130916_sureselect_euni_id_seq OWNER TO dberaldi;

--
-- TOC entry 3840 (class 0 OID 0)
-- Dependencies: 497
-- Name: exp_design_20130916_sureselect_euni_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20130916_sureselect_euni_id_seq OWNED BY exp_design_20130916_sureselect_euni.id;


--
-- TOC entry 520 (class 1259 OID 1285157)
-- Dependencies: 40
-- Name: exp_design_20140818_fumi_hmu_pull_down; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20140818_fumi_hmu_pull_down (
    project text,
    sample_id text,
    chip_target text,
    host text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20140818_fumi_hmu_pull_down OWNER TO dberaldi;

--
-- TOC entry 3841 (class 0 OID 0)
-- Dependencies: 520
-- Name: TABLE exp_design_20140818_fumi_hmu_pull_down; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20140818_fumi_hmu_pull_down IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 521 (class 1259 OID 1285169)
-- Dependencies: 520 40
-- Name: exp_design_20140818_fumi_hmu_pull_down_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20140818_fumi_hmu_pull_down_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20140818_fumi_hmu_pull_down_id_seq OWNER TO dberaldi;

--
-- TOC entry 3842 (class 0 OID 0)
-- Dependencies: 521
-- Name: exp_design_20140818_fumi_hmu_pull_down_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20140818_fumi_hmu_pull_down_id_seq OWNED BY exp_design_20140818_fumi_hmu_pull_down.id;


--
-- TOC entry 559 (class 1259 OID 1285573)
-- Dependencies: 40
-- Name: exp_design_20141215_robyn_modified_u; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20141215_robyn_modified_u (
    project text,
    sample_id text,
    chip_target text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20141215_robyn_modified_u OWNER TO dberaldi;

--
-- TOC entry 3843 (class 0 OID 0)
-- Dependencies: 559
-- Name: TABLE exp_design_20141215_robyn_modified_u; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20141215_robyn_modified_u IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 560 (class 1259 OID 1285585)
-- Dependencies: 40 559
-- Name: exp_design_20141215_robyn_modified_u_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20141215_robyn_modified_u_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20141215_robyn_modified_u_id_seq OWNER TO dberaldi;

--
-- TOC entry 3844 (class 0 OID 0)
-- Dependencies: 560
-- Name: exp_design_20141215_robyn_modified_u_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20141215_robyn_modified_u_id_seq OWNED BY exp_design_20141215_robyn_modified_u.id;


--
-- TOC entry 487 (class 1259 OID 1284805)
-- Dependencies: 40
-- Name: exp_design_20150309_gordon_redBS_mESC; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE "exp_design_20150309_gordon_redBS_mESC" (
    project text,
    sample_id text,
    animal_id text,
    chip_target text,
    embryo_day text,
    genotype text,
    knock_out text,
    litter text,
    id integer NOT NULL
);


ALTER TABLE materialized_views."exp_design_20150309_gordon_redBS_mESC" OWNER TO dberaldi;

--
-- TOC entry 3845 (class 0 OID 0)
-- Dependencies: 487
-- Name: TABLE "exp_design_20150309_gordon_redBS_mESC"; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE "exp_design_20150309_gordon_redBS_mESC" IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 488 (class 1259 OID 1284817)
-- Dependencies: 40 487
-- Name: exp_design_20150309_gordon_redBS_mESC_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE "exp_design_20150309_gordon_redBS_mESC_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views."exp_design_20150309_gordon_redBS_mESC_id_seq" OWNER TO dberaldi;

--
-- TOC entry 3846 (class 0 OID 0)
-- Dependencies: 488
-- Name: exp_design_20150309_gordon_redBS_mESC_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE "exp_design_20150309_gordon_redBS_mESC_id_seq" OWNED BY "exp_design_20150309_gordon_redBS_mESC".id;


--
-- TOC entry 538 (class 1259 OID 1285349)
-- Dependencies: 40
-- Name: exp_design_20150320_Robert_senescent_chromatin; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE "exp_design_20150320_Robert_senescent_chromatin" (
    project text,
    sample_id text,
    cell_line text,
    overexpression text,
    "shRNA" text,
    id integer NOT NULL
);


ALTER TABLE materialized_views."exp_design_20150320_Robert_senescent_chromatin" OWNER TO dberaldi;

--
-- TOC entry 3847 (class 0 OID 0)
-- Dependencies: 538
-- Name: TABLE "exp_design_20150320_Robert_senescent_chromatin"; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE "exp_design_20150320_Robert_senescent_chromatin" IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 539 (class 1259 OID 1285361)
-- Dependencies: 40 538
-- Name: exp_design_20150320_Robert_senescent_chromatin_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE "exp_design_20150320_Robert_senescent_chromatin_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views."exp_design_20150320_Robert_senescent_chromatin_id_seq" OWNER TO dberaldi;

--
-- TOC entry 3848 (class 0 OID 0)
-- Dependencies: 539
-- Name: exp_design_20150320_Robert_senescent_chromatin_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE "exp_design_20150320_Robert_senescent_chromatin_id_seq" OWNED BY "exp_design_20150320_Robert_senescent_chromatin".id;


--
-- TOC entry 550 (class 1259 OID 1285477)
-- Dependencies: 40
-- Name: exp_design_20150805_bless_stefanie; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20150805_bless_stefanie (
    project text,
    sample_id text,
    cell_line text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20150805_bless_stefanie OWNER TO dberaldi;

--
-- TOC entry 3849 (class 0 OID 0)
-- Dependencies: 550
-- Name: TABLE exp_design_20150805_bless_stefanie; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20150805_bless_stefanie IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 551 (class 1259 OID 1285489)
-- Dependencies: 550 40
-- Name: exp_design_20150805_bless_stefanie_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20150805_bless_stefanie_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20150805_bless_stefanie_id_seq OWNER TO dberaldi;

--
-- TOC entry 3850 (class 0 OID 0)
-- Dependencies: 551
-- Name: exp_design_20150805_bless_stefanie_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20150805_bless_stefanie_id_seq OWNED BY exp_design_20150805_bless_stefanie.id;


--
-- TOC entry 532 (class 1259 OID 1285285)
-- Dependencies: 40
-- Name: exp_design_20150821_tobi_cisplatin; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_20150821_tobi_cisplatin (
    project text,
    sample_id text,
    chip_target text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_20150821_tobi_cisplatin OWNER TO dberaldi;

--
-- TOC entry 3851 (class 0 OID 0)
-- Dependencies: 532
-- Name: TABLE exp_design_20150821_tobi_cisplatin; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_20150821_tobi_cisplatin IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 533 (class 1259 OID 1285297)
-- Dependencies: 532 40
-- Name: exp_design_20150821_tobi_cisplatin_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_20150821_tobi_cisplatin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_20150821_tobi_cisplatin_id_seq OWNER TO dberaldi;

--
-- TOC entry 3852 (class 0 OID 0)
-- Dependencies: 533
-- Name: exp_design_20150821_tobi_cisplatin_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_20150821_tobi_cisplatin_id_seq OWNED BY exp_design_20150821_tobi_cisplatin.id;


--
-- TOC entry 562 (class 1259 OID 1285637)
-- Dependencies: 40
-- Name: exp_design_samples; Type: TABLE; Schema: materialized_views; Owner: dberaldi; Tablespace: 
--

CREATE TABLE exp_design_samples (
    sample_id text,
    amino_acid text,
    amount text,
    animal_id text,
    bisulfite_molar_conc text,
    bisulfite_reaction text,
    cell_line text,
    cell_phase text,
    chip_target text,
    clonal_line text,
    dna_substrate_type text,
    drug text,
    embryo_day text,
    fixai_target text,
    foxm1_cat_id text,
    "gamma_Gy" text,
    genotype text,
    harvest_time text,
    host text,
    hpa_ilmn_ratio text,
    hydroxygluterate_feeding text,
    idh2_mutant text,
    is_faire_input text,
    knock_out text,
    light text,
    litter text,
    mnase_time text,
    modification text,
    n_pcr_cycles text,
    overexpression text,
    photocaged text,
    polymerase text,
    pull_repl text,
    "pyridostatin_uM" text,
    replicate text,
    rrbs_enzyme text,
    "shRNA" text,
    sirna text,
    stage text,
    strain text,
    synthetic_strand_percent text,
    synthetic_strands text,
    tetr_gene text,
    tetr_induction text,
    transient_transfection text,
    treatment text,
    treatment_conc text,
    treatment_time text,
    trialist text,
    tumor_condition text,
    id integer NOT NULL
);


ALTER TABLE materialized_views.exp_design_samples OWNER TO dberaldi;

--
-- TOC entry 3853 (class 0 OID 0)
-- Dependencies: 562
-- Name: TABLE exp_design_samples; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON TABLE exp_design_samples IS ' Crosstab table generated by cross_tab() from input query:  
        select distinct
            exp_design.sample_id,
            exp_design.s_variable, -- For cross_tab: This must be second last column
            exp_design.s_value     -- For cross_tab: This must be last column
        from exp_design 
        left join project_samples on exp_design.sample_id = project_samples.sample_id
        inner join samples on exp_design.sample_id = samples.sample_id
        left join libraries on samples.sample_id = libraries.sample_id ';


--
-- TOC entry 563 (class 1259 OID 1285649)
-- Dependencies: 562 40
-- Name: exp_design_samples_id_seq; Type: SEQUENCE; Schema: materialized_views; Owner: dberaldi
--

CREATE SEQUENCE exp_design_samples_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE materialized_views.exp_design_samples_id_seq OWNER TO dberaldi;

--
-- TOC entry 3854 (class 0 OID 0)
-- Dependencies: 563
-- Name: exp_design_samples_id_seq; Type: SEQUENCE OWNED BY; Schema: materialized_views; Owner: dberaldi
--

ALTER SEQUENCE exp_design_samples_id_seq OWNED BY exp_design_samples.id;


--
-- TOC entry 483 (class 1259 OID 1284762)
-- Dependencies: 3235 40
-- Name: view_20111206_chipseq_foxm1_debbies; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20111206_chipseq_foxm1_debbies AS
    SELECT DISTINCT exp_design_20111206_chipseq_foxm1_debbies.project, exp_design_20111206_chipseq_foxm1_debbies.sample_id, exp_design_20111206_chipseq_foxm1_debbies.cell_line, exp_design_20111206_chipseq_foxm1_debbies.chip_target, exp_design_20111206_chipseq_foxm1_debbies.dna_substrate_type, exp_design_20111206_chipseq_foxm1_debbies.drug, exp_design_20111206_chipseq_foxm1_debbies.foxm1_cat_id, exp_design_20111206_chipseq_foxm1_debbies.replicate, exp_design_20111206_chipseq_foxm1_debbies.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20111206_chipseq_foxm1_debbies JOIN main.samples ON ((samples.sample_id = exp_design_20111206_chipseq_foxm1_debbies.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20111206_chipseq_foxm1_debbies OWNER TO dberaldi;

--
-- TOC entry 3855 (class 0 OID 0)
-- Dependencies: 483
-- Name: VIEW view_20111206_chipseq_foxm1_debbies; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20111206_chipseq_foxm1_debbies IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 486 (class 1259 OID 1284794)
-- Dependencies: 3236 40
-- Name: view_20111206_chipseq_gquad_lame; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20111206_chipseq_gquad_lame AS
    SELECT DISTINCT exp_design_20111206_chipseq_gquad_lame.project, exp_design_20111206_chipseq_gquad_lame.sample_id, exp_design_20111206_chipseq_gquad_lame.cell_line, exp_design_20111206_chipseq_gquad_lame.cell_phase, exp_design_20111206_chipseq_gquad_lame.chip_target, exp_design_20111206_chipseq_gquad_lame.dna_substrate_type, exp_design_20111206_chipseq_gquad_lame.replicate, exp_design_20111206_chipseq_gquad_lame.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20111206_chipseq_gquad_lame JOIN main.samples ON ((samples.sample_id = exp_design_20111206_chipseq_gquad_lame.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20111206_chipseq_gquad_lame OWNER TO dberaldi;

--
-- TOC entry 3856 (class 0 OID 0)
-- Dependencies: 486
-- Name: VIEW view_20111206_chipseq_gquad_lame; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20111206_chipseq_gquad_lame IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 495 (class 1259 OID 1284890)
-- Dependencies: 3239 40
-- Name: view_20111212_chipseq_formylseq_raiberea; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20111212_chipseq_formylseq_raiberea AS
    SELECT DISTINCT exp_design_20111212_chipseq_formylseq_raiberea.project, exp_design_20111212_chipseq_formylseq_raiberea.sample_id, exp_design_20111212_chipseq_formylseq_raiberea.cell_line, exp_design_20111212_chipseq_formylseq_raiberea.chip_target, exp_design_20111212_chipseq_formylseq_raiberea.sirna, exp_design_20111212_chipseq_formylseq_raiberea.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20111212_chipseq_formylseq_raiberea JOIN main.samples ON ((samples.sample_id = exp_design_20111212_chipseq_formylseq_raiberea.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20111212_chipseq_formylseq_raiberea OWNER TO dberaldi;

--
-- TOC entry 3857 (class 0 OID 0)
-- Dependencies: 495
-- Name: VIEW view_20111212_chipseq_formylseq_raiberea; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20111212_chipseq_formylseq_raiberea IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 513 (class 1259 OID 1285082)
-- Dependencies: 3245 40
-- Name: view_20120305_pif1; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20120305_pif1 AS
    SELECT DISTINCT exp_design_20120305_pif1.project, exp_design_20120305_pif1.sample_id, exp_design_20120305_pif1.cell_line, exp_design_20120305_pif1.chip_target, exp_design_20120305_pif1.treatment, exp_design_20120305_pif1.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20120305_pif1 JOIN main.samples ON ((samples.sample_id = exp_design_20120305_pif1.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20120305_pif1 OWNER TO dberaldi;

--
-- TOC entry 3858 (class 0 OID 0)
-- Dependencies: 513
-- Name: VIEW view_20120305_pif1; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20120305_pif1 IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 492 (class 1259 OID 1284858)
-- Dependencies: 3238 40
-- Name: view_20120306_sanneh_gquad; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20120306_sanneh_gquad AS
    SELECT DISTINCT exp_design_20120306_sanneh_gquad.project, exp_design_20120306_sanneh_gquad.sample_id, exp_design_20120306_sanneh_gquad.cell_line, exp_design_20120306_sanneh_gquad.chip_target, exp_design_20120306_sanneh_gquad.clonal_line, exp_design_20120306_sanneh_gquad.dna_substrate_type, exp_design_20120306_sanneh_gquad.tetr_gene, exp_design_20120306_sanneh_gquad.tetr_induction, exp_design_20120306_sanneh_gquad.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20120306_sanneh_gquad JOIN main.samples ON ((samples.sample_id = exp_design_20120306_sanneh_gquad.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20120306_sanneh_gquad OWNER TO dberaldi;

--
-- TOC entry 3859 (class 0 OID 0)
-- Dependencies: 492
-- Name: VIEW view_20120306_sanneh_gquad; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20120306_sanneh_gquad IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 474 (class 1259 OID 1284666)
-- Dependencies: 3232 40
-- Name: view_20120330_ramon_fixai; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20120330_ramon_fixai AS
    SELECT DISTINCT exp_design_20120330_ramon_fixai.project, exp_design_20120330_ramon_fixai.sample_id, exp_design_20120330_ramon_fixai.fixai_target, exp_design_20120330_ramon_fixai.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20120330_ramon_fixai JOIN main.samples ON ((samples.sample_id = exp_design_20120330_ramon_fixai.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20120330_ramon_fixai OWNER TO dberaldi;

--
-- TOC entry 3860 (class 0 OID 0)
-- Dependencies: 474
-- Name: VIEW view_20120330_ramon_fixai; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20120330_ramon_fixai IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 501 (class 1259 OID 1284954)
-- Dependencies: 3241 40
-- Name: view_20120516_pierre_ribosome_profiling; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20120516_pierre_ribosome_profiling AS
    SELECT DISTINCT exp_design_20120516_pierre_ribosome_profiling.project, exp_design_20120516_pierre_ribosome_profiling.sample_id, exp_design_20120516_pierre_ribosome_profiling.cell_line, exp_design_20120516_pierre_ribosome_profiling.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20120516_pierre_ribosome_profiling JOIN main.samples ON ((samples.sample_id = exp_design_20120516_pierre_ribosome_profiling.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20120516_pierre_ribosome_profiling OWNER TO dberaldi;

--
-- TOC entry 3861 (class 0 OID 0)
-- Dependencies: 501
-- Name: VIEW view_20120516_pierre_ribosome_profiling; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20120516_pierre_ribosome_profiling IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 477 (class 1259 OID 1284698)
-- Dependencies: 3233 40
-- Name: view_20120522_oxbsseq_mesc; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20120522_oxbsseq_mesc AS
    SELECT DISTINCT exp_design_20120522_oxbsseq_mesc.project, exp_design_20120522_oxbsseq_mesc.sample_id, exp_design_20120522_oxbsseq_mesc.bisulfite_reaction, exp_design_20120522_oxbsseq_mesc.cell_line, exp_design_20120522_oxbsseq_mesc.dna_substrate_type, exp_design_20120522_oxbsseq_mesc.n_pcr_cycles, exp_design_20120522_oxbsseq_mesc.replicate, exp_design_20120522_oxbsseq_mesc.synthetic_strand_percent, exp_design_20120522_oxbsseq_mesc.synthetic_strands, exp_design_20120522_oxbsseq_mesc.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20120522_oxbsseq_mesc JOIN main.samples ON ((samples.sample_id = exp_design_20120522_oxbsseq_mesc.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20120522_oxbsseq_mesc OWNER TO dberaldi;

--
-- TOC entry 3862 (class 0 OID 0)
-- Dependencies: 477
-- Name: VIEW view_20120522_oxbsseq_mesc; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20120522_oxbsseq_mesc IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 471 (class 1259 OID 1284634)
-- Dependencies: 3231 40
-- Name: view_20120622_rnaseq_pdsa; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20120622_rnaseq_pdsa AS
    SELECT DISTINCT exp_design_20120622_rnaseq_pdsa.project, exp_design_20120622_rnaseq_pdsa.sample_id, exp_design_20120622_rnaseq_pdsa.cell_line, exp_design_20120622_rnaseq_pdsa.chip_target, exp_design_20120622_rnaseq_pdsa."pyridostatin_uM", exp_design_20120622_rnaseq_pdsa.replicate, exp_design_20120622_rnaseq_pdsa.treatment, exp_design_20120622_rnaseq_pdsa.treatment_time, exp_design_20120622_rnaseq_pdsa.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20120622_rnaseq_pdsa JOIN main.samples ON ((samples.sample_id = exp_design_20120622_rnaseq_pdsa.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20120622_rnaseq_pdsa OWNER TO dberaldi;

--
-- TOC entry 3863 (class 0 OID 0)
-- Dependencies: 471
-- Name: VIEW view_20120622_rnaseq_pdsa; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20120622_rnaseq_pdsa IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 480 (class 1259 OID 1284730)
-- Dependencies: 3234 40
-- Name: view_20120925_mdip_hematop_sc; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20120925_mdip_hematop_sc AS
    SELECT DISTINCT exp_design_20120925_mdip_hematop_sc.project, exp_design_20120925_mdip_hematop_sc.sample_id, exp_design_20120925_mdip_hematop_sc.chip_target, exp_design_20120925_mdip_hematop_sc.mnase_time, exp_design_20120925_mdip_hematop_sc.replicate, exp_design_20120925_mdip_hematop_sc.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20120925_mdip_hematop_sc JOIN main.samples ON ((samples.sample_id = exp_design_20120925_mdip_hematop_sc.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20120925_mdip_hematop_sc OWNER TO dberaldi;

--
-- TOC entry 3864 (class 0 OID 0)
-- Dependencies: 480
-- Name: VIEW view_20120925_mdip_hematop_sc; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20120925_mdip_hematop_sc IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 504 (class 1259 OID 1284986)
-- Dependencies: 3242 40
-- Name: view_20121015_hmc_lambda; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20121015_hmc_lambda AS
    SELECT DISTINCT exp_design_20121015_hmc_lambda.project, exp_design_20121015_hmc_lambda.sample_id, exp_design_20121015_hmc_lambda.replicate, exp_design_20121015_hmc_lambda.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20121015_hmc_lambda JOIN main.samples ON ((samples.sample_id = exp_design_20121015_hmc_lambda.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20121015_hmc_lambda OWNER TO dberaldi;

--
-- TOC entry 3865 (class 0 OID 0)
-- Dependencies: 504
-- Name: VIEW view_20121015_hmc_lambda; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20121015_hmc_lambda IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 516 (class 1259 OID 1285114)
-- Dependencies: 3246 40
-- Name: view_20121122_oxbseq_kit_toby; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20121122_oxbseq_kit_toby AS
    SELECT DISTINCT exp_design_20121122_oxbseq_kit_toby.project, exp_design_20121122_oxbseq_kit_toby.sample_id, exp_design_20121122_oxbseq_kit_toby.hpa_ilmn_ratio, exp_design_20121122_oxbseq_kit_toby.synthetic_strand_percent, exp_design_20121122_oxbseq_kit_toby.synthetic_strands, exp_design_20121122_oxbseq_kit_toby.trialist, exp_design_20121122_oxbseq_kit_toby.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20121122_oxbseq_kit_toby JOIN main.samples ON ((samples.sample_id = exp_design_20121122_oxbseq_kit_toby.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20121122_oxbseq_kit_toby OWNER TO dberaldi;

--
-- TOC entry 3866 (class 0 OID 0)
-- Dependencies: 516
-- Name: VIEW view_20121122_oxbseq_kit_toby; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20121122_oxbseq_kit_toby IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 507 (class 1259 OID 1285018)
-- Dependencies: 3243 40
-- Name: view_20121408_mikeb_oxbs_mtdna; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20121408_mikeb_oxbs_mtdna AS
    SELECT DISTINCT exp_design_20121408_mikeb_oxbs_mtdna.project, exp_design_20121408_mikeb_oxbs_mtdna.sample_id, exp_design_20121408_mikeb_oxbs_mtdna.cell_line, exp_design_20121408_mikeb_oxbs_mtdna.replicate, exp_design_20121408_mikeb_oxbs_mtdna.synthetic_strands, exp_design_20121408_mikeb_oxbs_mtdna.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20121408_mikeb_oxbs_mtdna JOIN main.samples ON ((samples.sample_id = exp_design_20121408_mikeb_oxbs_mtdna.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20121408_mikeb_oxbs_mtdna OWNER TO dberaldi;

--
-- TOC entry 3867 (class 0 OID 0)
-- Dependencies: 507
-- Name: VIEW view_20121408_mikeb_oxbs_mtdna; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20121408_mikeb_oxbs_mtdna IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 549 (class 1259 OID 1285466)
-- Dependencies: 3257 40
-- Name: view_20130214_oxbs_vs_tab; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130214_oxbs_vs_tab AS
    SELECT DISTINCT exp_design_20130214_oxbs_vs_tab.project, exp_design_20130214_oxbs_vs_tab.sample_id, exp_design_20130214_oxbs_vs_tab.synthetic_strand_percent, exp_design_20130214_oxbs_vs_tab.synthetic_strands, exp_design_20130214_oxbs_vs_tab.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130214_oxbs_vs_tab JOIN main.samples ON ((samples.sample_id = exp_design_20130214_oxbs_vs_tab.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130214_oxbs_vs_tab OWNER TO dberaldi;

--
-- TOC entry 3868 (class 0 OID 0)
-- Dependencies: 549
-- Name: VIEW view_20130214_oxbs_vs_tab; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130214_oxbs_vs_tab IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 519 (class 1259 OID 1285146)
-- Dependencies: 3247 40
-- Name: view_20130312_oxbs_optimization_nmb; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130312_oxbs_optimization_nmb AS
    SELECT DISTINCT exp_design_20130312_oxbs_optimization_nmb.project, exp_design_20130312_oxbs_optimization_nmb.sample_id, exp_design_20130312_oxbs_optimization_nmb.bisulfite_molar_conc, exp_design_20130312_oxbs_optimization_nmb.synthetic_strand_percent, exp_design_20130312_oxbs_optimization_nmb.synthetic_strands, exp_design_20130312_oxbs_optimization_nmb.treatment_time, exp_design_20130312_oxbs_optimization_nmb.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130312_oxbs_optimization_nmb JOIN main.samples ON ((samples.sample_id = exp_design_20130312_oxbs_optimization_nmb.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130312_oxbs_optimization_nmb OWNER TO dberaldi;

--
-- TOC entry 3869 (class 0 OID 0)
-- Dependencies: 519
-- Name: VIEW view_20130312_oxbs_optimization_nmb; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130312_oxbs_optimization_nmb IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 525 (class 1259 OID 1285210)
-- Dependencies: 3249 40
-- Name: view_20130409_reduced_bsseq; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130409_reduced_bsseq AS
    SELECT DISTINCT exp_design_20130409_reduced_bsseq.project, exp_design_20130409_reduced_bsseq.sample_id, exp_design_20130409_reduced_bsseq.cell_line, exp_design_20130409_reduced_bsseq.rrbs_enzyme, exp_design_20130409_reduced_bsseq.sirna, exp_design_20130409_reduced_bsseq.strain, exp_design_20130409_reduced_bsseq.synthetic_strands, exp_design_20130409_reduced_bsseq.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130409_reduced_bsseq JOIN main.samples ON ((samples.sample_id = exp_design_20130409_reduced_bsseq.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130409_reduced_bsseq OWNER TO dberaldi;

--
-- TOC entry 3870 (class 0 OID 0)
-- Dependencies: 525
-- Name: VIEW view_20130409_reduced_bsseq; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130409_reduced_bsseq IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 510 (class 1259 OID 1285050)
-- Dependencies: 3244 40
-- Name: view_20130424_rnaseq_mikeg; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130424_rnaseq_mikeg AS
    SELECT DISTINCT exp_design_20130424_rnaseq_mikeg.project, exp_design_20130424_rnaseq_mikeg.sample_id, exp_design_20130424_rnaseq_mikeg.cell_line, exp_design_20130424_rnaseq_mikeg.treatment_time, exp_design_20130424_rnaseq_mikeg.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130424_rnaseq_mikeg JOIN main.samples ON ((samples.sample_id = exp_design_20130424_rnaseq_mikeg.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130424_rnaseq_mikeg OWNER TO dberaldi;

--
-- TOC entry 3871 (class 0 OID 0)
-- Dependencies: 510
-- Name: VIEW view_20130424_rnaseq_mikeg; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130424_rnaseq_mikeg IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 528 (class 1259 OID 1285242)
-- Dependencies: 3250 40
-- Name: view_20130507_rnaseq_rhau_mchen; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130507_rnaseq_rhau_mchen AS
    SELECT DISTINCT exp_design_20130507_rnaseq_rhau_mchen.project, exp_design_20130507_rnaseq_rhau_mchen.sample_id, exp_design_20130507_rnaseq_rhau_mchen.cell_line, exp_design_20130507_rnaseq_rhau_mchen.sirna, exp_design_20130507_rnaseq_rhau_mchen.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130507_rnaseq_rhau_mchen JOIN main.samples ON ((samples.sample_id = exp_design_20130507_rnaseq_rhau_mchen.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130507_rnaseq_rhau_mchen OWNER TO dberaldi;

--
-- TOC entry 3872 (class 0 OID 0)
-- Dependencies: 528
-- Name: VIEW view_20130507_rnaseq_rhau_mchen; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130507_rnaseq_rhau_mchen IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 543 (class 1259 OID 1285402)
-- Dependencies: 3255 40
-- Name: view_20130520_chipseq_olivia; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130520_chipseq_olivia AS
    SELECT DISTINCT exp_design_20130520_chipseq_olivia.project, exp_design_20130520_chipseq_olivia.sample_id, exp_design_20130520_chipseq_olivia.amino_acid, exp_design_20130520_chipseq_olivia.cell_line, exp_design_20130520_chipseq_olivia.chip_target, exp_design_20130520_chipseq_olivia.harvest_time, exp_design_20130520_chipseq_olivia.hydroxygluterate_feeding, exp_design_20130520_chipseq_olivia.idh2_mutant, exp_design_20130520_chipseq_olivia.light, exp_design_20130520_chipseq_olivia.photocaged, exp_design_20130520_chipseq_olivia.transient_transfection, exp_design_20130520_chipseq_olivia.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130520_chipseq_olivia JOIN main.samples ON ((samples.sample_id = exp_design_20130520_chipseq_olivia.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130520_chipseq_olivia OWNER TO dberaldi;

--
-- TOC entry 3873 (class 0 OID 0)
-- Dependencies: 543
-- Name: VIEW view_20130520_chipseq_olivia; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130520_chipseq_olivia IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 555 (class 1259 OID 1285530)
-- Dependencies: 3259 40
-- Name: view_20130610_5fc_linker_gordon; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130610_5fc_linker_gordon AS
    SELECT DISTINCT exp_design_20130610_5fc_linker_gordon.project, exp_design_20130610_5fc_linker_gordon.sample_id, exp_design_20130610_5fc_linker_gordon.chip_target, exp_design_20130610_5fc_linker_gordon.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130610_5fc_linker_gordon JOIN main.samples ON ((samples.sample_id = exp_design_20130610_5fc_linker_gordon.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130610_5fc_linker_gordon OWNER TO dberaldi;

--
-- TOC entry 3874 (class 0 OID 0)
-- Dependencies: 555
-- Name: VIEW view_20130610_5fc_linker_gordon; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130610_5fc_linker_gordon IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 558 (class 1259 OID 1285562)
-- Dependencies: 3260 40
-- Name: view_20130705_oxbs_rna; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130705_oxbs_rna AS
    SELECT DISTINCT exp_design_20130705_oxbs_rna.project, exp_design_20130705_oxbs_rna.sample_id, exp_design_20130705_oxbs_rna.bisulfite_reaction, exp_design_20130705_oxbs_rna.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130705_oxbs_rna JOIN main.samples ON ((samples.sample_id = exp_design_20130705_oxbs_rna.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130705_oxbs_rna OWNER TO dberaldi;

--
-- TOC entry 3875 (class 0 OID 0)
-- Dependencies: 558
-- Name: VIEW view_20130705_oxbs_rna; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130705_oxbs_rna IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 537 (class 1259 OID 1285338)
-- Dependencies: 3253 40
-- Name: view_20130722_oxbseq_450k_sally; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130722_oxbseq_450k_sally AS
    SELECT DISTINCT exp_design_20130722_oxbseq_450k_sally.project, exp_design_20130722_oxbseq_450k_sally.sample_id, exp_design_20130722_oxbseq_450k_sally.rrbs_enzyme, exp_design_20130722_oxbseq_450k_sally.tumor_condition, exp_design_20130722_oxbseq_450k_sally.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130722_oxbseq_450k_sally JOIN main.samples ON ((samples.sample_id = exp_design_20130722_oxbseq_450k_sally.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130722_oxbseq_450k_sally OWNER TO dberaldi;

--
-- TOC entry 3876 (class 0 OID 0)
-- Dependencies: 537
-- Name: VIEW view_20130722_oxbseq_450k_sally; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130722_oxbseq_450k_sally IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 546 (class 1259 OID 1285434)
-- Dependencies: 3256 40
-- Name: view_20130906_faire_seq_robert; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130906_faire_seq_robert AS
    SELECT DISTINCT exp_design_20130906_faire_seq_robert.project, exp_design_20130906_faire_seq_robert.sample_id, exp_design_20130906_faire_seq_robert.amount, exp_design_20130906_faire_seq_robert.cell_line, exp_design_20130906_faire_seq_robert.chip_target, exp_design_20130906_faire_seq_robert."gamma_Gy", exp_design_20130906_faire_seq_robert.is_faire_input, exp_design_20130906_faire_seq_robert.pull_repl, exp_design_20130906_faire_seq_robert."pyridostatin_uM", exp_design_20130906_faire_seq_robert.replicate, exp_design_20130906_faire_seq_robert.treatment, exp_design_20130906_faire_seq_robert.treatment_conc, exp_design_20130906_faire_seq_robert.treatment_time, exp_design_20130906_faire_seq_robert.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130906_faire_seq_robert JOIN main.samples ON ((samples.sample_id = exp_design_20130906_faire_seq_robert.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130906_faire_seq_robert OWNER TO dberaldi;

--
-- TOC entry 3877 (class 0 OID 0)
-- Dependencies: 546
-- Name: VIEW view_20130906_faire_seq_robert; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130906_faire_seq_robert IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 531 (class 1259 OID 1285274)
-- Dependencies: 3251 40
-- Name: view_20130906_foxm1_gfp; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130906_foxm1_gfp AS
    SELECT DISTINCT exp_design_20130906_foxm1_gfp.project, exp_design_20130906_foxm1_gfp.sample_id, exp_design_20130906_foxm1_gfp.chip_target, exp_design_20130906_foxm1_gfp.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130906_foxm1_gfp JOIN main.samples ON ((samples.sample_id = exp_design_20130906_foxm1_gfp.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130906_foxm1_gfp OWNER TO dberaldi;

--
-- TOC entry 3878 (class 0 OID 0)
-- Dependencies: 531
-- Name: VIEW view_20130906_foxm1_gfp; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130906_foxm1_gfp IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 498 (class 1259 OID 1284922)
-- Dependencies: 3240 40
-- Name: view_20130916_sureselect_euni; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20130916_sureselect_euni AS
    SELECT DISTINCT exp_design_20130916_sureselect_euni.project, exp_design_20130916_sureselect_euni.sample_id, exp_design_20130916_sureselect_euni.cell_line, exp_design_20130916_sureselect_euni.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20130916_sureselect_euni JOIN main.samples ON ((samples.sample_id = exp_design_20130916_sureselect_euni.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20130916_sureselect_euni OWNER TO dberaldi;

--
-- TOC entry 3879 (class 0 OID 0)
-- Dependencies: 498
-- Name: VIEW view_20130916_sureselect_euni; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20130916_sureselect_euni IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 522 (class 1259 OID 1285178)
-- Dependencies: 3248 40
-- Name: view_20140818_fumi_hmu_pull_down; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20140818_fumi_hmu_pull_down AS
    SELECT DISTINCT exp_design_20140818_fumi_hmu_pull_down.project, exp_design_20140818_fumi_hmu_pull_down.sample_id, exp_design_20140818_fumi_hmu_pull_down.chip_target, exp_design_20140818_fumi_hmu_pull_down.host, exp_design_20140818_fumi_hmu_pull_down.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20140818_fumi_hmu_pull_down JOIN main.samples ON ((samples.sample_id = exp_design_20140818_fumi_hmu_pull_down.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20140818_fumi_hmu_pull_down OWNER TO dberaldi;

--
-- TOC entry 3880 (class 0 OID 0)
-- Dependencies: 522
-- Name: VIEW view_20140818_fumi_hmu_pull_down; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20140818_fumi_hmu_pull_down IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 561 (class 1259 OID 1285594)
-- Dependencies: 3261 40
-- Name: view_20141215_robyn_modified_u; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20141215_robyn_modified_u AS
    SELECT DISTINCT exp_design_20141215_robyn_modified_u.project, exp_design_20141215_robyn_modified_u.sample_id, exp_design_20141215_robyn_modified_u.chip_target, exp_design_20141215_robyn_modified_u.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20141215_robyn_modified_u JOIN main.samples ON ((samples.sample_id = exp_design_20141215_robyn_modified_u.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20141215_robyn_modified_u OWNER TO dberaldi;

--
-- TOC entry 3881 (class 0 OID 0)
-- Dependencies: 561
-- Name: VIEW view_20141215_robyn_modified_u; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20141215_robyn_modified_u IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 489 (class 1259 OID 1284826)
-- Dependencies: 3237 40
-- Name: view_20150309_gordon_redBS_mESC; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW "view_20150309_gordon_redBS_mESC" AS
    SELECT DISTINCT "exp_design_20150309_gordon_redBS_mESC".project, "exp_design_20150309_gordon_redBS_mESC".sample_id, "exp_design_20150309_gordon_redBS_mESC".animal_id, "exp_design_20150309_gordon_redBS_mESC".chip_target, "exp_design_20150309_gordon_redBS_mESC".embryo_day, "exp_design_20150309_gordon_redBS_mESC".genotype, "exp_design_20150309_gordon_redBS_mESC".knock_out, "exp_design_20150309_gordon_redBS_mESC".litter, "exp_design_20150309_gordon_redBS_mESC".id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM (("exp_design_20150309_gordon_redBS_mESC" JOIN main.samples ON ((samples.sample_id = "exp_design_20150309_gordon_redBS_mESC".sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views."view_20150309_gordon_redBS_mESC" OWNER TO dberaldi;

--
-- TOC entry 3882 (class 0 OID 0)
-- Dependencies: 489
-- Name: VIEW "view_20150309_gordon_redBS_mESC"; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW "view_20150309_gordon_redBS_mESC" IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 540 (class 1259 OID 1285370)
-- Dependencies: 3254 40
-- Name: view_20150320_Robert_senescent_chromatin; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW "view_20150320_Robert_senescent_chromatin" AS
    SELECT DISTINCT "exp_design_20150320_Robert_senescent_chromatin".project, "exp_design_20150320_Robert_senescent_chromatin".sample_id, "exp_design_20150320_Robert_senescent_chromatin".cell_line, "exp_design_20150320_Robert_senescent_chromatin".overexpression, "exp_design_20150320_Robert_senescent_chromatin"."shRNA", "exp_design_20150320_Robert_senescent_chromatin".id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM (("exp_design_20150320_Robert_senescent_chromatin" JOIN main.samples ON ((samples.sample_id = "exp_design_20150320_Robert_senescent_chromatin".sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views."view_20150320_Robert_senescent_chromatin" OWNER TO dberaldi;

--
-- TOC entry 3883 (class 0 OID 0)
-- Dependencies: 540
-- Name: VIEW "view_20150320_Robert_senescent_chromatin"; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW "view_20150320_Robert_senescent_chromatin" IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 552 (class 1259 OID 1285498)
-- Dependencies: 3258 40
-- Name: view_20150805_bless_stefanie; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20150805_bless_stefanie AS
    SELECT DISTINCT exp_design_20150805_bless_stefanie.project, exp_design_20150805_bless_stefanie.sample_id, exp_design_20150805_bless_stefanie.cell_line, exp_design_20150805_bless_stefanie.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20150805_bless_stefanie JOIN main.samples ON ((samples.sample_id = exp_design_20150805_bless_stefanie.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20150805_bless_stefanie OWNER TO dberaldi;

--
-- TOC entry 3884 (class 0 OID 0)
-- Dependencies: 552
-- Name: VIEW view_20150805_bless_stefanie; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20150805_bless_stefanie IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 534 (class 1259 OID 1285306)
-- Dependencies: 3252 40
-- Name: view_20150821_tobi_cisplatin; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_20150821_tobi_cisplatin AS
    SELECT DISTINCT exp_design_20150821_tobi_cisplatin.project, exp_design_20150821_tobi_cisplatin.sample_id, exp_design_20150821_tobi_cisplatin.chip_target, exp_design_20150821_tobi_cisplatin.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_20150821_tobi_cisplatin JOIN main.samples ON ((samples.sample_id = exp_design_20150821_tobi_cisplatin.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_20150821_tobi_cisplatin OWNER TO dberaldi;

--
-- TOC entry 3885 (class 0 OID 0)
-- Dependencies: 534
-- Name: VIEW view_20150821_tobi_cisplatin; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_20150821_tobi_cisplatin IS 'Table created by create_crosstab_project_designs() triggered by changes on exp_design (and possibly ther tables)';


--
-- TOC entry 564 (class 1259 OID 1285658)
-- Dependencies: 3262 40
-- Name: view_exp_design_samples; Type: VIEW; Schema: materialized_views; Owner: dberaldi
--

CREATE VIEW view_exp_design_samples AS
    SELECT DISTINCT exp_design_samples.sample_id, exp_design_samples.amino_acid, exp_design_samples.amount, exp_design_samples.animal_id, exp_design_samples.bisulfite_molar_conc, exp_design_samples.bisulfite_reaction, exp_design_samples.cell_line, exp_design_samples.cell_phase, exp_design_samples.chip_target, exp_design_samples.clonal_line, exp_design_samples.dna_substrate_type, exp_design_samples.drug, exp_design_samples.embryo_day, exp_design_samples.fixai_target, exp_design_samples.foxm1_cat_id, exp_design_samples."gamma_Gy", exp_design_samples.genotype, exp_design_samples.harvest_time, exp_design_samples.host, exp_design_samples.hpa_ilmn_ratio, exp_design_samples.hydroxygluterate_feeding, exp_design_samples.idh2_mutant, exp_design_samples.is_faire_input, exp_design_samples.knock_out, exp_design_samples.light, exp_design_samples.litter, exp_design_samples.mnase_time, exp_design_samples.modification, exp_design_samples.n_pcr_cycles, exp_design_samples.overexpression, exp_design_samples.photocaged, exp_design_samples.polymerase, exp_design_samples.pull_repl, exp_design_samples."pyridostatin_uM", exp_design_samples.replicate, exp_design_samples.rrbs_enzyme, exp_design_samples."shRNA", exp_design_samples.sirna, exp_design_samples.stage, exp_design_samples.strain, exp_design_samples.synthetic_strand_percent, exp_design_samples.synthetic_strands, exp_design_samples.tetr_gene, exp_design_samples.tetr_induction, exp_design_samples.transient_transfection, exp_design_samples.treatment, exp_design_samples.treatment_conc, exp_design_samples.treatment_time, exp_design_samples.trialist, exp_design_samples.tumor_condition, exp_design_samples.id, samples.organism, samples.source_name, samples.molecule, libraries.library_id, libraries.library_type FROM ((exp_design_samples JOIN main.samples ON ((exp_design_samples.sample_id = samples.sample_id))) LEFT JOIN main.libraries ON ((libraries.sample_id = samples.sample_id)));


ALTER TABLE materialized_views.view_exp_design_samples OWNER TO dberaldi;

--
-- TOC entry 3886 (class 0 OID 0)
-- Dependencies: 564
-- Name: VIEW view_exp_design_samples; Type: COMMENT; Schema: materialized_views; Owner: dberaldi
--

COMMENT ON VIEW view_exp_design_samples IS 'Table created by procedure main.update_crosstab_exp_design() triggered by "trigger_crosstab_exp_design" on update/insert/delete on table exp_design. Do not modify this table directly.';


SET search_path = public, pg_catalog;

--
-- TOC entry 396 (class 1259 OID 30794)
-- Dependencies: 5
-- Name: barcodes_tmp; Type: TABLE; Schema: public; Owner: dberaldi; Tablespace: 
--

CREATE TABLE barcodes_tmp (
    barcode_id text[] NOT NULL
);


ALTER TABLE public.barcodes_tmp OWNER TO dberaldi;

--
-- TOC entry 425 (class 1259 OID 35941)
-- Dependencies: 5
-- Name: customer; Type: TABLE; Schema: public; Owner: dberaldi; Tablespace: 
--

CREATE TABLE customer (
    customer text
);


ALTER TABLE public.customer OWNER TO dberaldi;

--
-- TOC entry 433 (class 1259 OID 116710)
-- Dependencies: 3223 5
-- Name: dual; Type: VIEW; Schema: public; Owner: dberaldi
--

CREATE VIEW dual AS
    SELECT 'X'::character varying AS dummy;


ALTER TABLE public.dual OWNER TO dberaldi;

--
-- TOC entry 438 (class 1259 OID 168208)
-- Dependencies: 5
-- Name: myblastout; Type: TABLE; Schema: public; Owner: dberaldi; Tablespace: 
--

CREATE TABLE myblastout (
    qseqid text,
    sseqid text,
    pident double precision,
    length integer,
    mismatch integer,
    gapopen integer,
    qstart integer,
    qend integer,
    sstart integer,
    send integer,
    evalue double precision,
    bitscore double precision
);


ALTER TABLE public.myblastout OWNER TO dberaldi;

--
-- TOC entry 3888 (class 0 OID 0)
-- Dependencies: 438
-- Name: TABLE myblastout; Type: COMMENT; Schema: public; Owner: dberaldi
--

COMMENT ON TABLE myblastout IS 'BLAST output generated by function pg_blast() on [Mon Jun 18 16:39:24 2012]
BLASTN command was
/Applications/blast+/ncbi-blast-2.2.26+/bin/blastn -outfmt 6 -query /var/folders/AS/ASAJNiztHCW0SZZ0KHQ+Vk+++TQ/-Tmp-/pg_blast/pg_blast_query.fa -db /var/folders/AS/ASAJNiztHCW0SZZ0KHQ+Vk+++TQ/-Tmp-/pg_blast/pg_blast_database.fa -max_target_seqs 2 -evalue 1e-9 -out /var/folders/AS/ASAJNiztHCW0SZZ0KHQ+Vk+++TQ/-Tmp-/pg_blast/pg_blast_query.fa.blastout
See also log dir /var/folders/AS/ASAJNiztHCW0SZZ0KHQ+Vk+++TQ/-Tmp-/pg_blast';


--
-- TOC entry 388 (class 1259 OID 28304)
-- Dependencies: 5
-- Name: mytable; Type: TABLE; Schema: public; Owner: dberaldi; Tablespace: 
--

CREATE TABLE mytable (
    chrom text,
    start integer,
    "end" integer,
    peak_id text,
    score double precision,
    strand text,
    merged_peaks text,
    annotation text,
    detailed_annotation text,
    distance_to_tss integer,
    nearest_promoter_id text,
    entrez_id text,
    nearest_unigene_id text,
    nearest_refseq_id text,
    nearest_ensembl_id text,
    gene_name text,
    gene_alias text,
    gene_description text
);


ALTER TABLE public.mytable OWNER TO dberaldi;

--
-- TOC entry 387 (class 1259 OID 28201)
-- Dependencies: 5
-- Name: t; Type: TABLE; Schema: public; Owner: dberaldi; Tablespace: 
--

CREATE TABLE t (
    a text,
    b integer
);


ALTER TABLE public.t OWNER TO dberaldi;

--
-- TOC entry 426 (class 1259 OID 36511)
-- Dependencies: 5
-- Name: testfile; Type: TABLE; Schema: public; Owner: dberaldi; Tablespace: 
--

CREATE TABLE testfile (
    fileid text NOT NULL,
    file text
);


ALTER TABLE public.testfile OWNER TO dberaldi;

--
-- TOC entry 447 (class 1259 OID 210891)
-- Dependencies: 3295 5
-- Name: tmp_fq; Type: TABLE; Schema: public; Owner: dberaldi; Tablespace: 
--

CREATE TABLE tmp_fq (
    fastqfile text NOT NULL,
    encoding text,
    md5sum text,
    description text,
    service_id text,
    library_id text,
    CONSTRAINT check_library_fq CHECK ((get_library_id(fastqfile) = library_id))
);


ALTER TABLE public.tmp_fq OWNER TO dberaldi;

SET search_path = utl_file, pg_catalog;

--
-- TOC entry 435 (class 1259 OID 116945)
-- Dependencies: 55
-- Name: utl_file_dir; Type: TABLE; Schema: utl_file; Owner: dberaldi; Tablespace: 
--

CREATE TABLE utl_file_dir (
    dir text
);


ALTER TABLE utl_file.utl_file_dir OWNER TO dberaldi;

SET search_path = zzz_unused_or_deprecated, pg_catalog;

--
-- TOC entry 386 (class 1259 OID 24700)
-- Dependencies: 106
-- Name: chipseq_input; Type: TABLE; Schema: zzz_unused_or_deprecated; Owner: dberaldi; Tablespace: 
--

CREATE TABLE chipseq_input (
    input_id text NOT NULL,
    input_for text NOT NULL,
    input_type text,
    description text,
    id integer NOT NULL
);


ALTER TABLE zzz_unused_or_deprecated.chipseq_input OWNER TO dberaldi;

--
-- TOC entry 3890 (class 0 OID 0)
-- Dependencies: 386
-- Name: TABLE chipseq_input; Type: COMMENT; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

COMMENT ON TABLE chipseq_input IS 'Table to match chipseq samples to their input control libraries';


--
-- TOC entry 421 (class 1259 OID 31719)
-- Dependencies: 386 106
-- Name: chipseq_input_id_seq; Type: SEQUENCE; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

CREATE SEQUENCE chipseq_input_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE zzz_unused_or_deprecated.chipseq_input_id_seq OWNER TO dberaldi;

--
-- TOC entry 3891 (class 0 OID 0)
-- Dependencies: 421
-- Name: chipseq_input_id_seq; Type: SEQUENCE OWNED BY; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

ALTER SEQUENCE chipseq_input_id_seq OWNED BY chipseq_input.id;


--
-- TOC entry 393 (class 1259 OID 30319)
-- Dependencies: 3275 106
-- Name: project_files; Type: TABLE; Schema: zzz_unused_or_deprecated; Owner: dberaldi; Tablespace: 
--

CREATE TABLE project_files (
    file_id integer NOT NULL,
    project text,
    hostname text NOT NULL,
    path text NOT NULL,
    filename text NOT NULL,
    ctime timestamp without time zone NOT NULL,
    mtime timestamp without time zone NOT NULL,
    fsize bigint NOT NULL,
    md5sum text NOT NULL,
    removed boolean,
    description text NOT NULL,
    CONSTRAINT project_files_md5sum_check CHECK ((((length(md5sum) = 32) AND (NOT (md5sum ~ '[^a-zA-Z0-9]'::text))) OR (md5sum = 'not_available'::text)))
);


ALTER TABLE zzz_unused_or_deprecated.project_files OWNER TO dberaldi;

--
-- TOC entry 392 (class 1259 OID 30317)
-- Dependencies: 106 393
-- Name: project_files_file_id_seq; Type: SEQUENCE; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

CREATE SEQUENCE project_files_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE zzz_unused_or_deprecated.project_files_file_id_seq OWNER TO dberaldi;

--
-- TOC entry 3892 (class 0 OID 0)
-- Dependencies: 392
-- Name: project_files_file_id_seq; Type: SEQUENCE OWNED BY; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

ALTER SEQUENCE project_files_file_id_seq OWNED BY project_files.file_id;


SET search_path = django_admin, pg_catalog;

--
-- TOC entry 3282 (class 2604 OID 31282)
-- Dependencies: 403 404 404
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- TOC entry 3281 (class 2604 OID 31267)
-- Dependencies: 402 401 402
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- TOC entry 3286 (class 2604 OID 31347)
-- Dependencies: 411 412 412
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE auth_message ALTER COLUMN id SET DEFAULT nextval('auth_message_id_seq'::regclass);


--
-- TOC entry 3280 (class 2604 OID 31257)
-- Dependencies: 399 400 400
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- TOC entry 3285 (class 2604 OID 31327)
-- Dependencies: 410 409 410
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- TOC entry 3284 (class 2604 OID 31312)
-- Dependencies: 408 407 408
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- TOC entry 3283 (class 2604 OID 31297)
-- Dependencies: 405 406 406
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- TOC entry 3289 (class 2604 OID 31404)
-- Dependencies: 418 419 419
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- TOC entry 3287 (class 2604 OID 31363)
-- Dependencies: 414 413 414
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- TOC entry 3288 (class 2604 OID 31386)
-- Dependencies: 416 417 417
-- Name: id; Type: DEFAULT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


SET search_path = main, pg_catalog;

--
-- TOC entry 3266 (class 2604 OID 31711)
-- Dependencies: 420 382
-- Name: id; Type: DEFAULT; Schema: main; Owner: dberaldi
--

ALTER TABLE exp_design ALTER COLUMN id SET DEFAULT nextval('exp_design_id_seq'::regclass);


--
-- TOC entry 3291 (class 2604 OID 31989)
-- Dependencies: 424 423
-- Name: id; Type: DEFAULT; Schema: main; Owner: dberaldi
--

ALTER TABLE exp_values ALTER COLUMN id SET DEFAULT nextval('exp_values_id_seq'::regclass);


--
-- TOC entry 3293 (class 2604 OID 52897)
-- Dependencies: 429 430 430
-- Name: id; Type: DEFAULT; Schema: main; Owner: dberaldi
--

ALTER TABLE lib2seq ALTER COLUMN id SET DEFAULT nextval('lib2seq_id_seq'::regclass);


--
-- TOC entry 3271 (class 2604 OID 31741)
-- Dependencies: 422 384
-- Name: id; Type: DEFAULT; Schema: main; Owner: dberaldi
--

ALTER TABLE project_samples ALTER COLUMN id SET DEFAULT nextval('project_samples_id_seq'::regclass);


SET search_path = materialized_views, pg_catalog;

--
-- TOC entry 3316 (class 2604 OID 1284755)
-- Dependencies: 482 481
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20111206_chipseq_foxm1_debbies ALTER COLUMN id SET DEFAULT nextval('exp_design_20111206_chipseq_foxm1_debbies_id_seq'::regclass);


--
-- TOC entry 3317 (class 2604 OID 1284787)
-- Dependencies: 485 484
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20111206_chipseq_gquad_lame ALTER COLUMN id SET DEFAULT nextval('exp_design_20111206_chipseq_gquad_lame_id_seq'::regclass);


--
-- TOC entry 3320 (class 2604 OID 1284883)
-- Dependencies: 494 493
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20111212_chipseq_formylseq_raiberea ALTER COLUMN id SET DEFAULT nextval('exp_design_20111212_chipseq_formylseq_raiberea_id_seq'::regclass);


--
-- TOC entry 3326 (class 2604 OID 1285075)
-- Dependencies: 512 511
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20120305_pif1 ALTER COLUMN id SET DEFAULT nextval('exp_design_20120305_pif1_id_seq'::regclass);


--
-- TOC entry 3319 (class 2604 OID 1284851)
-- Dependencies: 491 490
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20120306_sanneh_gquad ALTER COLUMN id SET DEFAULT nextval('exp_design_20120306_sanneh_gquad_id_seq'::regclass);


--
-- TOC entry 3313 (class 2604 OID 1284659)
-- Dependencies: 473 472
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20120330_ramon_fixai ALTER COLUMN id SET DEFAULT nextval('exp_design_20120330_ramon_fixai_id_seq'::regclass);


--
-- TOC entry 3322 (class 2604 OID 1284947)
-- Dependencies: 500 499
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20120516_pierre_ribosome_profiling ALTER COLUMN id SET DEFAULT nextval('exp_design_20120516_pierre_ribosome_profiling_id_seq'::regclass);


--
-- TOC entry 3314 (class 2604 OID 1284691)
-- Dependencies: 476 475
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20120522_oxbsseq_mesc ALTER COLUMN id SET DEFAULT nextval('exp_design_20120522_oxbsseq_mesc_id_seq'::regclass);


--
-- TOC entry 3312 (class 2604 OID 1284627)
-- Dependencies: 470 469
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20120622_rnaseq_pdsa ALTER COLUMN id SET DEFAULT nextval('exp_design_20120622_rnaseq_pdsa_id_seq'::regclass);


--
-- TOC entry 3315 (class 2604 OID 1284723)
-- Dependencies: 479 478
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20120925_mdip_hematop_sc ALTER COLUMN id SET DEFAULT nextval('exp_design_20120925_mdip_hematop_sc_id_seq'::regclass);


--
-- TOC entry 3323 (class 2604 OID 1284979)
-- Dependencies: 503 502
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20121015_hmc_lambda ALTER COLUMN id SET DEFAULT nextval('exp_design_20121015_hmc_lambda_id_seq'::regclass);


--
-- TOC entry 3327 (class 2604 OID 1285107)
-- Dependencies: 515 514
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20121122_oxbseq_kit_toby ALTER COLUMN id SET DEFAULT nextval('exp_design_20121122_oxbseq_kit_toby_id_seq'::regclass);


--
-- TOC entry 3324 (class 2604 OID 1285011)
-- Dependencies: 506 505
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20121408_mikeb_oxbs_mtdna ALTER COLUMN id SET DEFAULT nextval('exp_design_20121408_mikeb_oxbs_mtdna_id_seq'::regclass);


--
-- TOC entry 3338 (class 2604 OID 1285459)
-- Dependencies: 548 547
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130214_oxbs_vs_tab ALTER COLUMN id SET DEFAULT nextval('exp_design_20130214_oxbs_vs_tab_id_seq'::regclass);


--
-- TOC entry 3328 (class 2604 OID 1285139)
-- Dependencies: 518 517
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130312_oxbs_optimization_nmb ALTER COLUMN id SET DEFAULT nextval('exp_design_20130312_oxbs_optimization_nmb_id_seq'::regclass);


--
-- TOC entry 3330 (class 2604 OID 1285203)
-- Dependencies: 524 523
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130409_reduced_bsseq ALTER COLUMN id SET DEFAULT nextval('exp_design_20130409_reduced_bsseq_id_seq'::regclass);


--
-- TOC entry 3325 (class 2604 OID 1285043)
-- Dependencies: 509 508
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130424_rnaseq_mikeg ALTER COLUMN id SET DEFAULT nextval('exp_design_20130424_rnaseq_mikeg_id_seq'::regclass);


--
-- TOC entry 3331 (class 2604 OID 1285235)
-- Dependencies: 527 526
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130507_rnaseq_rhau_mchen ALTER COLUMN id SET DEFAULT nextval('exp_design_20130507_rnaseq_rhau_mchen_id_seq'::regclass);


--
-- TOC entry 3336 (class 2604 OID 1285395)
-- Dependencies: 542 541
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130520_chipseq_olivia ALTER COLUMN id SET DEFAULT nextval('exp_design_20130520_chipseq_olivia_id_seq'::regclass);


--
-- TOC entry 3340 (class 2604 OID 1285523)
-- Dependencies: 554 553
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130610_5fc_linker_gordon ALTER COLUMN id SET DEFAULT nextval('exp_design_20130610_5fc_linker_gordon_id_seq'::regclass);


--
-- TOC entry 3341 (class 2604 OID 1285555)
-- Dependencies: 557 556
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130705_oxbs_rna ALTER COLUMN id SET DEFAULT nextval('exp_design_20130705_oxbs_rna_id_seq'::regclass);


--
-- TOC entry 3334 (class 2604 OID 1285331)
-- Dependencies: 536 535
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130722_oxbseq_450k_sally ALTER COLUMN id SET DEFAULT nextval('exp_design_20130722_oxbseq_450k_sally_id_seq'::regclass);


--
-- TOC entry 3337 (class 2604 OID 1285427)
-- Dependencies: 545 544
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130906_faire_seq_robert ALTER COLUMN id SET DEFAULT nextval('exp_design_20130906_faire_seq_robert_id_seq'::regclass);


--
-- TOC entry 3332 (class 2604 OID 1285267)
-- Dependencies: 530 529
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130906_foxm1_gfp ALTER COLUMN id SET DEFAULT nextval('exp_design_20130906_foxm1_gfp_id_seq'::regclass);


--
-- TOC entry 3321 (class 2604 OID 1284915)
-- Dependencies: 497 496
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20130916_sureselect_euni ALTER COLUMN id SET DEFAULT nextval('exp_design_20130916_sureselect_euni_id_seq'::regclass);


--
-- TOC entry 3329 (class 2604 OID 1285171)
-- Dependencies: 521 520
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20140818_fumi_hmu_pull_down ALTER COLUMN id SET DEFAULT nextval('exp_design_20140818_fumi_hmu_pull_down_id_seq'::regclass);


--
-- TOC entry 3342 (class 2604 OID 1285587)
-- Dependencies: 560 559
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20141215_robyn_modified_u ALTER COLUMN id SET DEFAULT nextval('exp_design_20141215_robyn_modified_u_id_seq'::regclass);


--
-- TOC entry 3318 (class 2604 OID 1284819)
-- Dependencies: 488 487
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE "exp_design_20150309_gordon_redBS_mESC" ALTER COLUMN id SET DEFAULT nextval('"exp_design_20150309_gordon_redBS_mESC_id_seq"'::regclass);


--
-- TOC entry 3335 (class 2604 OID 1285363)
-- Dependencies: 539 538
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE "exp_design_20150320_Robert_senescent_chromatin" ALTER COLUMN id SET DEFAULT nextval('"exp_design_20150320_Robert_senescent_chromatin_id_seq"'::regclass);


--
-- TOC entry 3339 (class 2604 OID 1285491)
-- Dependencies: 551 550
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20150805_bless_stefanie ALTER COLUMN id SET DEFAULT nextval('exp_design_20150805_bless_stefanie_id_seq'::regclass);


--
-- TOC entry 3333 (class 2604 OID 1285299)
-- Dependencies: 533 532
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_20150821_tobi_cisplatin ALTER COLUMN id SET DEFAULT nextval('exp_design_20150821_tobi_cisplatin_id_seq'::regclass);


--
-- TOC entry 3343 (class 2604 OID 1285651)
-- Dependencies: 563 562
-- Name: id; Type: DEFAULT; Schema: materialized_views; Owner: dberaldi
--

ALTER TABLE exp_design_samples ALTER COLUMN id SET DEFAULT nextval('exp_design_samples_id_seq'::regclass);


SET search_path = zzz_unused_or_deprecated, pg_catalog;

--
-- TOC entry 3273 (class 2604 OID 31721)
-- Dependencies: 421 386
-- Name: id; Type: DEFAULT; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

ALTER TABLE chipseq_input ALTER COLUMN id SET DEFAULT nextval('chipseq_input_id_seq'::regclass);


--
-- TOC entry 3274 (class 2604 OID 30322)
-- Dependencies: 392 393 393
-- Name: file_id; Type: DEFAULT; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

ALTER TABLE project_files ALTER COLUMN file_id SET DEFAULT nextval('project_files_file_id_seq'::regclass);


SET search_path = django_admin, pg_catalog;

--
-- TOC entry 3391 (class 2606 OID 31286)
-- Dependencies: 404 404
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- TOC entry 3386 (class 2606 OID 31271)
-- Dependencies: 402 402 402
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- TOC entry 3389 (class 2606 OID 31269)
-- Dependencies: 402 402
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3393 (class 2606 OID 31284)
-- Dependencies: 404 404
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- TOC entry 3411 (class 2606 OID 31352)
-- Dependencies: 412 412
-- Name: auth_message_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_pkey PRIMARY KEY (id);


--
-- TOC entry 3381 (class 2606 OID 31261)
-- Dependencies: 400 400 400
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- TOC entry 3383 (class 2606 OID 31259)
-- Dependencies: 400 400
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 3402 (class 2606 OID 31314)
-- Dependencies: 408 408
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3405 (class 2606 OID 31316)
-- Dependencies: 408 408 408
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- TOC entry 3407 (class 2606 OID 31329)
-- Dependencies: 410 410
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- TOC entry 3396 (class 2606 OID 31299)
-- Dependencies: 406 406
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3399 (class 2606 OID 31301)
-- Dependencies: 406 406 406
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- TOC entry 3409 (class 2606 OID 31331)
-- Dependencies: 410 410
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- TOC entry 3424 (class 2606 OID 31410)
-- Dependencies: 419 419
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3414 (class 2606 OID 31367)
-- Dependencies: 414 414 414
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- TOC entry 3416 (class 2606 OID 31365)
-- Dependencies: 414 414
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- TOC entry 3419 (class 2606 OID 31380)
-- Dependencies: 415 415
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- TOC entry 3421 (class 2606 OID 31388)
-- Dependencies: 417 417
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


SET search_path = main, pg_catalog;

--
-- TOC entry 3358 (class 2606 OID 29362)
-- Dependencies: 389 389
-- Name: barcodes_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY barcodes
    ADD CONSTRAINT barcodes_pkey PRIMARY KEY (barcode_id);


--
-- TOC entry 3462 (class 2606 OID 256695)
-- Dependencies: 458 458
-- Name: encodings_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY encodings
    ADD CONSTRAINT encodings_pkey PRIMARY KEY (encoding);


--
-- TOC entry 3347 (class 2606 OID 24651)
-- Dependencies: 382 382 382
-- Name: exp_design_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY exp_design
    ADD CONSTRAINT exp_design_pkey PRIMARY KEY (sample_id, s_variable);


--
-- TOC entry 3427 (class 2606 OID 31998)
-- Dependencies: 423 423
-- Name: exp_values_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY exp_values
    ADD CONSTRAINT exp_values_pkey PRIMARY KEY (id);


--
-- TOC entry 3372 (class 2606 OID 30557)
-- Dependencies: 395 395
-- Name: fastqfiles_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY fastqfiles
    ADD CONSTRAINT fastqfiles_pkey PRIMARY KEY (fastqfile);


--
-- TOC entry 3464 (class 2606 OID 262257)
-- Dependencies: 459 459
-- Name: instrument_models_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY sequencers
    ADD CONSTRAINT instrument_models_pkey PRIMARY KEY (sequencer_id);


--
-- TOC entry 3448 (class 2606 OID 212621)
-- Dependencies: 451 451
-- Name: instruments_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY sequencing_platforms
    ADD CONSTRAINT instruments_pkey PRIMARY KEY (sequencing_platform);


--
-- TOC entry 3378 (class 2606 OID 31003)
-- Dependencies: 398 398
-- Name: libraries_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY libraries
    ADD CONSTRAINT libraries_pkey PRIMARY KEY (library_id);


--
-- TOC entry 3433 (class 2606 OID 46531)
-- Dependencies: 427 427
-- Name: library_types_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY library_types
    ADD CONSTRAINT library_types_pkey PRIMARY KEY (library_type);


--
-- TOC entry 3440 (class 2606 OID 184103)
-- Dependencies: 440 440
-- Name: molecules_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY molecules
    ADD CONSTRAINT molecules_pkey PRIMARY KEY (molecule);


--
-- TOC entry 3442 (class 2606 OID 184116)
-- Dependencies: 441 441
-- Name: organisms_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY organisms
    ADD CONSTRAINT organisms_pkey PRIMARY KEY (organism);


--
-- TOC entry 3370 (class 2606 OID 30394)
-- Dependencies: 394 394
-- Name: pk_exp_variables-s_variable; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY exp_variables
    ADD CONSTRAINT "pk_exp_variables-s_variable" PRIMARY KEY (s_variable);


--
-- TOC entry 3364 (class 2606 OID 29471)
-- Dependencies: 391 391
-- Name: pk_filing_order-table_name; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY filing_order
    ADD CONSTRAINT "pk_filing_order-table_name" PRIMARY KEY (table_name);


--
-- TOC entry 3435 (class 2606 OID 52904)
-- Dependencies: 430 430 430
-- Name: pk_lib2seq; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY lib2seq
    ADD CONSTRAINT pk_lib2seq PRIMARY KEY (library_id, service_id);


--
-- TOC entry 3480 (class 2606 OID 328216)
-- Dependencies: 463 463 463
-- Name: pkey_bamfile; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY samtools_idxstats
    ADD CONSTRAINT pkey_bamfile PRIMARY KEY (sequence_name, bamfile);


--
-- TOC entry 3360 (class 2606 OID 29391)
-- Dependencies: 390 390
-- Name: pkey_contacts-contact_name; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY contacts
    ADD CONSTRAINT "pkey_contacts-contact_name" PRIMARY KEY (contact_name);


--
-- TOC entry 3482 (class 2606 OID 329375)
-- Dependencies: 464 464 464 464
-- Name: pkey_flagstat_bamfile; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY samtools_flagstat
    ADD CONSTRAINT pkey_flagstat_bamfile PRIMARY KEY (md5sum, bamfile, mate);


--
-- TOC entry 3345 (class 2606 OID 29282)
-- Dependencies: 381 381
-- Name: pkey_solexa_lims; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY solexa_lims
    ADD CONSTRAINT pkey_solexa_lims PRIMARY KEY (service_id);


--
-- TOC entry 3478 (class 2606 OID 323060)
-- Dependencies: 462 462 462
-- Name: pkey_synth_seq; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY synthetic_sequences
    ADD CONSTRAINT pkey_synth_seq PRIMARY KEY (sequence_name, base_position);


--
-- TOC entry 3351 (class 2606 OID 24655)
-- Dependencies: 384 384 384
-- Name: project_samples_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY project_samples
    ADD CONSTRAINT project_samples_pkey PRIMARY KEY (sample_id, project);


--
-- TOC entry 3349 (class 2606 OID 24653)
-- Dependencies: 383 383
-- Name: projects_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (project);


--
-- TOC entry 3450 (class 2606 OID 230967)
-- Dependencies: 454 454
-- Name: protocol_types_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY protocol_types
    ADD CONSTRAINT protocol_types_pkey PRIMARY KEY (protocol_type);


--
-- TOC entry 3452 (class 2606 OID 231029)
-- Dependencies: 455 455
-- Name: protocols_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY protocols
    ADD CONSTRAINT protocols_pkey PRIMARY KEY (protocol_id);


--
-- TOC entry 3454 (class 2606 OID 232147)
-- Dependencies: 455 455
-- Name: protocols_protocol_text_key; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY protocols
    ADD CONSTRAINT protocols_protocol_text_key UNIQUE (protocol_text) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3456 (class 2606 OID 232150)
-- Dependencies: 455 455
-- Name: protocols_protocol_title_key; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY protocols
    ADD CONSTRAINT protocols_protocol_title_key UNIQUE (protocol_title) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3376 (class 2606 OID 30825)
-- Dependencies: 397 397
-- Name: reference_seqs_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY reference_seqs
    ADD CONSTRAINT reference_seqs_pkey PRIMARY KEY (reference_seq);


--
-- TOC entry 3444 (class 2606 OID 184137)
-- Dependencies: 442 442
-- Name: sample_sources_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY sample_sources
    ADD CONSTRAINT sample_sources_pkey PRIMARY KEY (source_name);


--
-- TOC entry 3353 (class 2606 OID 24684)
-- Dependencies: 385 385
-- Name: samples_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY samples
    ADD CONSTRAINT samples_pkey PRIMARY KEY (sample_id);


--
-- TOC entry 3468 (class 2606 OID 323024)
-- Dependencies: 461 461
-- Name: synthetic_sequences_codes_description_key; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY synthetic_sequences_codes
    ADD CONSTRAINT synthetic_sequences_codes_description_key UNIQUE (description);


--
-- TOC entry 3470 (class 2606 OID 323022)
-- Dependencies: 461 461
-- Name: synthetic_sequences_codes_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY synthetic_sequences_codes
    ADD CONSTRAINT synthetic_sequences_codes_pkey PRIMARY KEY (base_modified);


--
-- TOC entry 3484 (class 2606 OID 331846)
-- Dependencies: 465 465
-- Name: synthetic_sequences_names_pkey; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY synthetic_sequences_names
    ADD CONSTRAINT synthetic_sequences_names_pkey PRIMARY KEY (sequence_name);


--
-- TOC entry 3472 (class 2606 OID 323036)
-- Dependencies: 461 461 461
-- Name: uidx_bases; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY synthetic_sequences_codes
    ADD CONSTRAINT uidx_bases UNIQUE (base_iupac, base_modified);


--
-- TOC entry 3474 (class 2606 OID 323034)
-- Dependencies: 461 461
-- Name: uidx_iupac; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY synthetic_sequences_codes
    ADD CONSTRAINT uidx_iupac UNIQUE (base_modified);


--
-- TOC entry 3460 (class 2606 OID 256627)
-- Dependencies: 457 457 457
-- Name: uidx_protocol2library; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY protocol2library
    ADD CONSTRAINT uidx_protocol2library UNIQUE (library_id, protocol_id);


--
-- TOC entry 3458 (class 2606 OID 256625)
-- Dependencies: 456 456 456
-- Name: uidx_protocol2sample; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY protocol2sample
    ADD CONSTRAINT uidx_protocol2sample UNIQUE (sample_id, protocol_id);


--
-- TOC entry 3466 (class 2606 OID 320781)
-- Dependencies: 459 459 459
-- Name: uidx_seqid_seq_plat; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY sequencers
    ADD CONSTRAINT uidx_seqid_seq_plat UNIQUE (sequencer_id, sequencing_platform);


--
-- TOC entry 3476 (class 2606 OID 339400)
-- Dependencies: 461 461
-- Name: uidx_short_descr; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY synthetic_sequences_codes
    ADD CONSTRAINT uidx_short_descr UNIQUE (short_description);


--
-- TOC entry 3429 (class 2606 OID 31986)
-- Dependencies: 423 423 423
-- Name: uindx_variable_value; Type: CONSTRAINT; Schema: main; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY exp_values
    ADD CONSTRAINT uindx_variable_value UNIQUE (s_variable, s_value);


SET search_path = public, pg_catalog;

--
-- TOC entry 3374 (class 2606 OID 30801)
-- Dependencies: 396 396
-- Name: pk_barcode_id; Type: CONSTRAINT; Schema: public; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY barcodes_tmp
    ADD CONSTRAINT pk_barcode_id PRIMARY KEY (barcode_id);


--
-- TOC entry 3446 (class 2606 OID 210898)
-- Dependencies: 447 447
-- Name: pk_tmpfq; Type: CONSTRAINT; Schema: public; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY tmp_fq
    ADD CONSTRAINT pk_tmpfq PRIMARY KEY (fastqfile);


--
-- TOC entry 3431 (class 2606 OID 36518)
-- Dependencies: 426 426
-- Name: testfile_pkey; Type: CONSTRAINT; Schema: public; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY testfile
    ADD CONSTRAINT testfile_pkey PRIMARY KEY (fileid);


SET search_path = zzz_unused_or_deprecated, pg_catalog;

--
-- TOC entry 3356 (class 2606 OID 24707)
-- Dependencies: 386 386 386
-- Name: chipseq_input_pkey; Type: CONSTRAINT; Schema: zzz_unused_or_deprecated; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY chipseq_input
    ADD CONSTRAINT chipseq_input_pkey PRIMARY KEY (input_for, input_id);


--
-- TOC entry 3367 (class 2606 OID 30327)
-- Dependencies: 393 393
-- Name: project_files_pkey; Type: CONSTRAINT; Schema: zzz_unused_or_deprecated; Owner: dberaldi; Tablespace: 
--

ALTER TABLE ONLY project_files
    ADD CONSTRAINT project_files_pkey PRIMARY KEY (file_id);


SET search_path = "20120622_rnaseq_pdsa", pg_catalog;

--
-- TOC entry 3437 (class 1259 OID 173003)
-- Dependencies: 439
-- Name: idx_gene_id; Type: INDEX; Schema: 20120622_rnaseq_pdsa; Owner: dberaldi; Tablespace: 
--

CREATE INDEX idx_gene_id ON cufflinks_gtf USING btree (gene_id);


--
-- TOC entry 3438 (class 1259 OID 173004)
-- Dependencies: 439
-- Name: idx_transcript_id; Type: INDEX; Schema: 20120622_rnaseq_pdsa; Owner: dberaldi; Tablespace: 
--

CREATE INDEX idx_transcript_id ON cufflinks_gtf USING btree (transcript_id);


SET search_path = django_admin, pg_catalog;

--
-- TOC entry 3384 (class 1259 OID 31390)
-- Dependencies: 402
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- TOC entry 3387 (class 1259 OID 31391)
-- Dependencies: 402
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- TOC entry 3412 (class 1259 OID 31396)
-- Dependencies: 412
-- Name: auth_message_user_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_message_user_id ON auth_message USING btree (user_id);


--
-- TOC entry 3379 (class 1259 OID 31389)
-- Dependencies: 400
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- TOC entry 3400 (class 1259 OID 31395)
-- Dependencies: 408
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- TOC entry 3403 (class 1259 OID 31394)
-- Dependencies: 408
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- TOC entry 3394 (class 1259 OID 31393)
-- Dependencies: 406
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- TOC entry 3397 (class 1259 OID 31392)
-- Dependencies: 406
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- TOC entry 3422 (class 1259 OID 31422)
-- Dependencies: 419
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- TOC entry 3425 (class 1259 OID 31421)
-- Dependencies: 419
-- Name: django_admin_log_user_id; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- TOC entry 3417 (class 1259 OID 31397)
-- Dependencies: 415
-- Name: django_session_expire_date; Type: INDEX; Schema: django_admin; Owner: dberaldi; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


SET search_path = main, pg_catalog;

--
-- TOC entry 3436 (class 1259 OID 209762)
-- Dependencies: 437 680 437
-- Name: idx_demux_report_library_id; Type: INDEX; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE INDEX idx_demux_report_library_id ON demux_report USING btree (public.get_library_id(fastqfile_demux));


--
-- TOC entry 3354 (class 1259 OID 190833)
-- Dependencies: 385 385
-- Name: uind_samples_initials; Type: INDEX; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE UNIQUE INDEX uind_samples_initials ON samples USING btree (regexp_replace(sample_id, '\d.*'::text, ''::text), regexp_replace(regexp_replace(sample_id, '^[A-Z0]*'::text, ''::text), '_.*'::text, ''::text));


--
-- TOC entry 3893 (class 0 OID 0)
-- Dependencies: 3354
-- Name: INDEX uind_samples_initials; Type: COMMENT; Schema: main; Owner: dberaldi
--

COMMENT ON INDEX uind_samples_initials IS 'Make sample_id unique in the initials and int part. E.g. DB001 and DB0001 not allowed (DB1 = DB1)';


--
-- TOC entry 3361 (class 1259 OID 155765)
-- Dependencies: 390 390
-- Name: uindx_initials; Type: INDEX; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE UNIQUE INDEX uindx_initials ON contacts USING btree (lower(initials));


--
-- TOC entry 3362 (class 1259 OID 29389)
-- Dependencies: 390 390
-- Name: unique_contacts-contact_name; Type: INDEX; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE UNIQUE INDEX "unique_contacts-contact_name" ON contacts USING btree (lower(contact_name));


--
-- TOC entry 3365 (class 1259 OID 29472)
-- Dependencies: 391 391
-- Name: unique_filing_order-filing_order; Type: INDEX; Schema: main; Owner: dberaldi; Tablespace: 
--

CREATE UNIQUE INDEX "unique_filing_order-filing_order" ON filing_order USING btree (filing_order) WHERE (filing_order IS NOT NULL);


SET search_path = zzz_unused_or_deprecated, pg_catalog;

--
-- TOC entry 3368 (class 1259 OID 30335)
-- Dependencies: 393 393 393 393 393
-- Name: unique_project_files-files; Type: INDEX; Schema: zzz_unused_or_deprecated; Owner: dberaldi; Tablespace: 
--

CREATE UNIQUE INDEX "unique_project_files-files" ON project_files USING btree (filename, path, hostname, project) WHERE (removed = false);


SET search_path = main, pg_catalog;

--
-- TOC entry 3216 (class 2618 OID 29927)
-- Dependencies: 391 391 281 281 391 391
-- Name: filing_order-table_name-must-exist; Type: RULE; Schema: main; Owner: dberaldi
--

CREATE RULE "filing_order-table_name-must-exist" AS ON INSERT TO filing_order WHERE (NOT (new.table_name IN (SELECT pg_tables.tablename FROM pg_tables WHERE (pg_tables.schemaname = 'main'::name)))) DO INSTEAD NOTHING;


--
-- TOC entry 3217 (class 2618 OID 29928)
-- Dependencies: 391 281 391 391 281 391
-- Name: filing_order-table_name-must-exist-update; Type: RULE; Schema: main; Owner: dberaldi
--

CREATE RULE "filing_order-table_name-must-exist-update" AS ON UPDATE TO filing_order WHERE (NOT (new.table_name IN (SELECT pg_tables.tablename FROM pg_tables WHERE (pg_tables.schemaname = 'main'::name)))) DO INSTEAD NOTHING;


SET search_path = zzz_unused_or_deprecated, pg_catalog;

--
-- TOC entry 3218 (class 2618 OID 32004)
-- Dependencies: 386 382 386 382 398 675 386 382 386 398
-- Name: chipseq_input_ins; Type: RULE; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

CREATE RULE chipseq_input_ins AS ON INSERT TO chipseq_input WHERE (NOT (new.input_id IN (SELECT libraries.library_id FROM (main.libraries JOIN main.exp_design ON ((libraries.sample_id = exp_design.sample_id))) WHERE ((exp_design.s_variable = 'chip_target'::text) AND (exp_design.s_value = 'input'::text))))) DO INSTEAD SELECT public.raise_exception((('Exception raised by rule chipseq_input_ins: '::text || new.input_id) || ' is not present in exp_design as "input"'::text)) AS raise_exception;


--
-- TOC entry 3219 (class 2618 OID 32007)
-- Dependencies: 386 382 675 386 398 398 386 382 382 386
-- Name: chipseq_input_up; Type: RULE; Schema: zzz_unused_or_deprecated; Owner: dberaldi
--

CREATE RULE chipseq_input_up AS ON UPDATE TO chipseq_input WHERE (NOT (new.input_id IN (SELECT libraries.library_id FROM (main.libraries JOIN main.exp_design ON ((libraries.sample_id = exp_design.sample_id))) WHERE ((exp_design.s_variable = 'chip_target'::text) AND (exp_design.s_value = 'input'::text))))) DO INSTEAD SELECT public.raise_exception((('Exception raised by rule chipseq_input_ins: '::text || new.input_id) || ' is not present in exp_design as "input"'::text)) AS raise_exception;


SET search_path = main, pg_catalog;

--
-- TOC entry 3531 (class 2620 OID 203640)
-- Dependencies: 869 382
-- Name: trigger_create_crosstab_project_designs; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE TRIGGER trigger_create_crosstab_project_designs AFTER INSERT OR DELETE OR UPDATE ON exp_design FOR EACH STATEMENT EXECUTE PROCEDURE create_crosstab_project_designs();


--
-- TOC entry 3532 (class 2620 OID 32893)
-- Dependencies: 382 870
-- Name: trigger_crosstab_exp_design; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE TRIGGER trigger_crosstab_exp_design AFTER INSERT OR DELETE OR UPDATE ON exp_design FOR EACH STATEMENT EXECUTE PROCEDURE update_crosstab_exp_design();


--
-- TOC entry 3537 (class 2620 OID 256484)
-- Dependencies: 395 681
-- Name: trigger_fastqfile_startswith_library_id; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE CONSTRAINT TRIGGER trigger_fastqfile_startswith_library_id AFTER INSERT OR UPDATE ON fastqfiles DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE PROCEDURE fastqfile_startswith_library_id();


--
-- TOC entry 3534 (class 2620 OID 203642)
-- Dependencies: 384 869
-- Name: trigger_project_samples_create_crosstab_project_designs; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE TRIGGER trigger_project_samples_create_crosstab_project_designs AFTER INSERT OR DELETE OR UPDATE ON project_samples FOR EACH STATEMENT EXECUTE PROCEDURE create_crosstab_project_designs();


--
-- TOC entry 3533 (class 2620 OID 203641)
-- Dependencies: 869 383
-- Name: trigger_projects_create_crosstab_project_designs; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE TRIGGER trigger_projects_create_crosstab_project_designs AFTER INSERT OR DELETE OR UPDATE ON projects FOR EACH STATEMENT EXECUTE PROCEDURE create_crosstab_project_designs();


--
-- TOC entry 3530 (class 2620 OID 203639)
-- Dependencies: 870 382
-- Name: trigger_update_crosstab_exp_design; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE TRIGGER trigger_update_crosstab_exp_design AFTER INSERT OR DELETE OR UPDATE ON exp_design FOR EACH STATEMENT EXECUTE PROCEDURE update_crosstab_exp_design();


--
-- TOC entry 3539 (class 2620 OID 232212)
-- Dependencies: 677 423
-- Name: trigger_validate_exp_values; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE CONSTRAINT TRIGGER trigger_validate_exp_values AFTER INSERT OR UPDATE ON exp_values DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE PROCEDURE public.validate_exp_values();


--
-- TOC entry 3536 (class 2620 OID 232214)
-- Dependencies: 677 394
-- Name: trigger_validate_exp_values; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE CONSTRAINT TRIGGER trigger_validate_exp_values AFTER INSERT OR UPDATE ON exp_variables DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE PROCEDURE public.validate_exp_values();


--
-- TOC entry 3538 (class 2620 OID 249142)
-- Dependencies: 682 398
-- Name: trigger_validate_library_id; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE CONSTRAINT TRIGGER trigger_validate_library_id AFTER INSERT OR UPDATE ON libraries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE PROCEDURE validate_library_id();


--
-- TOC entry 3535 (class 2620 OID 686742)
-- Dependencies: 385 871
-- Name: trigger_validate_sample_id; Type: TRIGGER; Schema: main; Owner: dberaldi
--

CREATE CONSTRAINT TRIGGER trigger_validate_sample_id AFTER INSERT OR UPDATE ON samples DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE PROCEDURE validate_sample_id();


SET search_path = "20120622_rnaseq_pdsa", pg_catalog;

--
-- TOC entry 3519 (class 2606 OID 172990)
-- Dependencies: 439 398 3377
-- Name: fkey_library_id; Type: FK CONSTRAINT; Schema: 20120622_rnaseq_pdsa; Owner: dberaldi
--

ALTER TABLE ONLY cufflinks_gtf
    ADD CONSTRAINT fkey_library_id FOREIGN KEY (library_id) REFERENCES main.libraries(library_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3520 (class 2606 OID 172995)
-- Dependencies: 383 439 3348
-- Name: fkey_project_id; Type: FK CONSTRAINT; Schema: 20120622_rnaseq_pdsa; Owner: dberaldi
--

ALTER TABLE ONLY cufflinks_gtf
    ADD CONSTRAINT fkey_project_id FOREIGN KEY (project_id) REFERENCES main.projects(project) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = django_admin, pg_catalog;

--
-- TOC entry 3507 (class 2606 OID 31272)
-- Dependencies: 3382 402 400
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3513 (class 2606 OID 31353)
-- Dependencies: 3406 410 412
-- Name: auth_message_user_id_fkey; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3511 (class 2606 OID 31317)
-- Dependencies: 408 404 3392
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3509 (class 2606 OID 31302)
-- Dependencies: 406 400 3382
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3506 (class 2606 OID 31368)
-- Dependencies: 414 3415 400
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3515 (class 2606 OID 31416)
-- Dependencies: 414 3415 419
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3514 (class 2606 OID 31411)
-- Dependencies: 419 410 3406
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3508 (class 2606 OID 31287)
-- Dependencies: 3392 402 404
-- Name: group_id_refs_id_3cea63fe; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_3cea63fe FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3512 (class 2606 OID 31337)
-- Dependencies: 410 408 3406
-- Name: user_id_refs_id_831107f1; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_831107f1 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3510 (class 2606 OID 31332)
-- Dependencies: 410 3406 406
-- Name: user_id_refs_id_f2045483; Type: FK CONSTRAINT; Schema: django_admin; Owner: dberaldi
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_f2045483 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


SET search_path = main, pg_catalog;

--
-- TOC entry 3500 (class 2606 OID 320782)
-- Dependencies: 3465 459 459 395 395
-- Name: fastqfiles_seq_plat_seq_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY fastqfiles
    ADD CONSTRAINT fastqfiles_seq_plat_seq_id_fkey FOREIGN KEY (sequencing_platform, sequencer_id) REFERENCES sequencers(sequencing_platform, sequencer_id);


--
-- TOC entry 3501 (class 2606 OID 375350)
-- Dependencies: 459 3463 395
-- Name: fastqfiles_sequencer_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY fastqfiles
    ADD CONSTRAINT fastqfiles_sequencer_id_fkey FOREIGN KEY (sequencer_id) REFERENCES sequencers(sequencer_id);


--
-- TOC entry 3499 (class 2606 OID 262275)
-- Dependencies: 395 3447 451
-- Name: fastqfiles_sequencing_platform_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY fastqfiles
    ADD CONSTRAINT fastqfiles_sequencing_platform_fkey FOREIGN KEY (sequencing_platform) REFERENCES sequencing_platforms(sequencing_platform);


--
-- TOC entry 3487 (class 2606 OID 231989)
-- Dependencies: 382 3352 385
-- Name: fk_exp_design-sample_id; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY exp_design
    ADD CONSTRAINT "fk_exp_design-sample_id" FOREIGN KEY (sample_id) REFERENCES samples(sample_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3496 (class 2606 OID 231994)
-- Dependencies: 3377 398 395
-- Name: fk_library; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY fastqfiles
    ADD CONSTRAINT fk_library FOREIGN KEY (library_id) REFERENCES libraries(library_id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3518 (class 2606 OID 231999)
-- Dependencies: 3377 430 398
-- Name: fk_libs; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY lib2seq
    ADD CONSTRAINT fk_libs FOREIGN KEY (library_id) REFERENCES libraries(library_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3491 (class 2606 OID 232004)
-- Dependencies: 383 384 3348
-- Name: fk_project_sample-project; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY project_samples
    ADD CONSTRAINT "fk_project_sample-project" FOREIGN KEY (project) REFERENCES projects(project) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3490 (class 2606 OID 232009)
-- Dependencies: 385 3352 384
-- Name: fk_project_sample-sample_id; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY project_samples
    ADD CONSTRAINT "fk_project_sample-sample_id" FOREIGN KEY (sample_id) REFERENCES samples(sample_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3489 (class 2606 OID 232014)
-- Dependencies: 3359 390 383
-- Name: fk_projects-contact; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY projects
    ADD CONSTRAINT "fk_projects-contact" FOREIGN KEY (contact) REFERENCES contacts(contact_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3517 (class 2606 OID 232019)
-- Dependencies: 430 3344 381
-- Name: fk_service; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY lib2seq
    ADD CONSTRAINT fk_service FOREIGN KEY (service_id) REFERENCES solexa_lims(service_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3497 (class 2606 OID 232024)
-- Dependencies: 3344 381 395
-- Name: fk_service2solexa; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY fastqfiles
    ADD CONSTRAINT fk_service2solexa FOREIGN KEY (service_id_deprecated) REFERENCES solexa_lims(service_id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3528 (class 2606 OID 323042)
-- Dependencies: 3471 462 461 461 462
-- Name: fkey_bases; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY synthetic_sequences
    ADD CONSTRAINT fkey_bases FOREIGN KEY (base_iupac, base_modified) REFERENCES synthetic_sequences_codes(base_iupac, base_modified);


--
-- TOC entry 3488 (class 2606 OID 232029)
-- Dependencies: 423 382 382 423 3428
-- Name: fkey_exp_design_value; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY exp_design
    ADD CONSTRAINT fkey_exp_design_value FOREIGN KEY (s_variable, s_value) REFERENCES exp_values(s_variable, s_value) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3516 (class 2606 OID 232034)
-- Dependencies: 394 423 3369
-- Name: fkey_exp_values_variable; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY exp_values
    ADD CONSTRAINT fkey_exp_values_variable FOREIGN KEY (s_variable) REFERENCES exp_variables(s_variable) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3498 (class 2606 OID 256696)
-- Dependencies: 458 3461 395
-- Name: fkey_fastqfiles_encoding; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY fastqfiles
    ADD CONSTRAINT fkey_fastqfiles_encoding FOREIGN KEY (encoding) REFERENCES encodings(encoding) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3486 (class 2606 OID 232039)
-- Dependencies: 3447 381 451
-- Name: fkey_instrument; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY solexa_lims
    ADD CONSTRAINT fkey_instrument FOREIGN KEY (instrument_deprecated) REFERENCES sequencing_platforms(sequencing_platform) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3493 (class 2606 OID 232044)
-- Dependencies: 3439 440 385
-- Name: fkey_molecule; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY samples
    ADD CONSTRAINT fkey_molecule FOREIGN KEY (molecule) REFERENCES molecules(molecule) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3529 (class 2606 OID 331852)
-- Dependencies: 462 3483 465
-- Name: fkey_names; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY synthetic_sequences
    ADD CONSTRAINT fkey_names FOREIGN KEY (sequence_name) REFERENCES synthetic_sequences_names(sequence_name) ON UPDATE CASCADE;


--
-- TOC entry 3494 (class 2606 OID 232049)
-- Dependencies: 3441 385 441
-- Name: fkey_organism; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY samples
    ADD CONSTRAINT fkey_organism FOREIGN KEY (organism) REFERENCES organisms(organism) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3495 (class 2606 OID 232054)
-- Dependencies: 385 3359 390
-- Name: fkey_samples-sample_owner-contacts; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY samples
    ADD CONSTRAINT "fkey_samples-sample_owner-contacts" FOREIGN KEY (contact) REFERENCES contacts(contact_name) ON UPDATE CASCADE ON DELETE SET DEFAULT DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3485 (class 2606 OID 232059)
-- Dependencies: 3359 381 390
-- Name: fkey_solexa_lims-owner_contacts; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY solexa_lims
    ADD CONSTRAINT "fkey_solexa_lims-owner_contacts" FOREIGN KEY (contact) REFERENCES contacts(contact_name) ON UPDATE CASCADE ON DELETE SET DEFAULT DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3492 (class 2606 OID 232064)
-- Dependencies: 442 385 3443
-- Name: fkey_source; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY samples
    ADD CONSTRAINT fkey_source FOREIGN KEY (source_name) REFERENCES sample_sources(source_name) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3527 (class 2606 OID 262258)
-- Dependencies: 3447 459 451
-- Name: instrument_models_instrument_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY sequencers
    ADD CONSTRAINT instrument_models_instrument_fkey FOREIGN KEY (sequencing_platform) REFERENCES sequencing_platforms(sequencing_platform) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3505 (class 2606 OID 630041)
-- Dependencies: 398 3357 389
-- Name: libraries_barcode_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY libraries
    ADD CONSTRAINT libraries_barcode_id_fkey FOREIGN KEY (barcode_id) REFERENCES barcodes(barcode_id) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3502 (class 2606 OID 232074)
-- Dependencies: 398 3359 390
-- Name: libraries_contact_name_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY libraries
    ADD CONSTRAINT libraries_contact_name_fkey FOREIGN KEY (contact) REFERENCES contacts(contact_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3503 (class 2606 OID 232079)
-- Dependencies: 398 427 3432
-- Name: libraries_library_type_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY libraries
    ADD CONSTRAINT libraries_library_type_fkey FOREIGN KEY (library_type) REFERENCES library_types(library_type) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3504 (class 2606 OID 232084)
-- Dependencies: 3352 398 385
-- Name: libraries_sample_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY libraries
    ADD CONSTRAINT libraries_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES samples(sample_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3526 (class 2606 OID 232089)
-- Dependencies: 398 3377 457
-- Name: protocol2library_library_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY protocol2library
    ADD CONSTRAINT protocol2library_library_id_fkey FOREIGN KEY (library_id) REFERENCES libraries(library_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3525 (class 2606 OID 232094)
-- Dependencies: 457 3451 455
-- Name: protocol2library_protocol_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY protocol2library
    ADD CONSTRAINT protocol2library_protocol_id_fkey FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3524 (class 2606 OID 232099)
-- Dependencies: 455 3451 456
-- Name: protocol2sample_protocol_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY protocol2sample
    ADD CONSTRAINT protocol2sample_protocol_id_fkey FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3523 (class 2606 OID 232104)
-- Dependencies: 456 3352 385
-- Name: protocol2sample_sample_id_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY protocol2sample
    ADD CONSTRAINT protocol2sample_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES samples(sample_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3521 (class 2606 OID 232109)
-- Dependencies: 390 3359 455
-- Name: protocols_contact_name_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY protocols
    ADD CONSTRAINT protocols_contact_name_fkey FOREIGN KEY (contact_name) REFERENCES contacts(contact_name) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3522 (class 2606 OID 232114)
-- Dependencies: 455 3449 454
-- Name: protocols_protocol_type_fkey; Type: FK CONSTRAINT; Schema: main; Owner: dberaldi
--

ALTER TABLE ONLY protocols
    ADD CONSTRAINT protocols_protocol_type_fkey FOREIGN KEY (protocol_type) REFERENCES protocol_types(protocol_type) ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 47
-- Name: dbms_alert; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA dbms_alert FROM PUBLIC;
REVOKE ALL ON SCHEMA dbms_alert FROM dberaldi;
GRANT ALL ON SCHEMA dbms_alert TO dberaldi;
GRANT USAGE ON SCHEMA dbms_alert TO PUBLIC;


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 56
-- Name: dbms_assert; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA dbms_assert FROM PUBLIC;
REVOKE ALL ON SCHEMA dbms_assert FROM dberaldi;
GRANT ALL ON SCHEMA dbms_assert TO dberaldi;
GRANT USAGE ON SCHEMA dbms_assert TO PUBLIC;


--
-- TOC entry 3546 (class 0 OID 0)
-- Dependencies: 51
-- Name: dbms_output; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA dbms_output FROM PUBLIC;
REVOKE ALL ON SCHEMA dbms_output FROM dberaldi;
GRANT ALL ON SCHEMA dbms_output TO dberaldi;
GRANT USAGE ON SCHEMA dbms_output TO PUBLIC;


--
-- TOC entry 3547 (class 0 OID 0)
-- Dependencies: 46
-- Name: dbms_pipe; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA dbms_pipe FROM PUBLIC;
REVOKE ALL ON SCHEMA dbms_pipe FROM dberaldi;
GRANT ALL ON SCHEMA dbms_pipe TO dberaldi;
GRANT USAGE ON SCHEMA dbms_pipe TO PUBLIC;


--
-- TOC entry 3548 (class 0 OID 0)
-- Dependencies: 58
-- Name: dbms_random; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA dbms_random FROM PUBLIC;
REVOKE ALL ON SCHEMA dbms_random FROM dberaldi;
GRANT ALL ON SCHEMA dbms_random TO dberaldi;
GRANT USAGE ON SCHEMA dbms_random TO PUBLIC;


--
-- TOC entry 3549 (class 0 OID 0)
-- Dependencies: 53
-- Name: dbms_utility; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA dbms_utility FROM PUBLIC;
REVOKE ALL ON SCHEMA dbms_utility FROM dberaldi;
GRANT ALL ON SCHEMA dbms_utility TO dberaldi;
GRANT USAGE ON SCHEMA dbms_utility TO PUBLIC;


--
-- TOC entry 3551 (class 0 OID 0)
-- Dependencies: 50
-- Name: plvchr; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA plvchr FROM PUBLIC;
REVOKE ALL ON SCHEMA plvchr FROM dberaldi;
GRANT ALL ON SCHEMA plvchr TO dberaldi;
GRANT USAGE ON SCHEMA plvchr TO PUBLIC;


--
-- TOC entry 3552 (class 0 OID 0)
-- Dependencies: 48
-- Name: plvdate; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA plvdate FROM PUBLIC;
REVOKE ALL ON SCHEMA plvdate FROM dberaldi;
GRANT ALL ON SCHEMA plvdate TO dberaldi;
GRANT USAGE ON SCHEMA plvdate TO PUBLIC;


--
-- TOC entry 3553 (class 0 OID 0)
-- Dependencies: 54
-- Name: plvlex; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA plvlex FROM PUBLIC;
REVOKE ALL ON SCHEMA plvlex FROM dberaldi;
GRANT ALL ON SCHEMA plvlex TO dberaldi;
GRANT USAGE ON SCHEMA plvlex TO PUBLIC;


--
-- TOC entry 3554 (class 0 OID 0)
-- Dependencies: 49
-- Name: plvstr; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA plvstr FROM PUBLIC;
REVOKE ALL ON SCHEMA plvstr FROM dberaldi;
GRANT ALL ON SCHEMA plvstr TO dberaldi;
GRANT USAGE ON SCHEMA plvstr TO PUBLIC;


--
-- TOC entry 3555 (class 0 OID 0)
-- Dependencies: 52
-- Name: plvsubst; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA plvsubst FROM PUBLIC;
REVOKE ALL ON SCHEMA plvsubst FROM dberaldi;
GRANT ALL ON SCHEMA plvsubst TO dberaldi;
GRANT USAGE ON SCHEMA plvsubst TO PUBLIC;


--
-- TOC entry 3557 (class 0 OID 0)
-- Dependencies: 5
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- TOC entry 3558 (class 0 OID 0)
-- Dependencies: 55
-- Name: utl_file; Type: ACL; Schema: -; Owner: dberaldi
--

REVOKE ALL ON SCHEMA utl_file FROM PUBLIC;
REVOKE ALL ON SCHEMA utl_file FROM dberaldi;
GRANT ALL ON SCHEMA utl_file TO dberaldi;
GRANT USAGE ON SCHEMA utl_file TO PUBLIC;


SET search_path = dbms_alert, pg_catalog;

--
-- TOC entry 3560 (class 0 OID 0)
-- Dependencies: 587
-- Name: defered_signal(); Type: ACL; Schema: dbms_alert; Owner: dberaldi
--

REVOKE ALL ON FUNCTION defered_signal() FROM PUBLIC;
REVOKE ALL ON FUNCTION defered_signal() FROM dberaldi;
GRANT ALL ON FUNCTION defered_signal() TO dberaldi;


SET search_path = utl_file, pg_catalog;

--
-- TOC entry 3738 (class 0 OID 0)
-- Dependencies: 630
-- Name: tmpdir(); Type: ACL; Schema: utl_file; Owner: dberaldi
--

REVOKE ALL ON FUNCTION tmpdir() FROM PUBLIC;
REVOKE ALL ON FUNCTION tmpdir() FROM dberaldi;
GRANT ALL ON FUNCTION tmpdir() TO dberaldi;


SET search_path = dbms_pipe, pg_catalog;

--
-- TOC entry 3739 (class 0 OID 0)
-- Dependencies: 434
-- Name: db_pipes; Type: ACL; Schema: dbms_pipe; Owner: dberaldi
--

REVOKE ALL ON TABLE db_pipes FROM PUBLIC;
REVOKE ALL ON TABLE db_pipes FROM dberaldi;
GRANT ALL ON TABLE db_pipes TO dberaldi;
GRANT SELECT ON TABLE db_pipes TO PUBLIC;


SET search_path = public, pg_catalog;

--
-- TOC entry 3887 (class 0 OID 0)
-- Dependencies: 433
-- Name: dual; Type: ACL; Schema: public; Owner: dberaldi
--

REVOKE ALL ON TABLE dual FROM PUBLIC;
REVOKE ALL ON TABLE dual FROM dberaldi;
GRANT ALL ON TABLE dual TO dberaldi;
GRANT SELECT,REFERENCES ON TABLE dual TO PUBLIC;


SET search_path = utl_file, pg_catalog;

--
-- TOC entry 3889 (class 0 OID 0)
-- Dependencies: 435
-- Name: utl_file_dir; Type: ACL; Schema: utl_file; Owner: dberaldi
--

REVOKE ALL ON TABLE utl_file_dir FROM PUBLIC;
REVOKE ALL ON TABLE utl_file_dir FROM dberaldi;
GRANT ALL ON TABLE utl_file_dir TO dberaldi;


-- Completed on 2015-10-16 12:15:34 BST

--
-- PostgreSQL database dump complete
--

